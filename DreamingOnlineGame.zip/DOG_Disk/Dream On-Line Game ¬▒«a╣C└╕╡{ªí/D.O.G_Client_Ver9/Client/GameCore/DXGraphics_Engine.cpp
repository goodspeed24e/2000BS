//////////////////////////////////////////////////////////////////
///
//
/*************************************											
//	ø�Ϥ���, DXGraphics_Engine.cpp - v0.1	
//    author : Y.Y.L Date : 02/27/03
//************************************/
//-----------------------------------------------------------------


#include "..\Common\Global.h"
#include "rmxftmpl.h"
#include "rmxfguid.h"

//	--------------------------------------------------------------------------------
//
//	Class of CGraphics3DCore Functioins
//
//	--------------------------------------------------------------------------------
CGraphics3DCore::CGraphics3DCore()
{
	m_hWnd = NULL;

	m_pD3D = NULL;
	m_pD3DDevice =	NULL;
	m_pSprite =	NULL;
	m_AmbientRed = m_AmbientGreen = m_AmbientBlue = 255;

	m_Width		= 0;
	m_Height	=	0;
	m_BPP			= 0;

	m_Windowed	=	TRUE;
	m_ZBuffer		=	FALSE;
	m_HAL				= FALSE;

}

CGraphics3DCore::~CGraphics3DCore()
{ Shutdown();	}

BOOL CGraphics3DCore::Init()
{
  Shutdown();
	if((m_pD3D = Direct3DCreate8(D3D_SDK_VERSION)) == NULL)
			return FALSE;
	return TRUE;
}

BOOL CGraphics3DCore::SetMode(HWND hWnd,BOOL Windowed,BOOL UseZBuffer,long Width,long Height, char BPP)
{
	D3DPRESENT_PARAMETERS						d3dpp;
	D3DFORMAT												Format, AltFormat;
	RECT														WndRect,ClientRect;
	long														WndWidth,WndHeight;
	float														Aspect;

	// ���~�ˬd
	if((m_hWnd = hWnd) == NULL)
		return FALSE;
	if( m_pD3D == NULL )
		return FALSE;

	// ���o�ثe��ܼҦ����榡
	if(FAILED(m_pD3D->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &m_d3ddm)))
		return FALSE;

	// �]�w Width
	if(!Width){
		if(Windowed == FALSE)							// �O�_���ù�
			m_Width = m_d3ddm.Width;
		else{
			GetClientRect(m_hWnd,&ClientRect);
			m_Width = ClientRect.right;}
	}
	else{	
		m_Width = Width;	
	}

	// �]�w Height
	if(!Height){
		if(Windowed == FALSE)
			m_Height = m_d3ddm.Height;
		else{
			GetClientRect(m_hWnd, &ClientRect);
			m_Height = ClientRect.bottom;}
	}
	else{ 
		m_Height = Height;	
	}

	// �]�w BPP
	if(!(m_BPP = BPP) || Windowed == TRUE){
		if(!(m_BPP = GetFormatBPP(m_d3ddm.Format)))
			return FALSE;	}

	// �վ�client����
	if(Windowed == TRUE)
	{
		// Get the size of the window
		GetWindowRect(m_hWnd,&WndRect);
		GetClientRect(m_hWnd,&ClientRect);
		// Set to fullscreen
		//	SetWindowLong( m_hWnd, GWL_STYLE, WS_POPUP|WS_SYSMENU|WS_VISIBLE );
		WndWidth	= (WndRect.right	- (ClientRect.right  - m_Width))	- WndRect.left;
		WndHeight =	(WndRect.bottom	- (ClientRect.bottom - m_Height))	- WndRect.top;
		MoveWindow(m_hWnd,WndRect.left,WndRect.top,WndWidth,WndHeight,TRUE);
	}
	
	m_HAL = FALSE;				//	����l�w��[�t��false
	ZeroMemory(&d3dpp,sizeof(d3dpp));

	// �]�w������/���ù�
	if((m_Windowed = Windowed) == TRUE)
	{
		d3dpp.Windowed					=	TRUE;
		d3dpp.SwapEffect				=	D3DSWAPEFFECT_DISCARD;
		d3dpp.BackBufferFormat	=	m_d3ddm.Format;
		
		if(CheckFormat(m_d3ddm.Format,TRUE,TRUE) == TRUE)		
			m_HAL		=		TRUE; 
		else
			if(CheckFormat(m_d3ddm.Format,TRUE,FALSE) == FALSE)
				return FALSE;
	}
	else
	{
		d3dpp.Windowed		=	FALSE;
		d3dpp.SwapEffect	= D3DSWAPEFFECT_FLIP;

		d3dpp.BackBufferWidth		=	m_Width;
		d3dpp.BackBufferHeight		=	m_Height;
		d3dpp.FullScreen_RefreshRateInHz		=	D3DPRESENT_RATE_DEFAULT;
		d3dpp.FullScreen_PresentationInterval	=	D3DPRESENT_INTERVAL_DEFAULT;	
		// or D3DPRESENT_INTERVAL_DEFAULT or D3DPRESENT_INTERVAL_IMMEDIATE

		// �p����ܮ榡
		if(m_BPP == 32){
			Format		=	D3DFMT_X8R8G8B8;
			AltFormat	=	D3DFMT_X8R8G8B8;
		}else 	if(m_BPP == 24){
			Format		=	D3DFMT_R8G8B8;
			AltFormat	= D3DFMT_R8G8B8;
		}else		if(m_BPP == 16){
			Format		=	D3DFMT_R5G6B5;
			AltFormat	= D3DFMT_X1R5G5B5;
		}else		if(m_BPP == 8){
			Format		= D3DFMT_P8;
			AltFormat	= D3DFMT_P8;
		}

		// �ˬdHAL�˸m
		if(CheckFormat(Format,FALSE,TRUE) == TRUE)
			m_HAL	=	TRUE;
		else
			if(CheckFormat(AltFormat,FALSE,TRUE) == TRUE){
				m_HAL = TRUE;
				Format = AltFormat;}
			else
				if(CheckFormat(Format,FALSE,FALSE) == FALSE)
					if(CheckFormat(AltFormat,FALSE,FALSE) == FALSE)	
						return FALSE;
					else	
						Format = AltFormat;
			d3dpp.BackBufferFormat = Format;
	}
		
	// �]�w Zbuffer �榡 - 16bit
	if((m_ZBuffer = UseZBuffer) == TRUE)
	{
		d3dpp.EnableAutoDepthStencil	=	TRUE;
		d3dpp.AutoDepthStencilFormat	=	D3DFMT_D16;
	}else
		d3dpp.EnableAutoDepthStencil	= FALSE;

	// �إ�D3DDevice����
	if(FAILED(m_pD3D->CreateDevice(D3DADAPTER_DEFAULT,
		(m_HAL == TRUE) ? D3DDEVTYPE_HAL : D3DDEVTYPE_REF,
		hWnd,D3DCREATE_SOFTWARE_VERTEXPROCESSING,
		&d3dpp,&m_pD3DDevice)))
	{
		// �յۥh�إߨS���䴩ZBuffer������
		if(m_ZBuffer == TRUE)
		{
			m_ZBuffer = FALSE;
			d3dpp.EnableAutoDepthStencil	= FALSE;

			if(FAILED(m_pD3D->CreateDevice(D3DADAPTER_DEFAULT,
					(m_HAL == TRUE) ? D3DDEVTYPE_HAL : D3DDEVTYPE_REF,
					hWnd,D3DCREATE_SOFTWARE_VERTEXPROCESSING,
					&d3dpp,&m_pD3DDevice)))
					return FALSE;
		}
		else
			return FALSE;
	}

	// �]�wdefault rendering states
	EnableLighting(FALSE);
	EnableZBuffer(m_ZBuffer);
	EnableAlphaBlending(FALSE);
	EnableAlphaTesting(FALSE);

	// �Ұʯ��zrendering stages �� filter ���A
	m_pD3DDevice->SetTextureStageState(0,D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pD3DDevice->SetTextureStageState(0,D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	m_pD3DDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_MODULATE);
	m_pD3DDevice->SetTextureStageState(0,D3DTSS_MAGFILTER,D3DTEXF_LINEAR);
	m_pD3DDevice->SetTextureStageState(0,D3DTSS_MINFILTER,D3DTEXF_LINEAR);

	// default ambient color to white
	SetAmbientLight(255,255,255);

	// �p����򥻤��
	Aspect = (float)m_Height / (float)m_Width;
	SetPerspective(D3DX_PI/4,Aspect,1.0f,1000.0f);

	// �إ�sprite ����
	if(FAILED(D3DXCreateSprite(m_pD3DDevice,&m_pSprite)))
		return FALSE;

	return TRUE;
}

// ����COM
BOOL CGraphics3DCore::Shutdown()
{
  ReleaseCOM(m_pSprite);
  ReleaseCOM(m_pD3DDevice);
  ReleaseCOM(m_pD3D);

  return TRUE;
}

// ���o��ܥd���䴩���Ӽ�
long CGraphics3DCore::GetNumDisplayModes()
{
  if(m_pD3D == NULL)
    return 0;

  return (long)m_pD3D->GetAdapterModeCount(D3DADAPTER_DEFAULT);
}

// ���o��ܼҦ�����T
BOOL CGraphics3DCore::GetDisplayModeInfo(long Num, D3DDISPLAYMODE *Mode)
{
  long Max;

  if(m_pD3D == NULL)
    return FALSE;

  Max = GetNumDisplayModes();
  if(Num >= Max)
    return FALSE;

  if(FAILED(m_pD3D->EnumAdapterModes(D3DADAPTER_DEFAULT,Num, Mode)))
    return FALSE;

  return TRUE;
}

// ���o�Ҥ䴩BPP���榡
char CGraphics3DCore::GetFormatBPP(D3DFORMAT Format)
{
  switch(Format) {
		// 32 bit modes
    case D3DFMT_A8R8G8B8:
    case D3DFMT_X8R8G8B8:
      return 32;break;

    // 24 bit modes
    case D3DFMT_R8G8B8:
      return 24; break;

    // 16 bit modes
    case D3DFMT_R5G6B5:
    case D3DFMT_X1R5G5B5:
    case D3DFMT_A1R5G5B5:
    case D3DFMT_A4R4G4B4:
      return 16; break;

    // 8 bit modes
    case D3DFMT_A8P8:
    case D3DFMT_P8:
      return 8; break;

    default:
       return 0;
  }
}

// �ˬd�O�_�䴩�w��[�t 
inline BOOL CGraphics3DCore::CheckFormat(D3DFORMAT Format, BOOL Windowed, BOOL HAL)
{
  if(FAILED(m_pD3D->CheckDeviceType(D3DADAPTER_DEFAULT,
		(HAL == TRUE) ? D3DDEVTYPE_HAL : D3DDEVTYPE_REF,
		Format, Format,Windowed)))
		return FALSE;

	return TRUE;
}
 
// �Ұ�/���� Scene
BOOL CGraphics3DCore::BeginScene()
{
  if(m_pD3DDevice == NULL)
    return FALSE;

  if(FAILED(m_pD3DDevice->BeginScene()))
    return FALSE;

  return TRUE;
}

BOOL CGraphics3DCore::EndScene()
{
  if(m_pD3DDevice == NULL)
    return FALSE;

  for(short i=0;i<8;i++)
    m_pD3DDevice->SetTexture(i, NULL);

  if(FAILED(m_pD3DDevice->EndScene()))
    return FALSE;

  return TRUE;
}

// �Ұ�/���� sprite
BOOL CGraphics3DCore::BeginSprite()
{
  if(m_pSprite == NULL)
    return FALSE;

  if(FAILED(m_pSprite->Begin()))
    return FALSE;

  return TRUE;
}

BOOL CGraphics3DCore::EndSprite()
{
  if(m_pSprite == NULL)
    return FALSE;

  if(FAILED(m_pSprite->End()))
    return FALSE;

  return TRUE;
}

// �M��present
BOOL CGraphics3DCore::Display()
{
  if(m_pD3DDevice == NULL)
    return FALSE;

  if(FAILED(m_pD3DDevice->Present(NULL, NULL, NULL, NULL)))
    return FALSE;

  return TRUE;
}

// �M��color & ZBuffer
BOOL CGraphics3DCore::Clear(long Color,float ZBuffer)
{
	if(m_pD3DDevice == NULL)
		return FALSE;
	
	// �P�_ZBuffer�O�_��False�A�Y�O�u�M��Color����
	if(m_ZBuffer == FALSE)
		return ClearDisplay(Color);
	
	// �M��Color/ZBuffer
	if(FAILED(m_pD3DDevice->Clear(0,NULL,D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
					Color,ZBuffer,0)))
					return FALSE;

	return TRUE;
}

// �M��color����
BOOL CGraphics3DCore::ClearDisplay(long Color)
{
  if(m_pD3DDevice == NULL)
    return FALSE;

	if(FAILED(m_pD3DDevice->Clear(0,NULL,D3DCLEAR_TARGET,Color,1.0f,0)))
		return FALSE;

  return TRUE; 
}  

// �M��ZBuffer
BOOL CGraphics3DCore::ClearZBuffer(float ZBuffer)
{
  if(m_pD3DDevice == NULL || m_ZBuffer == FALSE)
    return FALSE;

  if(FAILED(m_pD3DDevice->Clear(0,NULL,D3DCLEAR_ZBUFFER,0,ZBuffer,0)))
		return FALSE;

  return TRUE;
}

// �]�wCamera
BOOL CGraphics3DCore::SetCamera(cCamera *Camera)
{
	if(m_pD3DDevice == NULL || Camera == NULL)
		return FALSE;

	if(FAILED(m_pD3DDevice->SetTransform(D3DTS_VIEW,Camera->GetMatrix())))
		return FALSE;

	return TRUE;
}

// �]�wworld�y�Ъ���m
BOOL CGraphics3DCore::SetWorldPosition(cWorldPosition *WorldPos)
{
	if(WorldPos == NULL || m_pD3DDevice == NULL)
		return FALSE;
	
	if(FAILED(m_pD3DDevice->SetTransform(D3DTS_WORLD, WorldPos->GetMatrix(this))))
		return FALSE;

	return TRUE;
}

// �]�w����
BOOL CGraphics3DCore::SetLight(long Num,CLightMgr *Light)
{
	if(Light == NULL || m_pD3DDevice == NULL)
		return FALSE;

	if(FAILED(m_pD3DDevice->SetLight(Num,Light->GetLight())))
		return FALSE;

	return TRUE;
}

// �]�wAmbient����
BOOL CGraphics3DCore::SetAmbientLight(char Red, char Green, char Blue)
{
  D3DCOLOR Color;

  if(m_pD3DDevice == NULL)
    return FALSE;

	Color = D3DCOLOR_XRGB((m_AmbientRed = Red),(m_AmbientGreen = Green),
				(m_AmbientBlue = Blue));

	if(FAILED(m_pD3DDevice->SetRenderState(D3DRS_AMBIENT,Color)))
		return FALSE;

  return TRUE;
}

// ���oAmbientLight
BOOL CGraphics3DCore::GetAmbientLight(char *Red, char *Green, char *Blue)
{
  if(Red != NULL)
    *Red = m_AmbientRed;
  if(Green != NULL)
    *Green = m_AmbientGreen;
  if(Blue != NULL)
    *Blue = m_AmbientBlue;

  return TRUE;
}

// �]�w����
BOOL CGraphics3DCore::SetMaterial(CMaterialMgr *Material)
{
  if(m_pD3DDevice == NULL)
    return FALSE;

  if(Material != NULL){
		if(FAILED(m_pD3DDevice->SetMaterial(Material->GetMaterial())))
			return FALSE;
		}

  return TRUE;
}

// �]�w���z
BOOL CGraphics3DCore::SetTexture(short Num, CTextureMgr *Texture)
{
	if(m_pD3DDevice == NULL || Num < 0 || Num > 7)
		return FALSE;

	if(Texture == NULL)
	{
		if(FAILED(m_pD3DDevice->SetTexture(Num,NULL)))
			return FALSE;
	}
	else
	{
		if(FAILED(m_pD3DDevice->SetTexture(Num,Texture->GetTextureCOM())))
			return FALSE;
	}

  return TRUE;
}

// �]�wperspective
BOOL CGraphics3DCore::SetPerspective(float FOV, float Aspect, float Near, float Far)
{
  D3DXMATRIX matProjection;

  if(m_pD3DDevice == NULL)
    return FALSE;

  D3DXMatrixPerspectiveFovLH(&matProjection,FOV,Aspect,Near,Far);
	if(FAILED(m_pD3DDevice->SetTransform(D3DTS_PROJECTION,&matProjection)))
		return FALSE;

  return TRUE;
}

// �Ұʥ���
BOOL CGraphics3DCore::EnableLight(long Num, BOOL Enable)
{
  if(m_pD3DDevice == NULL)
    return FALSE;

  if(FAILED(m_pD3DDevice->LightEnable(Num, Enable)))
    return FALSE;

  return TRUE;
}

// �����B�z
BOOL CGraphics3DCore::EnableLighting(BOOL Enable)
{
	if(m_pD3DDevice == NULL)
		return FALSE;

	if(FAILED(m_pD3DDevice->SetRenderState(D3DRS_LIGHTING,Enable)))
		return FALSE;

	return TRUE;
}

// �Ұ�ZBuffer
BOOL CGraphics3DCore::EnableZBuffer(BOOL Enable)
{
  if(m_pD3DDevice == NULL || m_ZBuffer == FALSE)
    return FALSE;

  if(FAILED(m_pD3DDevice->SetRenderState(D3DRS_ZENABLE,
		(Enable == TRUE) ? D3DZB_TRUE : D3DZB_FALSE)))
		return FALSE;

  return TRUE;
}

// �Ұ�Alpha�V��
BOOL CGraphics3DCore::EnableAlphaBlending(BOOL Enable, DWORD Src, DWORD Dest)
{
  if(m_pD3DDevice == NULL)
    return FALSE;

	// �Ұ�/����
	if(FAILED(m_pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, Enable)))
		return FALSE;

	if(Enable == TRUE)
	{
		m_pD3DDevice->SetRenderState(D3DRS_SRCBLEND,Src);
		m_pD3DDevice->SetRenderState(D3DRS_DESTBLEND,Dest);
	}

  return TRUE;
}

// �Ұ�Alpha����
BOOL CGraphics3DCore::EnableAlphaTesting(BOOL Enable)
{
  if(m_pD3DDevice == NULL)
    return FALSE;

  if(FAILED(m_pD3DDevice->SetRenderState(D3DRS_ALPHATESTENABLE, Enable)))
    return FALSE;

  // Set test type
  if(Enable == TRUE) {
    m_pD3DDevice->SetRenderState(D3DRS_ALPHAREF, 0x08);
    m_pD3DDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);
  }

  return TRUE;
}

//	---------------------------------------------------------------------
//
//  Class of CTextureMgr Functions
//
//	---------------------------------------------------------------------
CTextureMgr::CTextureMgr()
{
  m_Graphics = NULL;
  m_Texture = NULL;
	sTexture.m_Width = sTexture.m_Height = 0;
}

CTextureMgr::~CTextureMgr()
{
	Free();
}

// ���J���z
BOOL CTextureMgr::Load(CGraphics3DCore *Graphics, char *FileName, DWORD Transparent, D3DFORMAT Format)
{
  Free();

  if((m_Graphics = Graphics) == NULL)
		return FALSE;
	if(Graphics->GetDeviceCOM() == NULL)
		return FALSE;
	if(FileName == NULL)
		return FALSE;

	if(FAILED(D3DXCreateTextureFromFileEx(Graphics->GetDeviceCOM(),
						FileName, D3DX_DEFAULT,D3DX_DEFAULT,D3DX_DEFAULT,
						0,Format,D3DPOOL_MANAGED,
						D3DX_FILTER_TRIANGLE, D3DX_FILTER_TRIANGLE,Transparent,
						NULL,NULL,&m_Texture)))
						return FALSE;

	sTexture.m_Width = GetWidth();
	sTexture.m_Height = GetHeight();

  return TRUE;
}

// �إ߯��z
BOOL CTextureMgr::Create(CGraphics3DCore *Graphics, IDirect3DTexture8 *Texture)
{
  D3DLOCKED_RECT	SrcRect,DestRect;
	D3DSURFACE_DESC	Desc;

	Free();
	if((m_Graphics = Graphics) == NULL)
		return FALSE;
	if(Texture == NULL)
		return FALSE;

	// �ƻs���z
	Texture->GetLevelDesc(0,&Desc);
	sTexture.m_Width = Desc.Width;
	sTexture.m_Height = Desc.Height;
	m_Graphics->GetDeviceCOM()->CreateTexture(sTexture.m_Width,sTexture.m_Height,0,0,Desc.Format,
		D3DPOOL_MANAGED, &m_Texture);

	// �i�毾�z�N���memory
	Texture->LockRect(0,&SrcRect,NULL,D3DLOCK_READONLY);
	m_Texture->LockRect(0,&DestRect,NULL,0);

	memcpy(DestRect.pBits,SrcRect.pBits,SrcRect.Pitch * sTexture.m_Height);

	m_Texture->UnlockRect(0);
	Texture->UnlockRect(0);

  return TRUE;
}

BOOL CTextureMgr::Free()
{
  ReleaseCOM(m_Texture);
  m_Graphics = NULL;
  sTexture.m_Width = sTexture.m_Height = 0;

  return TRUE;
}

BOOL CTextureMgr::IsLoaded()
{
  if(m_Texture == NULL)
    return FALSE;
  return TRUE;
}

long CTextureMgr::GetWidth()
{
	D3DSURFACE_DESC d3dsd;

	if(m_Texture == NULL)
		return 0;

	if(FAILED(m_Texture->GetLevelDesc(0, &d3dsd)))
		return 0;

	return d3dsd.Width;
}

long CTextureMgr::GetHeight()
{
  D3DSURFACE_DESC d3dsd;

  if(m_Texture == NULL)
    return 0;

  if(FAILED(m_Texture->GetLevelDesc(0, &d3dsd)))
    return 0;

  return d3dsd.Height;
}

D3DFORMAT CTextureMgr::GetFormat()
{
	D3DSURFACE_DESC	d3dsd;

  if(m_Texture == NULL)
		return D3DFMT_UNKNOWN;

	if(FAILED(m_Texture->GetLevelDesc(0,&d3dsd)))
		return D3DFMT_UNKNOWN;

	return d3dsd.Format;
}

// �ϥ�2-D���z
BOOL CTextureMgr::Blit(long DestX, long DestY,                   \
                    long SrcX, long SrcY,                     \
                    long Width, long Height,                  \
                    float XScale, float YScale,               \
                    D3DCOLOR Color)
{
  RECT Rect;
	ID3DXSprite	*pSprite;

	if (m_Texture == NULL || m_Graphics == NULL)
		return FALSE;
	// ���oID3DXSprite COM
	if((pSprite = m_Graphics->GetSpriteCOM()) == NULL)
		return FALSE;

	if(!Width)	Width		= sTexture.m_Width;
	if(!Height)	Height	= sTexture.m_Height;

	Rect.left = SrcX; Rect.top = SrcY;
	Rect.right	= Rect.left + Width;
	Rect.bottom =	Rect.top + Height;
	
	// Draws a simple sprite in screen-space
	if(FAILED(pSprite->Draw(m_Texture,&Rect,&D3DXVECTOR2(XScale,YScale),
						NULL, 0.0f,&D3DXVECTOR2((float) DestX,(float)DestY),Color)))
						return  FALSE;

	return TRUE;
}

//	---------------------------------------------------------------------
//
//  Class of CMaterialMgr Functions
//
//	---------------------------------------------------------------------
CMaterialMgr::CMaterialMgr()
{
	// default ���賣�M���զ�
  ZeroMemory(&m_Material,sizeof(D3DMATERIAL8));
	SetDiffuseColor(255,255,255);
	SetAmbientColor(255,255,255);
	SetSpecularColor(255,255,255);
	SetEmissiveColor(0,0,0);
	SetPower(1.0f);
}

// �]�w/���o Diffuse
BOOL CMaterialMgr::SetDiffuseColor(char Red,char Green,char Blue)
{
	m_Material.Diffuse.r = 1.0f / 255.0f * (float)Red;
	m_Material.Diffuse.g = 1.0f / 255.0f * (float)Green;
	m_Material.Diffuse.b = 1.0f / 255.0f * (float)Blue;

	return TRUE;
}

BOOL CMaterialMgr::GetDiffuseColor(char *Red, char *Green, char *Blue)
{
  if(Red != NULL)
    *Red = (char)(255.0f * m_Material.Diffuse.r);

  if(Green != NULL)
    *Green = (char)(255.0f * m_Material.Diffuse.g);

  if(Blue != NULL)
    *Blue = (char)(255.0f * m_Material.Diffuse.b);

  return TRUE;
}

// �]�w/���o Ambient
BOOL CMaterialMgr::SetAmbientColor(char Red, char Green, char Blue)
{
  m_Material.Ambient.r = 1.0f / 255.0f * (float)Red;
  m_Material.Ambient.g = 1.0f / 255.0f * (float)Green;
  m_Material.Ambient.b = 1.0f / 255.0f * (float)Blue;

  return TRUE;
}

BOOL CMaterialMgr::GetAmbientColor(char *Red, char *Green, char *Blue)
{
  if(Red != NULL)
    *Red = (char)(255.0f * m_Material.Ambient.r);

  if(Green != NULL)
    *Green = (char)(255.0f * m_Material.Ambient.g);

  if(Blue != NULL)
    *Blue = (char)(255.0f * m_Material.Ambient.b);

  return TRUE;
}

// �]�w/���o Specular 
BOOL CMaterialMgr::SetSpecularColor(char Red, char Green, char Blue)
{
  m_Material.Specular.r = 1.0f / 255.0f * (float)Red;
  m_Material.Specular.g = 1.0f / 255.0f * (float)Green;
  m_Material.Specular.b = 1.0f / 255.0f * (float)Blue;

  return TRUE;
}

BOOL CMaterialMgr::GetSpecularColor(char *Red, char *Green, char *Blue)
{
  if(Red != NULL)
    *Red = (char)(255.0f * m_Material.Specular.r);

  if(Green != NULL)
    *Green = (char)(255.0f * m_Material.Specular.g);

  if(Blue != NULL)
    *Blue = (char)(255.0f * m_Material.Specular.b);

  return TRUE;
}

// �]�w/���o Emissive
BOOL CMaterialMgr::SetEmissiveColor(char Red, char Green, char Blue)
{
  m_Material.Emissive.r = 1.0f / 255.0f * (float)Red;
  m_Material.Emissive.g = 1.0f / 255.0f * (float)Green;
  m_Material.Emissive.b = 1.0f / 255.0f * (float)Blue;

  return TRUE;
}

BOOL CMaterialMgr::GetEmissiveColor(char *Red, char *Green, char *Blue)
{
  if(Red != NULL)
    *Red = (char)(255.0f * m_Material.Emissive.r);

  if(Green != NULL)
    *Green = (char)(255.0f * m_Material.Emissive.g);

  if(Blue != NULL)
    *Blue = (char)(255.0f * m_Material.Emissive.b);

  return TRUE;
}

// �]�w/���o power
BOOL CMaterialMgr::SetPower(float Power)
{
  m_Material.Power = Power;
  return TRUE;
}

float CMaterialMgr::GetPower(float Power)
{
  return m_Material.Power;
}

D3DMATERIAL8 *CMaterialMgr::GetMaterial()
{
  return &m_Material;
}

//	-------------------------------------------------------------------------------
//
//	Class of Light Function
//
//	-------------------------------------------------------------------------------
CLightMgr::CLightMgr()
{
	// ��l�Ƭ����@�~
  ZeroMemory(&m_Light,sizeof(D3DLIGHT8));
	SetType(D3DLIGHT_POINT);
	Move(0.0f,0.0f,0.0f);
	SetDiffuseColor(255,255,255);
	SetAmbientColor(255,255,255);
	SetRange(1000.0f);
}

// �]�w�������A
BOOL CLightMgr::SetType(D3DLIGHTTYPE Type)
{
	m_Light.Type = Type;
	return TRUE;
}

D3DLIGHT8 *CLightMgr::GetLight()
{
  return &m_Light;
}

// ���ʥ����쵴���m�άO�۹��ثe����m
BOOL CLightMgr::Move(float XPos, float YPos, float ZPos)
{
  m_Light.Position.x = XPos;
	m_Light.Position.y = YPos;
	m_Light.Position.z = ZPos;
	return TRUE;
}

BOOL CLightMgr::MoveRel(float XPos, float YPos, float ZPos)
{
  m_Light.Position.x += XPos;
  m_Light.Position.y += YPos;
  m_Light.Position.z += ZPos;
  return TRUE;
}

// ���o�ثe��m
BOOL CLightMgr::GetPos(float *XPos, float *YPos, float *ZPos)
{
  if(XPos != NULL)
		*XPos = m_Light.Position.x;
	if(YPos != NULL)
		*YPos = m_Light.Position.y;
	if(ZPos != NULL)
		*ZPos = m_Light.Position.z;
	return TRUE;
}

// �]�w��V���w�����m�ά۹��m
BOOL CLightMgr::Point(float XFrom, float YFrom, float ZFrom,
                   float XAt,   float YAt,   float ZAt)
{
  D3DXVECTOR3 vecSrc;
	D3DXVECTOR3 vecDest;

	// ���ʥ���
	Move(XFrom,YFrom,ZFrom);

	// �p��V�q��������
	m_Light.Direction.x = XAt - XFrom;
	m_Light.Direction.y = YAt - YFrom;
	m_Light.Direction.z = ZAt - ZFrom;

  return TRUE;
}

// ���o�ثe��V
BOOL CLightMgr::GetDirection(float *XDir, float *YDir, float *ZDir)
{
  if(XDir != NULL)
    *XDir = m_Light.Direction.x;
  if(YDir != NULL)
    *YDir = m_Light.Direction.y;
  if(ZDir != NULL)
    *ZDir = m_Light.Direction.z;
  return TRUE;
}

// �]�w/���oDiffuse
BOOL CLightMgr::SetDiffuseColor(char Red, char Green, char Blue)
{
  m_Light.Diffuse.r = 1.0f / 255.0f * (float)Red;
  m_Light.Diffuse.g = 1.0f / 255.0f * (float)Green;
  m_Light.Diffuse.b = 1.0f / 255.0f * (float)Blue;

  return TRUE;
}

BOOL CLightMgr::GetDiffuseColor(char *Red, char *Green, char *Blue)
{
  if(Red != NULL)
    *Red = (char)(255.0f * m_Light.Diffuse.r);

  if(Green != NULL)
    *Green = (char)(255.0f * m_Light.Diffuse.g);

  if(Blue != NULL)
    *Blue = (char)(255.0f * m_Light.Diffuse.b);

  return TRUE;
}

// �]�w/���oSpecular
BOOL CLightMgr::SetSpecularColor(char Red, char Green, char Blue)
{
  m_Light.Specular.r = 1.0f / 255.0f * (float)Red;
  m_Light.Specular.g = 1.0f / 255.0f * (float)Green;
  m_Light.Specular.b = 1.0f / 255.0f * (float)Blue;

  return TRUE;
}

BOOL CLightMgr::GetSpecularColor(char *Red, char *Green, char *Blue)
{
  if(Red != NULL)
    *Red = (char)(255.0f * m_Light.Specular.r);

  if(Green != NULL)
    *Green = (char)(255.0f * m_Light.Specular.g);

  if(Blue != NULL)
    *Blue = (char)(255.0f * m_Light.Specular.b);

  return TRUE;
}

// �]�w/���oAmbient
BOOL CLightMgr::SetAmbientColor(char Red, char Green, char Blue)
{
  m_Light.Ambient.r = 1.0f / 255.0f * (float)Red;
  m_Light.Ambient.g = 1.0f / 255.0f * (float)Green;
  m_Light.Ambient.b = 1.0f / 255.0f * (float)Blue;

  return TRUE;
}

BOOL CLightMgr::GetAmbientColor(char *Red, char *Green, char *Blue)
{
  if(Red != NULL)
    *Red = (char)(255.0f * m_Light.Ambient.r);

  if(Green != NULL)
    *Green = (char)(255.0f * m_Light.Ambient.g);

  if(Blue != NULL)
    *Blue = (char)(255.0f * m_Light.Ambient.b);

  return TRUE;
}

// �]�w/���o�ഫ���
BOOL CLightMgr::SetRange(float Range)
{
  m_Light.Range = Range;
  return TRUE;
}

float CLightMgr::GetRange()
{
  return m_Light.Range;
}

// �]�w/���o��h����
BOOL CLightMgr::SetFalloff(float Falloff)
{
  m_Light.Falloff = Falloff;
  return TRUE;
}

float CLightMgr::GetFalloff()
{
  return m_Light.Falloff;
}

// �]�w/���oAttenuation0
BOOL CLightMgr::SetAttenuation0(float Attenuation)
{
  m_Light.Attenuation0 = Attenuation;
  return TRUE;
}

float CLightMgr::GetAttenuation0()
{
  return m_Light.Attenuation0;
}

// �]�w/���oAttenuation1
BOOL CLightMgr::SetAttenuation1(float Attenuation)
{
  m_Light.Attenuation1 = Attenuation;
  return TRUE;
}

float CLightMgr::GetAttenuation1()
{
  return m_Light.Attenuation1;
}

// �]�w/���oAttenuation2
BOOL CLightMgr::SetAttenuation2(float Attenuation)
{
  m_Light.Attenuation2 = Attenuation;
  return TRUE;
}

float CLightMgr::GetAttenuation2()
{
  return m_Light.Attenuation2;
}

// �]�w/���othta��
BOOL CLightMgr::SetTheta(float Theta)
{
  m_Light.Theta = Theta;
  return TRUE;
}

float CLightMgr::GetTheta()
{
  return m_Light.Theta;
}

// �]�w/���oPhi
BOOL CLightMgr::SetPhi(float Phi)
{
  m_Light.Phi = Phi;
  return TRUE;
}

float CLightMgr::GetPhi()
{
  return m_Light.Phi;
}

//	------------------------------------------------------------------------------
//
//  Class of cFont Function
//
//	------------------------------------------------------------------------------
cFont::cFont()
{
  m_Font = NULL;
}

cFont::~cFont()
{
  Free();
}

ID3DXFont *cFont::GetFontCOM()
{
  return m_Font;
}

BOOL cFont::Free()
{
  ReleaseCOM(m_Font);
  return TRUE;
}

BOOL cFont::Begin()
{
  if(m_Font == NULL)
    return FALSE;
  if(FAILED(m_Font->Begin()))
    return FALSE;
  return TRUE;
}

BOOL cFont::End()
{
  if(m_Font == NULL)
    return FALSE;
  if(FAILED(m_Font->End()))
    return FALSE;
  return TRUE;
}

// �إߦr��
BOOL cFont::Create(CGraphics3DCore *Graphics,char *Name,long Size, BOOL Bold,BOOL Italic, BOOL	Underline , BOOL Strikeout)
{
	LOGFONT	lf;

	if(Graphics == NULL || Name == NULL)
		return FALSE;
	if(Graphics->GetDeviceCOM() == NULL)
		return FALSE;

	// �M��font ���c
	ZeroMemory(&lf,sizeof(LOGFONT));

	// �]�w�r���W�ٿ�����
	strcpy(lf.lfFaceName,Name);
	lf.lfHeight		=		- Size;
	lf.lfWeight		=		(Bold == TRUE) ? 700 : 0;
	lf.lfItalic		=		Italic;
	lf.lfUnderline	=		Underline;
	lf.lfStrikeOut	=		Strikeout;

	//	�إߦr������
	if(FAILED(D3DXCreateFontIndirect(Graphics->GetDeviceCOM(),&lf,&m_Font)))
		return FALSE;

	return TRUE;
}

// �C�L�r������
BOOL	cFont::Print( char *Text,long XPos,long YPos,long Width,long Height ,D3DCOLOR Color, DWORD Format)
{
	RECT	Rect;

	if(m_Font == NULL)
		return FALSE;

	if(!Width)	Width = 65535;
	if(!Height) Height = 65536;

	Rect.left = XPos;
	Rect.top	=	YPos;
	Rect.right	=	Rect.left + Width;
	Rect.bottom = Rect.top	+	Height;
	if(FAILED(m_Font->DrawText(Text,-1,&Rect,Format,Color)))
		return FALSE;

	return TRUE;
}

//	------------------------------------------------------------------------------
//
//	Class of VertexBuffer function
//
//	------------------------------------------------------------------------------

cVertexBuffer::cVertexBuffer()
{
	m_Graphics	= NULL;
	m_pVB				=	NULL;
	m_NumVertices	=	0;
	m_FVF				=	0;
	m_Locked		=	FALSE;
	m_Ptr				=	NULL;
}

cVertexBuffer::~cVertexBuffer()
{	Free();}

IDirect3DVertexBuffer8 *cVertexBuffer::GetVertexBufferCOM()
{		return m_pVB;}

unsigned long cVertexBuffer::GetVertexSize()
{	return D3DXGetFVFVertexSize(m_FVF);}

unsigned long cVertexBuffer::GetNumVertices()
{	return m_NumVertices;}

BOOL cVertexBuffer::Create(CGraphics3DCore *Graphics,unsigned long NumVertices,DWORD Descriptor,long VertexSize)
{
	Free();

	if((m_Graphics = Graphics) == NULL)
		return FALSE;
	if((m_Graphics->GetDeviceCOM()) == NULL)
		return FALSE;
	// �P�_Vertices�Ӽ�,FVF,vertexSize
	if(!(m_NumVertices = NumVertices) || !(m_FVF = Descriptor) || !(m_VertexSize = VertexSize))
		return FALSE;

	// �إ�VertexBuffer
	if (FAILED(m_Graphics->GetDeviceCOM()->CreateVertexBuffer(m_NumVertices * m_VertexSize,0,m_FVF,
							D3DPOOL_DEFAULT, &m_pVB)))
		return FALSE;

	return TRUE;
}

BOOL cVertexBuffer::Free()
{
  Unlock();
	ReleaseCOM(m_pVB);
	m_Graphics = NULL;
	m_NumVertices = 0;
	m_FVF			=	0;
	m_Locked	=	FALSE;
	m_Ptr			=	NULL;

	return TRUE;
}

BOOL cVertexBuffer::Set(unsigned long FirstVertex,unsigned long NumVertices,void *VertexList)
{
	if(m_Graphics == NULL || VertexList == NULL || m_pVB == NULL)
		return FALSE;
	if(m_Graphics->GetDeviceCOM() ==	NULL)
		return FALSE;

	// lock the vertex buffer
	if(Lock(FirstVertex,NumVertices) == FALSE)
		return FALSE;

	// �ƻsvertex��vertex buffer
	memcpy(m_Ptr,VertexList,NumVertices * m_VertexSize);

	if(Unlock() == FALSE)
		return FALSE;

	return TRUE;
}

BOOL cVertexBuffer::Render(unsigned long FirstVertex,unsigned long NumPrimitives,DWORD Type)
{
	if(m_Graphics->GetDeviceCOM() == NULL || m_pVB == NULL)
		return FALSE;

	// �]�wvertex buffer ���˸m���Stream
	m_Graphics->GetDeviceCOM()->SetStreamSource(0,m_pVB,m_VertexSize);
	// �]�w�ثe��vertex shader����e�إߪ�vertex buffer
	m_Graphics->GetDeviceCOM()->SetVertexShader(m_FVF);
	// ���ͦh���
	m_Graphics->GetDeviceCOM()->DrawPrimitive((D3DPRIMITIVETYPE)Type,FirstVertex,NumPrimitives);

	return TRUE;
}

BOOL cVertexBuffer::Lock(unsigned long FirstVertex,unsigned long NumVertices)
{
	if(m_pVB == NULL)
		return FALSE;
	if(FAILED(m_pVB->Lock(FirstVertex * m_VertexSize,
								NumVertices * m_VertexSize,(BYTE**) &m_Ptr,
								D3DLOCK_NOSYSLOCK | D3DLOCK_DISCARD)))
		return FALSE;

	m_Locked = FALSE;

	return TRUE;
}

BOOL cVertexBuffer::Unlock()
{
	if(m_pVB == NULL)
		return FALSE;
	if(FAILED(m_pVB->Unlock()))
		return FALSE;

	m_Locked = FALSE;

	return TRUE;
}

BOOL cVertexBuffer::IsLoaded()
{	return (m_pVB == NULL ) ? FALSE : TRUE; }

void *cVertexBuffer::GetPtr()
{	return (void*) m_Ptr;}

//	-----------------------------------------------------------------------
//
//	Class of cWorldPosistion functions
//
//	-----------------------------------------------------------------------
cWorldPosition::cWorldPosition()
{
	m_Billboard	=	FALSE;
	m_matCombine1 = m_matCombine2 = NULL;

	Move(0.0f,0.0f,0.0f);
	Rotate(0.0f,0.0f,0.0f);
	Scale(1.0f,1.0f,1.0f);

	Update();
}

// �ƻs�@��world��matrix
BOOL cWorldPosition::Copy(cWorldPosition *DestPos)
{
	DestPos->Move(m_XPos,m_YPos,m_ZPos);
	DestPos->Rotate(m_XRotation,m_YRotation,m_ZRotation);
  DestPos->Scale(m_XScale,m_YScale,m_ZScale);
	DestPos->EnableBillboard(m_Billboard);

	return TRUE;
}

// ����world�y��
BOOL cWorldPosition::Move(float XPos,float YPos,float ZPos)
{
		m_XPos	=	XPos;
		m_YPos	= YPos;
		m_ZPos	= ZPos;

		D3DXMatrixTranslation(&m_matTranslation,m_XPos,m_YPos,m_ZPos);

		return TRUE;
}

BOOL cWorldPosition::MoveRel(float XAdd, float YAdd, float ZAdd)
{
  return Move(m_XPos + XAdd, m_YPos + YAdd, m_ZPos + ZAdd);
}

// ����world�y��
BOOL cWorldPosition::Rotate(float XRot,float YRot,float ZRot)
{
	m_XRotation	=	XRot;
	m_YRotation = YRot;
	m_ZRotation = ZRot;

	D3DXMatrixRotationYawPitchRoll(&m_matRotation,m_YRotation,m_XRotation,m_ZRotation);

	return TRUE;
}

BOOL cWorldPosition::RotateRel(float XAdd, float YAdd, float ZAdd)
{
  return Rotate(m_XRotation + XAdd, m_YRotation + YAdd, m_ZRotation + ZAdd);
}

// ����world�y��
BOOL cWorldPosition::Scale(float XScale, float YScale, float ZScale)
{
  m_XScale = XScale;
  m_YScale = YScale;
  m_ZScale = ZScale;

	D3DXMatrixScaling(&m_matScale,XScale,YScale,ZScale);

  return TRUE;
}

BOOL cWorldPosition::ScaleRel(float XAdd, float YAdd, float ZAdd)
{
  return Scale(m_XScale + XAdd, m_YScale + YAdd, m_ZScale + ZAdd);
}

BOOL cWorldPosition::Update(CGraphics3DCore *Graphics)
{
	D3DXMATRIX matView,matTransposed;

	// �ϥ�billboarding matrix
	if(m_Billboard == TRUE){
		if(Graphics != NULL && Graphics->GetDeviceCOM() != NULL){
			Graphics->GetDeviceCOM()->GetTransform(D3DTS_VIEW,&matView);
			D3DXMatrixTranspose(&matTransposed,&matView);
			matTransposed._41 = matTransposed._42 = matTransposed._43 = matTransposed._14 =
				matTransposed._24 = matTransposed._34 = 0.0f;
		}else
			D3DXMatrixIdentity(&matTransposed);
	}
	
	// ���Xscaling�Mrotation matrix
	D3DXMatrixMultiply(&m_matWorld,&m_matScale,&m_matRotation);

	// �B��billboard matrix
	if(m_Billboard == TRUE)
		D3DXMatrixMultiply(&m_matWorld,&m_matWorld,&matTransposed);

	// ���X�ഫmatrix
	D3DXMatrixMultiply(&m_matWorld,&m_matWorld,&m_matTranslation);

	// ���X ��L��matrix
	if(m_matCombine1 != NULL)
		D3DXMatrixMultiply(&m_matWorld,&m_matWorld,m_matCombine1);
	if(m_matCombine2 != NULL)
		D3DXMatrixMultiply(&m_matWorld,&m_matWorld,m_matCombine2);

	return TRUE;
}

BOOL cWorldPosition::EnableBillboard(BOOL Enable)
{
  m_Billboard = Enable;
  return TRUE;
}

D3DXMATRIX *cWorldPosition::GetMatrix(CGraphics3DCore *Graphics)
{
  Update(Graphics);
  return &m_matWorld;
}

BOOL cWorldPosition::SetCombineMatrix1(D3DXMATRIX *Matrix)
{
  m_matCombine1 = Matrix;
  return TRUE;
}

BOOL cWorldPosition::SetCombineMatrix2(D3DXMATRIX *Matrix)
{
  m_matCombine2 = Matrix;
  return TRUE;
}

float cWorldPosition::GetXPos()
{
  return m_XPos;
}

float cWorldPosition::GetYPos()
{
  return m_YPos;
}

float cWorldPosition::GetZPos()
{
  return m_ZPos;
}

float cWorldPosition::GetXRotation()
{
  return m_XRotation;
}

float cWorldPosition::GetYRotation()
{
  return m_YRotation;
}

float cWorldPosition::GetZRotation()
{
  return m_ZRotation;
}

float cWorldPosition::GetXScale()
{
  return m_XScale;
}

float cWorldPosition::GetYScale()
{
  return m_YScale;
}

float cWorldPosition::GetZScale()
{
  return m_ZScale;
}

//	-----------------------------------------------------------------------
//
//	Class of cCamera functions
//
//	-----------------------------------------------------------------------
cCamera::cCamera()
{
  Move(0.0f,0.0f,0.0f);
  Rotate(0.0f,0.0f,0.0f);
  Update();
}

BOOL cCamera::Move(float XPos, float YPos, float ZPos)
{
  m_XPos = XPos;
  m_YPos = YPos;
  m_ZPos = ZPos;

  D3DXMatrixTranslation(&m_matTranslation, -m_XPos, -m_YPos, -m_ZPos);

  return TRUE;
}

BOOL cCamera::MoveRel(float XAdd, float YAdd, float ZAdd)
{
  return Move(m_XPos + XAdd, m_YPos + YAdd, m_ZPos + ZAdd);
}

BOOL cCamera::Rotate(float XRot, float YRot, float ZRot)
{
  D3DXMATRIX matXRotation, matYRotation, matZRotation;

  m_XRot = XRot;
  m_YRot = YRot;
  m_ZRot = ZRot;

  D3DXMatrixRotationX(&matXRotation, -m_XRot);
  D3DXMatrixRotationY(&matYRotation, -m_YRot);
  D3DXMatrixRotationZ(&matZRotation, -m_ZRot);

  m_matRotation = matZRotation;
  D3DXMatrixMultiply(&m_matRotation, &m_matRotation, &matYRotation);
  D3DXMatrixMultiply(&m_matRotation, &m_matRotation, &matXRotation);

  return TRUE;
}

BOOL cCamera::RotateRel(float XAdd, float YAdd, float ZAdd)
{
  return Rotate(m_XRot + XAdd, m_YRot + YAdd, m_ZRot + ZAdd);
}

// Camera����V
BOOL cCamera::Point(float XEye,float YEye,float ZEye,float XAt,float YAt,float ZAt)
{
	float XRot,YRot,XDiff,YDiff,ZDiff;

	// �p���I������
	XDiff = XAt - XEye;
	YDiff = YAt - YEye;
	ZDiff = ZAt - ZEye;
	XRot = (float)atan2(-YDiff,sqrt(XDiff*XDiff+ZDiff*ZDiff));
	YRot = (float)atan2(XDiff,ZDiff);

	Move(XEye,YEye,ZEye);
	Rotate(XRot,YRot,0.0f);

	return TRUE;
}

// ���T��funtction�O�Q�ήɶ���track Camera����V
BOOL cCamera::SetStartTrack()
{
	m_StartXPos = m_XPos;
	m_StartYPos = m_YPos;
	m_StartZPos = m_ZPos;
	m_StartXRot = m_XRot;
	m_StartYRot = m_YRot;
	m_StartZRot = m_ZRot;

	return TRUE;
}

BOOL cCamera::SetEndTrack()
{
  m_EndXPos = m_XPos;
  m_EndYPos = m_YPos;
  m_EndZPos = m_ZPos;
  m_EndXRot = m_XRot;
  m_EndYRot = m_YRot;
  m_EndZRot = m_ZRot;
  return TRUE;
}

BOOL cCamera::Track(float Time,float Length)
{
	float x,y,z,TimeOffset;

	TimeOffset = Length * Time;

	x = (m_EndXPos - m_StartXPos) / Length * TimeOffset;
	y = (m_EndYPos - m_StartYPos) / Length * TimeOffset;
	z = (m_EndZPos - m_StartZPos) / Length * TimeOffset;
	Move(m_StartXPos + x, m_StartYPos + y , m_StartZPos + z);

	x = (m_EndXRot - m_StartXRot) / Length * TimeOffset;
	y = (m_EndYRot - m_StartYRot) / Length * TimeOffset;
	z = (m_EndZRot - m_StartZRot) / Length * TimeOffset;
	Move(m_StartXRot + x, m_StartYRot + y , m_StartZRot + z);

	return TRUE;
}


BOOL cCamera::Update()
{
  D3DXMatrixMultiply(&m_matWorld, &m_matTranslation, &m_matRotation);
  return TRUE;
}

D3DXMATRIX *cCamera::GetMatrix()
{
  Update();
  return &m_matWorld;
}

float cCamera::GetXPos()
{
  return m_XPos;
}

float cCamera::GetYPos()
{
  return m_YPos;
}

float cCamera::GetZPos()
{
  return m_ZPos;
}

float cCamera::GetXRotation()
{
  return m_XRot;
}

float cCamera::GetYRotation()
{
  return m_YRot;
}

float cCamera::GetZRotation()
{
  return m_ZRot;
}

//	-----------------------------------------------------------------------
//
//	Class of cMesh functions
//
//	-----------------------------------------------------------------------
cMesh::cMesh()
{
  m_Graphics = NULL;
  m_NumMeshes = 0;
  m_Meshes = NULL;
  m_NumFrames = 0;
  m_Frames = NULL;

  m_Min.x = m_Min.y = m_Min.z = m_Max.x = m_Max.y = m_Max.z = 0.0f;
  m_Radius = 0.0f;
}

cMesh::~cMesh()
{
  Free();
}

BOOL cMesh::Load(CGraphics3DCore *Graphics,char *Filename,char *TexturePath)
{
	IDirectXFile						*pDXFile	=	NULL;
	IDirectXFileEnumObject	*pDXEnum	=	NULL;
	IDirectXFileData				*pDXData	=	NULL;
	sFrame									*TempFrame,*FramePtr;
	sMesh										*Mesh;
	D3DXMATRIX							*Matrix;
	DWORD										i;

	Free();

	// ���~check
	if((m_Graphics = Graphics) == NULL || Filename == NULL)
		return FALSE;

	// �إ��ɮ׸̪�����
	if(FAILED(DirectXFileCreate(&pDXFile)))
		return FALSE;
	// �n����template
	if(FAILED(pDXFile->RegisterTemplates((LPVOID)D3DRM_XTEMPLATES,D3DRM_XTEMPLATE_BYTES)))
	{
		pDXFile->Release();
		return FALSE;
	}
	// �إߤ@�ӦC�|����
	if(FAILED(pDXFile->CreateEnumObject((LPVOID)Filename,DXFILELOAD_FROMFILE,&pDXEnum)))
	{
		pDXFile->Release();
		return FALSE;
	}

	// �إߤ@�ӼȮɪ��ɮ�
	TempFrame = new sFrame();

	// ���R�Ҧ���mesh&frame
	while(SUCCEEDED(pDXEnum->GetNextDataObject(&pDXData))){
		ParseXFileData(pDXData,TempFrame,TexturePath);
		ReleaseCOM(pDXData);
	}

	// release used COM
	ReleaseCOM(pDXEnum);
	ReleaseCOM(pDXFile);

	// see if we should keep the tempframe as root
	if(TempFrame->m_MeshList != NULL){
		m_Frames = TempFrame;
		m_Frames->m_Name = new char[7];
		strcpy(m_Frames->m_Name,"%ROOT%");}
	else{
		// ���wroot frame��release temporary �ج[
		m_Frames = TempFrame->m_Child;
		FramePtr = m_Frames;
		while(FramePtr != NULL){
			FramePtr->m_Parent = NULL;
			FramePtr = FramePtr->m_Sibling;
		}
		TempFrame->m_Child = NULL;
		delete TempFrame;
	}

	//	���ج[��bones
	MapFramesToBones(m_Frames);

	// ����default��mesh(skin mesh)
	if((Mesh = m_Meshes) != NULL){
		while(Mesh != NULL){
			if(Mesh->m_SkinMesh != NULL){
				Matrix = new D3DXMATRIX[Mesh->m_NumBones];
				for (i=0;i< Mesh->m_NumBones;i++)
					D3DXMatrixIdentity(&Matrix[i]);
				Mesh->m_SkinMesh->UpdateSkinnedMesh(Matrix,NULL,Mesh->m_Mesh);
				delete [] Matrix;
			}
			Mesh = Mesh->m_Next;
		}
	}

	// �p�⪫��M�Ϊ����j�p
	if((Mesh = m_Meshes) != NULL){
		while(Mesh != NULL){
			m_Min.x = min(m_Min.x,Mesh->m_Min.x);
			m_Min.y = min(m_Min.y,Mesh->m_Min.y);
			m_Min.z = min(m_Min.z,Mesh->m_Min.z);
			m_Max.x = max(m_Max.x,Mesh->m_Max.x);
			m_Max.y = max(m_Max.y,Mesh->m_Max.y);
			m_Max.z = max(m_Max.z,Mesh->m_Max.z);
			m_Radius = max(m_Radius,Mesh->m_Radius);

			Mesh = Mesh->m_Next;
		}
	}

	return TRUE;
}


void cMesh::ParseXFileData(IDirectXFileData *pDataObj,sFrame *ParentFrame,char *TexturePath)
{
  IDirectXFileObject	*pSubObj	=		NULL;				// �Ψӱ���.x ������
	IDirectXFileData		*pSubData	=		NULL;				// IDirectXFileData interface to build or to access the immediate hierarchy of the data object
	IDirectXFileDataReference	*	pDataRef	=	NULL;	// A data reference object refers to a data object that is defined earlier in the file. This enables you to use the same object multiple times without repeating it in the file. 
	// define object
	const			GUID		*Type = NULL;
	char			*Name		=	NULL;
	char			Path[MAX_PATH];		

	// using a frame & subFrame
	DWORD					Size;
	sFrame				*SubFrame			=	NULL;
	sFrame				*Frame				=	NULL;
	D3DXMATRIX		*FrameMatrix	=	NULL;

	// Mash,material buffer and Adjacency(like node)
	sMesh					*Mesh		=	NULL;
	ID3DXBuffer		*MaterialBuffer	=	NULL;
	D3DXMATERIAL	*Materials			=	NULL;
	ID3DXBuffer		*Adjacency			=	NULL;
	DWORD					*AdjacencyIn		=	NULL;
	DWORD					*AdjacencyOut		=	NULL;

	DWORD					i;
	BYTE					**Ptr;


  // ���otemplate ��type
	if(FAILED(pDataObj->GetType(&Type)))
		return ;

	// ���otemplate ���W��
	if(FAILED(pDataObj->GetName(NULL,&Size)))
		return ;

	//  check the size 
	if(Size){
		if((Name = new char[Size]) != NULL)
			pDataObj->GetName(Name,&Size);
		}

  // set �l�ج[
	SubFrame	=	ParentFrame;

	// �B�zthemplate	---------------------

	// �ج[	------------------------------- 1
	if(*Type == TID_D3DRMFrame){

		// �إߤ@�ӷs���ج[���c
		Frame = new sFrame();

		// �s�J�ج[�W��
		Frame->m_Name = Name;
		Name	=		NULL;

		Frame->m_Parent	=	ParentFrame;							// ��ParentFrame����Frame��parent
		Frame->m_Sibling	=	ParentFrame->m_Child;		// ��ParentFrame���lframe����frame��sibling
		ParentFrame->m_Child = Frame;								// �A��frame����ParentFrame��child

		// ����Frame#
		m_NumFrames++;

		// ��Frame���w��SubFrame
		SubFrame	=	 Frame;
	}

  // �ج[�ഫmartrix, look "IDirectXFileData->GetData"
	if(*Type == TID_D3DRMFrameTransformMatrix){
		if(FAILED(pDataObj->GetData(NULL,&Size,(PVOID*)&FrameMatrix)))
			return ;
		// ���o�Ӧ۩� .x����matrix
		ParentFrame->m_matOriginal = *FrameMatrix;
	}

  // ���� -------------------------------- 2
	if(*Type == TID_D3DRMMesh){
		// �P�_mesh�O�_�w�g���J
		if(m_Meshes == NULL || m_Meshes->FindMesh(Name)==NULL){
			// �إߤ@�ӷs��mesh���c
			Mesh = new sMesh();

			// save the name
			Mesh->m_Name= Name;
			Name = NULL;

			// ���JMesh ���
			if(FAILED(D3DXLoadSkinMeshFromXof(pDataObj,0,m_Graphics->GetDeviceCOM(),
								&Adjacency,
								&MaterialBuffer,&Mesh->m_NumMaterials,
								&Mesh->m_BoneNames,&Mesh->m_BoneTransforms,
								&Mesh->m_SkinMesh))){
				delete Mesh;
				return ;
			}

     // �p��box�d��M�Ϊ�
			if(SUCCEEDED(Mesh->m_SkinMesh->LockVertexBuffer(D3DLOCK_READONLY,(BYTE**)&Ptr))){
				// �p�� box
				D3DXComputeBoundingBox((void*)Ptr,Mesh->m_SkinMesh->GetNumVertices(),
				Mesh->m_SkinMesh->GetFVF(),&Mesh->m_Min,&Mesh->m_Max);
				// �p�� sphere
				D3DXComputeBoundingSphere((void*)Ptr,Mesh->m_SkinMesh->GetNumVertices(),
				Mesh->m_SkinMesh->GetFVF(),&D3DXVECTOR3(0.0F,0.0F,0.0F),&Mesh->m_Radius);
				// unlock vertexbuffer
				Mesh->m_SkinMesh->UnlockVertexBuffer();
			}

			// �P�_�O�_��bone or regular ��mesh,�A�i���ഫmesh
			if(!(Mesh->m_NumBones = Mesh->m_SkinMesh->GetNumBones())){
				// �i��W�hmesh�ഫ
				Mesh->m_SkinMesh->GetOriginalMesh(&Mesh->m_Mesh);
				ReleaseCOM(Mesh->m_SkinMesh);
			}else{
				// �إ�bone matrix arry(�����x�}m_Matrices)
				Mesh->m_Matrices = new D3DXMATRIX[Mesh->m_NumBones];
				for (i=0;i<Mesh->m_NumBones;i++)
					D3DXMatrixIdentity(&Mesh->m_Matrices[i]);

				// �إ�frame mapping matrix array
				Mesh->m_FrameMatrices = new D3DXMATRIX*[Mesh->m_NumBones];
				for (i=0;i<Mesh->m_NumBones;i++)
					Mesh->m_FrameMatrices[i] = NULL;

				// ���obone matrices������
				Mesh->m_BoneMatrices = (D3DXMATRIX*)Mesh->m_BoneTransforms->GetBufferPointer();

				// �վ�adjacency
				AdjacencyIn	=	(DWORD*)Adjacency->GetBufferPointer();
				AdjacencyOut= new DWORD[Mesh->m_SkinMesh->GetNumFaces()*3];

				// ����Skin mesh���� 
				if(FAILED(Mesh->m_SkinMesh->GenerateSkinnedMesh(
					D3DXMESH_WRITEONLY,0.0f,
					AdjacencyIn,AdjacencyOut,NULL,NULL,&Mesh->m_Mesh))){
					// �ഫregular mesh if error
					Mesh->m_SkinMesh->GetOriginalMesh(&Mesh->m_Mesh);
					ReleaseCOM(Mesh->m_SkinMesh);
					Mesh->m_NumBones = 0;
				}

				delete [] AdjacencyOut;
				ReleaseCOM(Adjacency);
			}

      // ���J����
			if(!Mesh->m_NumMaterials){
				// �إߤ@��defualt
				Mesh->m_Materials	=	new D3DMATERIAL8[1];
				Mesh->m_Textures	=	new LPDIRECT3DTEXTURE8[1];

				ZeroMemory(Mesh->m_Materials,sizeof(D3DMATERIAL8));
				// �ŧi���誺Diffuse�A�A�ΰʺA�t�m��ambient,specular..etc.
				Mesh->m_Materials[0].Diffuse.r = 1.0f;
				Mesh->m_Materials[0].Diffuse.g = 1.0f;
				Mesh->m_Materials[0].Diffuse.b = 1.0f;
				Mesh->m_Materials[0].Diffuse.a = 1.0f;
				Mesh->m_Materials[0].Ambient = Mesh->m_Materials[0].Diffuse;
				Mesh->m_Materials[0].Specular= Mesh->m_Materials[0].Diffuse;
				Mesh->m_Textures[0] = NULL;

				Mesh->m_NumMaterials = 1;				// ����s���]�w�� 1
			}else{
				// ���J����
				Materials = (D3DXMATERIAL*)MaterialBuffer->GetBufferPointer();
				Mesh->m_Materials = new D3DMATERIAL8[Mesh->m_NumMaterials];
				Mesh->m_Textures  = new LPDIRECT3DTEXTURE8[Mesh->m_NumMaterials];

				for(i=0;i<Mesh->m_NumMaterials;i++){
					Mesh->m_Materials[i] = Materials[i].MatD3D;
					Mesh->m_Materials[i].Ambient = Mesh->m_Materials[i].Diffuse;

					// �سy�@�ӯ��zPATH��LOAD IT
					sprintf(Path,"%s%s",TexturePath,Materials[i].pTextureFilename);
					if(FAILED(D3DXCreateTextureFromFile(m_Graphics->GetDeviceCOM(),
						Path,&Mesh->m_Textures[i]))){
						Mesh->m_Textures[i] =  NULL;
					}
				}
			}

			// release���褺�e
			ReleaseCOM(MaterialBuffer);

      // link in mesh
      Mesh->m_Next = m_Meshes;
      m_Meshes = Mesh;
      m_NumMeshes++;
    } else {
      // Find mesh in list
      Mesh = m_Meshes->FindMesh(Name);
    }

    // ���[Mesh��ج[	-----------------------	4
    if(Mesh != NULL)
      ParentFrame->AddMesh(Mesh);
  }

	// �ֽ�skin �ʵe �M �ʧ@
	if(*Type == TID_D3DRMAnimationSet || *Type == TID_D3DRMAnimation || *Type == TID_D3DRMAnimationKey){
		delete [] Name;
		return ;
	}

  // Release name buffer
  delete [] Name;

  // scan�O�i��templates	-----------------------	5
	while(SUCCEEDED(pDataObj->GetNextObject(&pSubObj))){
		// �B�z�O�i��references
		if(SUCCEEDED(pSubObj->QueryInterface(IID_IDirectXFileDataReference,(void**)&pDataRef))){
			if(SUCCEEDED(pDataRef->Resolve(&pSubData))){
			ParseXFileData(pSubData,SubFrame,TexturePath);
			ReleaseCOM(pSubData);
			}
			ReleaseCOM(pDataRef);
		}

		// �B�z�Dreferences �O�i��templates
		if(SUCCEEDED(pSubObj->QueryInterface(IID_IDirectXFileData,(void**)&pSubData))){
			ParseXFileData(pSubData,SubFrame,TexturePath);
			ReleaseCOM(pSubData);
		}
		ReleaseCOM(pSubObj);
	}

  return;
}

// �۰t(match) bone�Mframe�ഫ��matrix
void cMesh::MapFramesToBones(sFrame *Frame)
{
  sMesh *Mesh;
	DWORD	i;
	char  **Name;
	
	if(Frame == NULL || Frame->m_Name == NULL)
		return ;

	// �gmeshes��scan bone �������t��
	Mesh = m_Meshes;
	while(Mesh != NULL){
		if(Mesh->m_NumBones && Mesh->m_BoneNames != NULL && Mesh->m_Matrices != NULL 
			&& Mesh->m_FrameMatrices != NULL){
			Name = (char**)Mesh->m_BoneNames->GetBufferPointer(); // good way
			for (i=0;i<Mesh->m_NumBones;i++){
				if(!strcmp(Frame->m_Name,Name[i])){
					Mesh->m_FrameMatrices[i] = &Frame->m_matCombined;
					break;
				}
			}
		}
		Mesh = Mesh->m_Next;
	}
	
	// scan child's frames
	MapFramesToBones(Frame->m_Child);
	// scan sibling frames
	MapFramesToBones(Frame->m_Sibling);
}

BOOL cMesh::Free()
{
  m_Graphics = NULL;
 
  m_NumMeshes = 0;
  delete m_Meshes;
  m_Meshes = NULL;

  m_NumFrames = 0;
  delete m_Frames;
  m_Frames = NULL;

  m_Min.x = m_Min.y = m_Min.z = m_Max.x = m_Max.y = m_Max.z = 0.0f;
  m_Radius = 0.0f;

  return TRUE;
}

BOOL cMesh::IsLoaded()
{
  if(m_Meshes != NULL && m_Frames != NULL)
    return TRUE;
  return FALSE;
}

long cMesh::GetNumFrames()
{
  return m_NumFrames;
}

sFrame *cMesh::GetParentFrame()
{
  return m_Frames;
}

sFrame *cMesh::GetFrame(char *Name)
{
  if(m_Frames == NULL)
    return NULL;
  return m_Frames->FindFrame(Name);
}

long cMesh::GetNumMeshes()
{
  return m_NumMeshes;
}

sMesh *cMesh::GetParentMesh()
{
  return m_Meshes;
}

sMesh *cMesh::GetMesh(char *Name)
{
  if(m_Meshes == NULL)
    return NULL;
  return m_Meshes->FindMesh(Name);
}

BOOL cMesh::GetBounds(float *MinX, float *MinY, float *MinZ, float *MaxX, float *MaxY, float *MaxZ, float *Radius)
{
  if(MinX != NULL)
    *MinX = m_Min.x;
  if(MinY != NULL)
    *MinY = m_Min.y;
  if(MinZ != NULL)
    *MinZ = m_Min.z;

  if(MaxX != NULL)
    *MaxX = m_Max.x;
  if(MaxY != NULL)
    *MaxY = m_Max.y;
  if(MaxZ != NULL)
    *MaxZ = m_Max.z;

  if(Radius != NULL)
    *Radius = m_Radius;

  return TRUE;
}

//	-----------------------------------------------------------------------
//
//	Class of cObject functions
//
//	-----------------------------------------------------------------------
cObject::cObject()
{
  m_Graphics       = NULL;
  m_Mesh           = NULL;
  m_AnimationSet   = NULL;
}

cObject::~cObject()
{
  Free();
}

BOOL cObject::Create(CGraphics3DCore *Graphics, cMesh *Mesh)
{
  if((m_Graphics = Graphics) == NULL)
    return FALSE;
  m_Mesh = Mesh;

  Move(0.0f, 0.0f, 0.0f);
  Rotate(0.0f, 0.0f, 0.0f);
  Scale(1.0f, 1.0f, 1.0f);

  return TRUE;
}

BOOL cObject::Free()
{
  m_Graphics     = NULL;
  m_Mesh         = NULL;
  m_AnimationSet = NULL;

  return TRUE;
}

BOOL cObject::EnableBillboard(BOOL Enable)
{
	m_Pos.EnableBillboard(Enable);
	return TRUE;
}

BOOL cObject::AttachToObject(cObject *Object,char *FrameName)
{
	sFrame *Frame;

	if(Object == NULL || Object->m_Mesh == NULL){
		m_Pos.SetCombineMatrix1(NULL);
		m_Pos.SetCombineMatrix2(NULL);
	}else{
		Frame = Object->m_Mesh->GetFrame(FrameName);
		if(Frame==NULL){
			m_Pos.SetCombineMatrix1(NULL);
			m_Pos.SetCombineMatrix2(NULL);
		}else{
			m_Pos.SetCombineMatrix1(&Frame->m_matCombined);
			m_Pos.SetCombineMatrix2(Object->m_Pos.GetMatrix());
		}
	}
	return TRUE;
}

BOOL cObject::Move(float XPos, float YPos, float ZPos)
{
  return m_Pos.Move(XPos, YPos, ZPos);
}
BOOL cObject::MoveRel(float XAdd, float YAdd, float ZAdd)
{
  return m_Pos.MoveRel(XAdd, YAdd, ZAdd);
}

BOOL cObject::Rotate(float XRot, float YRot, float ZRot)
{
  return m_Pos.Rotate(XRot, YRot, ZRot);
}
BOOL cObject::RotateRel(float XAdd, float YAdd, float ZAdd)
{
  return m_Pos.RotateRel(XAdd, YAdd, ZAdd);
}

BOOL cObject::Scale(float XScale, float YScale, float ZScale)
{
  return m_Pos.Scale(XScale, YScale, ZScale);
}
BOOL cObject::ScaleRel(float XAdd, float YAdd, float ZAdd)
{
  return m_Pos.ScaleRel(XAdd, YAdd, ZAdd);
}

D3DXMATRIX *cObject::GetMatrix()
{
  return m_Pos.GetMatrix(); 
}

BOOL cObject::SetMesh(cMesh *Mesh)
{
  m_Mesh = Mesh;
  return TRUE;
}
cMesh *cObject::GetMesh()
{
  return m_Mesh;
}
// set/get/reset animation
BOOL cObject::SetAnimation(cAnimation *Animation, char *Name, unsigned long StartTime)
{
  m_StartTime = StartTime;
  if(Animation == NULL)
    m_AnimationSet = NULL;
  else
    m_AnimationSet = Animation->GetAnimationSet(Name);

  return TRUE;
}

char *cObject::GetAnimation()
{
  if(m_AnimationSet == NULL)
    return NULL;
  return m_AnimationSet->m_Name;
}

BOOL cObject::ResetAnimation(unsigned long StartTime)
{
  m_StartTime = StartTime;
  return TRUE;
}

float cObject::GetXPos()
{
  return m_Pos.GetXPos();
}
float cObject::GetYPos()
{
  return m_Pos.GetYPos();
}
float cObject::GetZPos()
{
  return m_Pos.GetZPos();
}

float cObject::GetXRotation()
{
  return m_Pos.GetXRotation();
}
float cObject::GetYRotation()
{
  return m_Pos.GetYRotation();
}
float cObject::GetZRotation()
{
  return m_Pos.GetZRotation();
}

float cObject::GetXScale()
{
  return m_Pos.GetXScale();
}
float cObject::GetYScale()
{
  return m_Pos.GetYScale();
}
float cObject::GetZScale()
{
  return m_Pos.GetZScale();
}

BOOL cObject::GetBounds(float *MinX, float *MinY, float *MinZ, float *MaxX, float *MaxY, float *MaxZ, float *Radius)
{
  float Length, XScale, YScale, ZScale;

  if(m_Mesh == NULL)
    return FALSE;

  m_Mesh->GetBounds(MinX, MinY, MinZ, MaxX, MaxY, MaxZ, Radius);

  // Scale bounds
  XScale = m_Pos.GetXScale();
  YScale = m_Pos.GetYScale();
  ZScale = m_Pos.GetZScale();

  if(MinX != NULL)   *MinX *= XScale;
  if(MinY != NULL)   *MinY *= YScale;
  if(MinZ != NULL)   *MinZ *= ZScale;

  if(MaxX != NULL)   *MaxX *= XScale;
  if(MaxY != NULL)   *MaxY *= YScale;
  if(MaxZ != NULL)   *MaxZ *= ZScale;

  if(Radius != NULL) {
    Length = (float)sqrt(XScale*XScale+YScale*YScale+ZScale*ZScale);
    (*Radius) *= Length;
  }

  return TRUE;
}

BOOL cObject::UpdateAnimation(unsigned long Time,BOOL Smooth)
{
	if(m_AnimationSet != NULL){
		m_Mesh->GetParentFrame()->ResetMatrices();
		m_AnimationSet->Update(Time - m_StartTime,Smooth);
	}
	return TRUE;
}

BOOL cObject::AnimationComplete(unsigned long Time)
{
	if(m_AnimationSet == NULL)
		return TRUE;
	if((Time - m_StartTime) >= m_AnimationSet->m_Length)
		return TRUE;
	return FALSE;
}

BOOL cObject::Update()
{
  // Update the world position
  m_Pos.Update(m_Graphics);
  return TRUE;
}

BOOL cObject::Render()
{
	D3DXMATRIX Matrix;

	// ���~�ˬd
	if(m_Graphics == NULL || m_Mesh == NULL || m_Mesh->GetParentFrame() == NULL || m_Mesh->GetParentMesh() == NULL)
		return FALSE;

	// ��s����matrix
	Update();

	// ��sframe matrices
	D3DXMatrixIdentity(&Matrix);
	UpdateFrame(m_Mesh->GetParentFrame(),&Matrix);

	// �ƻsframe matrices��bone matrices
	m_Mesh->GetParentMesh()->CopyFrameToBoneMatrices();
	// ø������frame��meshes
	DrawFrame(m_Mesh->GetParentFrame());

	return TRUE;
}

void cObject::UpdateFrame(sFrame *Frame,D3DXMATRIX *Matrix)
{
	if (Frame==NULL)
		return ;
	// �p��frame matrix based on animation
	if(m_AnimationSet==NULL)
		D3DXMatrixMultiply(&Frame->m_matCombined,&Frame->m_matOriginal,Matrix);
	else
		D3DXMatrixMultiply(&Frame->m_matCombined,&Frame->m_matTransformed,Matrix);

	// ��schild frames
	UpdateFrame(Frame->m_Child,&Frame->m_matCombined);

	// ��ssibling frames
	UpdateFrame(Frame->m_Sibling,Matrix);
}

void cObject::DrawFrame(sFrame *Frame)
{
	sFrameMeshList	*List;
	sMesh						*Mesh;
	D3DXMATRIX			matWorld;
	DWORD						i;

	if(Frame == NULL)
		return ;
	// �P�_ �ج[�O�_�����[������C
	if((List = Frame->m_MeshList) != NULL)
	{
		while(List != NULL)
		{
			// mesh to draw
			if((Mesh = List->m_Mesh) != NULL)
			{
				// �Y�ϥ�bones �M �]�wworld matrix �Ҳ��ͪ�mesh
				if(Mesh->m_NumBones && Mesh->m_SkinMesh != NULL)
				{
					Mesh->m_SkinMesh->UpdateSkinnedMesh(Mesh->m_Matrices,NULL,Mesh->m_Mesh);
					// �]�w����world���ഫ
					m_Graphics->GetDeviceCOM()->SetTransform(D3DTS_WORLD,m_Pos.GetMatrix());
				}else{
					// �]�wframe��world�ഫmatrix
					D3DXMatrixMultiply(&matWorld,&Frame->m_matCombined,m_Pos.GetMatrix());
					m_Graphics->GetDeviceCOM()->SetTransform(D3DTS_WORLD,&matWorld);
				}

				// �N����ø��mesh�W
				for(i=0;i<Mesh->m_NumMaterials;i++)
				{
					// ��ø�X����alpha��(0.0f)��
					if(Mesh->m_Materials[i].Diffuse.a != 0.0f){
						m_Graphics->GetDeviceCOM()->SetMaterial(&Mesh->m_Materials[i]);
						m_Graphics->GetDeviceCOM()->SetTexture(0,Mesh->m_Textures[i]);

						// �Ұ�alpha�ӲV�Xbased����誺alpha
						if(Mesh->m_Materials[i].Diffuse.a != 1.0f)
							m_Graphics->EnableAlphaBlending(TRUE,D3DBLEND_SRCCOLOR,D3DBLEND_ONE);

						Mesh->m_Mesh->DrawSubset(i);

						// �h�� alpha blending based �����W
						if(Mesh->m_Materials[i].Diffuse.a != 1.0f)
							m_Graphics->EnableAlphaBlending(FALSE);
					}
				}
			}
			// �U�@��mesh��C
			List = List->m_Next;
		}
	}
	//�U�@��child mesh,sibling
	DrawFrame(Frame->m_Child);
	DrawFrame(Frame->m_Sibling);
}
//	-----------------------------------------------------------------------
//
//	Class of cAnimation functions
//
//	-----------------------------------------------------------------------
cAnimation::cAnimation()
{
  m_NumAnimations = 0;
  m_AnimationSet  = NULL;
}

cAnimation::~cAnimation()
{
  Free();
}

BOOL cAnimation::Load(char *Filename, cMesh *MapMesh)
{
  IDirectXFile           *pDXFile = NULL;
  IDirectXFileEnumObject *pDXEnum = NULL;
  IDirectXFileData       *pDXData = NULL;
  
  // Free a prior animation
  Free();

  // Error checking
  if(Filename == NULL)
    return FALSE;

  // Create the file object
  if(FAILED(DirectXFileCreate(&pDXFile)))
    return FALSE;

  // Register the templates
  if(FAILED(pDXFile->RegisterTemplates((LPVOID)D3DRM_XTEMPLATES, D3DRM_XTEMPLATE_BYTES))) {
    pDXFile->Release();
    return FALSE;
  }

  // Create an enumeration object
  if(FAILED(pDXFile->CreateEnumObject((LPVOID)Filename, DXFILELOAD_FROMFILE, &pDXEnum))) {
    pDXFile->Release();
    return FALSE;
  }

  // Loop through all objects looking for the animation
  while(SUCCEEDED(pDXEnum->GetNextDataObject(&pDXData))) {
    ParseXFileData(pDXData, NULL, NULL);
    ReleaseCOM(pDXData);
  }

  ReleaseCOM(pDXEnum);
  ReleaseCOM(pDXFile);

  // Map the animation to the supplied mesh (if any)
  if(MapMesh != NULL)
    MapToMesh(MapMesh);

  return TRUE;
}

void cAnimation::ParseXFileData(IDirectXFileData *pDataObj, sAnimationSet *ParentAnim, sAnimation *CurrentAnim)
{
  IDirectXFileObject *pSubObj  = NULL;
  IDirectXFileData   *pSubData = NULL;
  IDirectXFileDataReference *pDataRef = NULL;
  const GUID      *Type = NULL;
  char            *Name = NULL;
  DWORD            Size;
  PBYTE           *DataPtr;

  DWORD            i;

  DWORD              KeyType, NumKeys, Time;
  sXFileRotateKey   *RotKey;
  sXFileScaleKey    *ScaleKey;
  sXFilePositionKey *PosKey;
  sXFileMatrixKey   *MatKey;

  sAnimationSet   *SubAnimSet = NULL;
  sAnimation      *SubAnim    = NULL;

  sAnimation      *Anim = NULL;
  sAnimationSet   *AnimSet = NULL;
  
  // Get the template type
  if(FAILED(pDataObj->GetType(&Type)))
    return;

  // Get the template name (if any)
  if(FAILED(pDataObj->GetName(NULL, &Size)))
    return;
  if(Size) {
    if((Name = new char[Size]) != NULL)
      pDataObj->GetName(Name, &Size);
  }

  // Give template a default name if none found
  if(Name == NULL) {
    if((Name = new char[9]) == NULL)
      return;
    strcpy(Name, "$NoName$");
  }

  // Set sub frame parent
  SubAnimSet = ParentAnim;
  SubAnim    = CurrentAnim;

  // Process the templates

  // Process an animation set
  if(*Type == TID_D3DRMAnimationSet) {
    // Create a animation set structure
    if((AnimSet = new sAnimationSet()) == NULL)
      return;

    // Set the name
    AnimSet->m_Name = Name;
    Name = NULL;

    // Link into the animation set list
    AnimSet->m_Next = m_AnimationSet;
    m_AnimationSet = AnimSet;

    // Set as new parent
    SubAnimSet = AnimSet;
  }

  // Process an animation
  if(*Type == TID_D3DRMAnimation && ParentAnim != NULL) {
    // Create an animation structure
    if((Anim = new sAnimation()) == NULL)
      return;

    // Set the name
    Anim->m_Name = Name;
    Name = NULL;

    // Link into the animation list
    Anim->m_Next = ParentAnim->m_Animation;
    ParentAnim->m_Animation = Anim;

    SubAnim = Anim;
  }

  // Process an animation key
  if(*Type == TID_D3DRMAnimationKey && CurrentAnim != NULL) {
    // Load in this animation's key data
    if(FAILED(pDataObj->GetData(NULL, &Size, (PVOID*)&DataPtr)))
      return;

    KeyType = ((DWORD*)DataPtr)[0];
    NumKeys = ((DWORD*)DataPtr)[1];

    switch(KeyType) {
      case 0:
        delete [] CurrentAnim->m_RotateKeys;
        if((CurrentAnim->m_RotateKeys = new sRotateKey[NumKeys]) == NULL)
          return;
        CurrentAnim->m_NumRotateKeys = NumKeys;
        RotKey = (sXFileRotateKey*)((char*)DataPtr + (sizeof(DWORD) * 2));
        for(i=0;i<NumKeys;i++) {
          CurrentAnim->m_RotateKeys[i].Time = RotKey->Time;
          CurrentAnim->m_RotateKeys[i].Quaternion.x = -RotKey->x;
          CurrentAnim->m_RotateKeys[i].Quaternion.y = -RotKey->y;
          CurrentAnim->m_RotateKeys[i].Quaternion.z = -RotKey->z;
          CurrentAnim->m_RotateKeys[i].Quaternion.w =  RotKey->w;

          if(RotKey->Time > ParentAnim->m_Length)
            ParentAnim->m_Length = RotKey->Time;

          RotKey += 1;
        }

        break;

      case 1: 
        delete [] CurrentAnim->m_ScaleKeys;
        if((CurrentAnim->m_ScaleKeys = new sScaleKey[NumKeys]) == NULL)
          return;
        CurrentAnim->m_NumScaleKeys = NumKeys;
        ScaleKey = (sXFileScaleKey*)((char*)DataPtr + (sizeof(DWORD) * 2));
        for(i=0;i<NumKeys;i++) {
          CurrentAnim->m_ScaleKeys[i].Time  = ScaleKey->Time;
          CurrentAnim->m_ScaleKeys[i].Scale = ScaleKey->Scale;

          if(ScaleKey->Time > ParentAnim->m_Length)
            ParentAnim->m_Length = ScaleKey->Time;

          ScaleKey += 1;
        }

        // Calculate the interpolation values
        if(NumKeys > 1) {
          for(i=0;i<NumKeys-1;i++) {
            CurrentAnim->m_ScaleKeys[i].ScaleInterpolation = CurrentAnim->m_ScaleKeys[i+1].Scale - CurrentAnim->m_ScaleKeys[i].Scale;
            Time = CurrentAnim->m_ScaleKeys[i+1].Time - CurrentAnim->m_ScaleKeys[i].Time;
            if(!Time)
              Time = 1;
            CurrentAnim->m_ScaleKeys[i].ScaleInterpolation /= (float)Time;
          }
        }

        break;
    
      case 2:
        delete [] CurrentAnim->m_PositionKeys;
        if((CurrentAnim->m_PositionKeys = new sPositionKey[NumKeys]) == NULL)
          return;
        CurrentAnim->m_NumPositionKeys = NumKeys;
        PosKey = (sXFilePositionKey*)((char*)DataPtr + (sizeof(DWORD) * 2));
        for(i=0;i<NumKeys;i++) {
          CurrentAnim->m_PositionKeys[i].Time = PosKey->Time;
          CurrentAnim->m_PositionKeys[i].Pos  = PosKey->Pos;

          if(PosKey->Time > ParentAnim->m_Length)
            ParentAnim->m_Length = PosKey->Time;

          PosKey += 1;
        }

        // Calculate the interpolation values
        if(NumKeys > 1) {
          for(i=0;i<NumKeys-1;i++) {
            CurrentAnim->m_PositionKeys[i].PosInterpolation = CurrentAnim->m_PositionKeys[i+1].Pos - CurrentAnim->m_PositionKeys[i].Pos;
            Time = CurrentAnim->m_PositionKeys[i+1].Time - CurrentAnim->m_PositionKeys[i].Time;
            if(!Time)
              Time = 1;
            CurrentAnim->m_PositionKeys[i].PosInterpolation /= (float)Time;
          }
        }

        break;

      case 4:
        delete [] CurrentAnim->m_MatrixKeys;
        if((CurrentAnim->m_MatrixKeys = new sMatrixKey[NumKeys]) == NULL)
          return;
        CurrentAnim->m_NumMatrixKeys = NumKeys;
        MatKey = (sXFileMatrixKey*)((char*)DataPtr + (sizeof(DWORD) * 2));
        for(i=0;i<NumKeys;i++) {
          CurrentAnim->m_MatrixKeys[i].Time   = MatKey->Time;
          CurrentAnim->m_MatrixKeys[i].Matrix = MatKey->Matrix;

          if(MatKey->Time > ParentAnim->m_Length)
            ParentAnim->m_Length = MatKey->Time;

          MatKey+=1;
        }

        // Calculate the interpolation matrices
        if(NumKeys > 1) {
          for(i=0;i<NumKeys-1;i++) {
            CurrentAnim->m_MatrixKeys[i].MatInterpolation = CurrentAnim->m_MatrixKeys[i+1].Matrix - CurrentAnim->m_MatrixKeys[i].Matrix;
            Time = CurrentAnim->m_MatrixKeys[i+1].Time - CurrentAnim->m_MatrixKeys[i].Time;
            if(!Time)
              Time = 1;
            CurrentAnim->m_MatrixKeys[i].MatInterpolation /= (float)Time;
          }
        }
        break;
    }
  }

  // Process animation options
  if(*Type == TID_D3DRMAnimationOptions && CurrentAnim != NULL) {
    // Load in this animation's options
    if(FAILED(pDataObj->GetData(NULL, &Size, (PVOID*)&DataPtr)))
      return;

    // Process looping information
    if(!((DWORD*)DataPtr)[0])
      CurrentAnim->m_Loop = TRUE;
    else
      CurrentAnim->m_Loop = FALSE;

    // Process linear information
    if(!((DWORD*)DataPtr)[1])
      CurrentAnim->m_Linear = FALSE;
    else
      CurrentAnim->m_Linear = TRUE;
  }

  // Process a frame reference
  if(*Type == TID_D3DRMFrame && CurrentAnim != NULL) {
    CurrentAnim->m_FrameName = Name;
    Name = NULL;

    // Don't enumerate child templates
    return;
  }

  // Release name buffer
  delete [] Name;

  // Scan for embedded templates
  while(SUCCEEDED(pDataObj->GetNextObject(&pSubObj))) {

    // Process embedded references
    if(SUCCEEDED(pSubObj->QueryInterface(IID_IDirectXFileDataReference, (void**)&pDataRef))) {
      if(SUCCEEDED(pDataRef->Resolve(&pSubData))) {
        ParseXFileData(pSubData, SubAnimSet, SubAnim);
        ReleaseCOM(pSubData);
      }
      ReleaseCOM(pDataRef);
    }

    // Process non-referenced embedded templates
    if(SUCCEEDED(pSubObj->QueryInterface(IID_IDirectXFileData, (void**)&pSubData))) {
      ParseXFileData(pSubData, SubAnimSet, SubAnim);
      ReleaseCOM(pSubData);
    }
    ReleaseCOM(pSubObj);
  }
}

BOOL cAnimation::Free()
{
  delete m_AnimationSet;
  m_AnimationSet  = NULL;
  m_NumAnimations = 0;

  return TRUE;
}

BOOL cAnimation::IsLoaded()
{
  if(m_AnimationSet == NULL)
    return FALSE;
  return TRUE;
}

BOOL cAnimation::MapToMesh(cMesh *Mesh)
{
  sAnimationSet *AnimSet;
  sAnimation    *Anim;

  // Make sure there's a mesh to work with
  if(Mesh == NULL)
    return FALSE;

  // Assign links to frames by name
  if((AnimSet = m_AnimationSet) == NULL)
    return FALSE;

  // Scan through all animation sets
  while(AnimSet != NULL) {
    // Scan through all animations
    Anim = AnimSet->m_Animation;
    while(Anim != NULL) {
      // Find the matching frame from Mesh
      Anim->m_Frame = Mesh->GetFrame(Anim->m_FrameName);
      Anim = Anim->m_Next;
    }
    AnimSet = AnimSet->m_Next;
  }

  return TRUE;
}

long cAnimation::GetNumAnimations()
{
  return m_NumAnimations;
}

sAnimationSet *cAnimation::GetAnimationSet(char *Name)
{
  if(m_AnimationSet == NULL)
    return NULL;
  return m_AnimationSet->FindSet(Name);
}

BOOL cAnimation::SetLoop(BOOL ToLoop, char *Name)
{
  sAnimationSet *AnimSet;
  sAnimation    *Anim;

  if((AnimSet = GetAnimationSet(Name)) == NULL)
    return FALSE;

  Anim = AnimSet->m_Animation;
  while(Anim != NULL) {
    Anim->m_Loop = ToLoop;
    Anim = Anim->m_Next;
  }

  return TRUE;
}

unsigned long cAnimation::GetLength(char *Name)
{
  sAnimationSet *AnimSet;

  if((AnimSet = GetAnimationSet(Name)) == NULL)
    return 0;
  return AnimSet->m_Length;
}
