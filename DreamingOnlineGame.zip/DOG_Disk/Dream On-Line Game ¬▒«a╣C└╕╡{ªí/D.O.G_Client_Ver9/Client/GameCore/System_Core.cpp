
#include "..\Common\Global.h"

/////////////////////////////////////////////////////////////////////////////////
//
// CGameSysCore Functions	
// ------------------------------------------------------------------------------
//
// ��l�Ƶ����򥻬[�c

void test()
{
// testing singleton -----------
//	CGameSysCoreMgt::GetSingleton().AdjustWindow(1280,960);
//	g_Core.AdjustWindow(800,600);

	MyWidgetManager aa;
//	aa.show();

}

void CGameSysCoreMgt::Create()
{
	// �x�s instatnce handle
  g_pGameSysCore = this;

  // ���instance handle
  m_hInst = GetModuleHandle(NULL);

  // �]�w window class and caption
	strcpy(m_Class,"GameSysEngine");
	strcpy(m_Caption,"GameSysEngine");

  // �]�w window style, position, width, height
  m_Style  = 	WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
  m_XPos   = 0;		m_YPos   = 0;
  m_Width  = 0;		m_Height = 0;

   // �]�w WNDCLASSEX ���c
  ZeroMemory(&m_Winclassex,sizeof(m_Winclassex));	
	
  m_Winclassex.cbSize					= sizeof(WNDCLASSEX);
  m_Winclassex.style					= CS_CLASSDC;
  m_Winclassex.lpfnWndProc		= cGameSysCoreWindowProc;
  m_Winclassex.cbClsExtra			= 0;
  m_Winclassex.cbWndExtra			= 0;
  m_Winclassex.hInstance			= m_hInst;
  m_Winclassex.hIcon					= LoadIcon(NULL,IDI_APPLICATION);
  m_Winclassex.hCursor				= LoadCursor(NULL,IDC_ARROW);
  m_Winclassex.hbrBackground	= (HBRUSH)GetStockObject(WHITE_BRUSH);
  m_Winclassex.lpszMenuName   = NULL;
  m_Winclassex.lpszClassName	= m_Class;
  m_Winclassex.hIconSm				= LoadIcon(NULL,IDI_APPLICATION);
}
// ------------------------------------------------------------------------------
//
// �g�������[�c
void CGameSysCoreMgt::Destory()
{	PostQuitMessage(0);}

// ------------------------------------------------------------------------------
//
// ���������messageloop
BOOL CGameSysCoreMgt::Run()
{
	MSG Msg;

	// ���U�������O
	cassert(RegisterClassEx(&m_Winclassex),"���U��������..");

	// �إߵ���
	cassert(m_hWnd = CreateWindow(
		m_Class,m_Caption,m_Style,
		m_XPos,m_YPos,
		m_Width,m_Height,
		NULL,NULL,m_hInst,NULL),"�غc��������..");
// 575
/*	hLB_Output = CreateWindowEx(
		WS_EX_CLIENTEDGE,
		"LISTBOX",
		NULL,
		WS_CHILD | WS_VISIBLE | LBS_NOTIFY | WS_VSCROLL,
		0,
		0,
		GetSystemMetrics(SM_CXMAXIMIZED),
		GetSystemMetrics(SM_CYMAXIMIZED),
		m_hWnd,(HMENU)IDC_hLB_Output,m_hInst,NULL);	

// Edit field to enter chat messages into
	hEB_InputField = CreateWindowEx(
		WS_EX_CLIENTEDGE,
		"EDIT",NULL,
		WS_CHILD | WS_VISIBLE | WS_BORDER | ES_LEFT | ES_AUTOVSCROLL | ES_MULTILINE,
		0,
		0,
		180,			// bar length
		20,				// bar width
		m_hWnd,(HMENU)IDC_hEB_InputField,m_hInst,NULL);
*/
	ShowWindow(m_hWnd,SW_NORMAL);					// ���,��s����
	UpdateWindow(m_hWnd);			
	AdjustWindow(m_Width,m_Height);				// �վ�Client area

	CoInitialize(NULL);										// ��l�� COM

	 // �i���l��
  if(Init() == FALSE)  {
		ErrorMsg(TRUE,"���������l�ƥ���..");
	}

	test();							//-----------------------------------------------------------

  // Message loop
  ZeroMemory(&Msg, sizeof(MSG));
  while(Msg.message != WM_QUIT) {
    if(PeekMessage(&Msg, NULL, 0, 0, PM_REMOVE)) {
      TranslateMessage(&Msg);
      DispatchMessage(&Msg);
    }
    if(FrameProcess() == FALSE)
      break;
  }
	
	Shutdown();								// ����
	CoUninitialize();					// ����COM
	UnregisterClass(m_Class,m_hInst);	// �������������U
	return TRUE;
}

// ------------------------------------------------------------------------------
//
// �������~
BOOL CGameSysCoreMgt::ErrorMsg(BOOL Fatal, char *Text, ...)
{
  char CaptionText[12];
  char ErrorText[2048];
  va_list valist;

  // �إ�Message,�ΨӧP�_�O�_�Y���v�T
  if(Fatal == FALSE)
    strcpy(CaptionText, "Error");
  else 
    strcpy(CaptionText, "Fatal Error");

  // �إߥi�ܪ�buffer
  va_start(valist, Text);
  vsprintf(ErrorText, Text, valist);
  va_end(valist);

  // Display the message box
  MessageBox(NULL, ErrorText, CaptionText, MB_OK | MB_ICONEXCLAMATION);

  // �Y�O�Y�����N���X
  if(Fatal == TRUE)   PostQuitMessage(0);

  return TRUE;
}
// End CGameSysCore Functions ////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////
// 
// Message process
// ------------------------------------------------------------------------------
//
long FAR PASCAL cGameSysCoreWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  switch(uMsg) {

    case WM_DESTROY:
      PostQuitMessage(0);
      return 0;

    default: return g_pGameSysCore->MsgProc(hWnd, uMsg, wParam, lParam);
  }
}
//End Message processes ////////////////////////////////////////////////////////////

