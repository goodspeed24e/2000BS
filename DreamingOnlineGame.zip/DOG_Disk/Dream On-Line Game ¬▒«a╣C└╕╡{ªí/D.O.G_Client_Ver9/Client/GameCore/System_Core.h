//////////////////////////////////////////////////////////////////
//
//
/*************************************													
//	�t�ή֤�, System_Core.h - v0.1	
//  author : Y.Y.L Date : 02/27/03
/*************************************/
//-----------------------------------------------------------------

#ifndef _SYSTEM_CORE_H
#define _SYSTEM_CORE_H

#define	IDC_hLB_Output				40002
#define	IDC_hEB_InputField		40011


class CGameSysCoreMgt : public Singleton< CGameSysCoreMgt >
{
private:
  HINSTANCE		m_hInst;						// ����handle
  HWND				m_hWnd;							// ����handle
	HWND				hLB_Output;
	HWND				hEB_InputField;
	WNDCLASSEX  m_Winclassex;				// �������O���c
protected:
	char          m_Class[MAX_PATH];
  char          m_Caption[MAX_PATH];

	DWORD		m_Style;							// �����Φ�
	DWORD   m_XPos;								// X coordinate 
	DWORD   m_YPos;								// Y coordinate
	DWORD		m_Width;							// width 
	DWORD		m_Height;							// height
public:
	CGameSysCoreMgt() {Create();}				
	~CGameSysCoreMgt(){Destory();}				
	

	// �إ�/�R��/Run window
	void		Create();
	void		Destory();
	BOOL Run();																					// ���� ����

	BOOL ErrorMsg(BOOL Fatal,char *Text,...);						// ���~����

  inline HWND				GethWnd()	{cassert(m_hWnd,"GethWnd is error..")		;return m_hWnd;}				// �^�� HWND
	inline HINSTANCE	GethInst(){cassert(m_hInst,"GethInst is error..");return m_hInst;}				// �^�� HINSTANCE
	inline void ShowMouse(BOOL Show=TRUE) 							// ��ܩ�����MOUSE
	{ShowCursor(Show);}

	// Message handle
	virtual FAR PASCAL MsgProc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
	{	return DefWindowProc(hWnd,uMsg,wParam,lParam);}

	//	flow control
	virtual BOOL Init()						{return TRUE;}
	virtual BOOL FrameProcess()		{return TRUE;}
	virtual BOOL Shutdown()				{return TRUE;}

	
	// Template Functions	
	// ���ʵ���
	template <class T> inline				
		BOOL Move(T XPos,T YPos){
			RECT ClientRect;
			GetClientRect(m_hWnd, &ClientRect);							// ���oClientRect
			MoveWindow(m_hWnd, XPos, YPos, ClientRect.right, ClientRect.bottom, TRUE);
			return TRUE;
		} // end Move
	
	// ���s�վ����
	template <class T> inline
		BOOL AdjustWindow(T Width, T Height){

			RECT WndRect, ClientRect;
			T WndWidth, WndHeight;

			GetWindowRect(m_hWnd, &WndRect);
			GetClientRect(m_hWnd, &ClientRect);

			WndWidth  = (WndRect.right  - (ClientRect.right  - Width))  - WndRect.left;
			WndHeight = (WndRect.bottom - (ClientRect.bottom - Height)) - WndRect.top;
			MoveWindow(m_hWnd, WndRect.left, WndRect.top, WndWidth, WndHeight, TRUE);
		return TRUE;
		}	// end AdjustWindow
};

static CGameSysCoreMgt *g_pGameSysCore = NULL;
static long FAR PASCAL  cGameSysCoreWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

BOOL CALLBACK ConnectDialogProc(HWND hWnd, UINT uMsg,         \
                                WPARAM wParam, LPARAM lParam);
BOOL CALLBACK SelectDialogProc(HWND hWnd, UINT uMsg,         \
                                WPARAM wParam, LPARAM lParam);
BOOL CALLBACK CreateDialogProc(HWND hWnd, UINT uMsg,         \
                                WPARAM wParam, LPARAM lParam);
typedef WidgetManager <OpNewCreator<CGameSysCoreMgt> > MyWidgetMgr;
typedef WidgetManager <PrototypeCreator<CGameSysCoreMgt> >MyWidgetManager;


#endif