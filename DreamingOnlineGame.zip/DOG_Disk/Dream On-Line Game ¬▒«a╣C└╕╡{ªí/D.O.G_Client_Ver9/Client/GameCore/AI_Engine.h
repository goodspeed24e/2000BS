#include <iostream>

#define lenth 20   //�a�Ϫ�x
#define width 40   //�a�Ϫ�y
char map[lenth][width];   //�a�ϰ}�C

class _declspec(dllimport) AIOListNode   //List��node
{
public:
	int f,g,h;           //�v��
	int x,y;             //�y��
	AIOListNode *parent;  //��node
	AIOListNode *next;    //�U�@��node
	AIOListNode *before;   //�e�@��node
	AIOListNode(int vx,int vy){
		x=vx;
		y=vy;
		parent=NULL;
		next=NULL;
		before=NULL;
	};
	void AISetghf(int sx,int sy,int tempx,int tempy)  //�p���v��
	{
		g=abs(x- sx)+abs(y - sy);
		h=abs(x - tempx)+abs(y - tempy);
		f=g + h;
	};

};


class _declspec(dllimport) AINode    //path��node
{
public:
	int x,y;
	AINode(int vx,int vy){
		x=vx;
		y=vy;
		parent=NULL;
		next=NULL;
	};
	AINode *next;
	AINode *parent;
};

class _declspec(dllimport) AIUser //���� 
{
public:
	AIUser(int a,int b){
		sx=a;
		sy=b;
		PathIndex=NULL;
		
	};
	int sx,sy;
	int dx,dy;
	int max;
	bool AIdecDestination();
	bool AISetDestination(int x,int y);
	bool AISelectpath(int x,int y);
	bool AICheckCL(int checkx,int checky);
	bool AICheckOL(AIOListNode *OL);
	void AIdelmemory();
	AIOListNode	*AIGetBestOLNode();
	AIOListNode *OLIndex;
	AIOListNode *CLIndex;
	AINode *PathIndex;
	AINode *PathWalk;
	AINode	*AISetpath(AIOListNode* OL);
};