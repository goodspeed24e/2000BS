//////////////////////////////////////////////////////////////////
//
//
//*****************************************											
//	�C���\��禡���Y��, GameTemplate.h - v0.1	
//  author : Y.Y.L Date : 02/27/03
//*****************************************
//-----------------------------------------------------------------


#ifndef _GameTemplate_
#define _GameTemplate_

// DEFINE	////////////////////////////////////////////////////////
// �j�p��� assertion
//////////////////////////////////////////////////////////////////
#ifdef WIN32
#define cassert(exp,description) (void)( (exp) || ( MessageBox( NULL, #description, "Assert", 0 ) ) )
#else
#define cassert(exp,description) (void)( (exp) || ( fprintf(stderr, "Assert: %s ", #description ) ) )
#endif

//////////////////////////////////////////////////////////////////
// MessageBox
//////////////////////////////////////////////////////////////////
#define MB(exp) ( MessageBox( NULL, exp, " Warning", MB_OK ) )



//////////////////////////////////////////////////////////////////
// Game Template Functions
//			Singlton 
//////////////////////////////////////////////////////////////////
template <typename T>class Singleton
{
	static T* ms_Singleton;
public:
	Singleton(void)
	{
		cassert(!ms_Singleton,"Singleton is error..");
		int offset = (int)(T*)1 - (int)(Singleton<T>*)(T*)1;
		ms_Singleton = (T*)((int)this+offset);
	}
	~Singleton(void)
	{		cassert(ms_Singleton,"Singleton is error.."); ms_Singleton = 0;}

	static T& GetSingleton(void)
	{		cassert(ms_Singleton,"GetSinleton is error.."); return (*ms_Singleton);}
	static T* GetSingletonPtr(void)
	{		return (ms_Singleton);}
};

template <typename T> T* Singleton <T>::ms_Singleton = 0;


#define g_Core CGameSysCoreMgt::GetSingleton()
#define g_3D	 CGraphics3DCore::GetSingleton()
#define g_Net	 CClientNet::GetSingleton()
// End 	Singlton 

//////////////////////////////////////////////////////////////////
// policy-based class
// first way ------------------------
template <class T>
struct OpNewCreator
{
	static T* Create()
	{
		return new T;
	}
};

template <class T>
struct PrototypeCreator
{
	public:
	PrototypeCreator(T* pObj = 0) : pPrototype_(pObj){}
	T* Create()
	{
		return pPrototype_ ? pPrototype_->Clone() : 0 ;
	}
	T* GetPrototype() { return pPrototype_;}
	void SetPrototype(T* Obj) { pPrototype_ = pObj;}
	private:
		T* pPrototype_;
	protected:
		~PrototypeCreator() {}
};

// stupit way
template <typename SysCoreWidgetManager>
class WidgetManager : public SysCoreWidgetManager
{
public:
	void show() { MB("is Test");}
	void switchPrototype(SysCoreWidgetManager* pNewPrototype)
	{
		SysCoreWidgetManager myPolicy = *this;
		delete myPolicy.GetPrototype();
		myPolicy.SetPrototype(pNewPrototype);
	}
};

//////////////////////////////////////////////////////////////////
// �qcompile time�����j�p���
//////////////////////////////////////////////////////////////////
template<bool> struct CompileTimeChecker
{
	CompilTimeChecker(...);
};
template<> struct CompileTimeChecker<false>{ };
// ps. #define �榡�n�`�N
#define STATIC_CHECK(expr,msg)\
{\
	char ERROR_##msg {};\
  (void)sizeof(CompileTimeChecker<(expr)>(ERROR_##msg()));\
}
template <class To, class From> inline
		To safe_reinterpret_cast(From from){
			STATIC_CHECK(sizeof(From) <= sizeof(To),Destination_Type_Too_Narrow);
			return reinterpret_cast<To>(from);
}

#endif