//////////////////////////////////////////////////////////////////
//
//
//*****************************************											
//	�w�q���Y��, Global.h - v0.1	
//  author : Y.Y.L Date : 02/27/03
//*****************************************
//----------------------------------------------------------------


#ifndef _GLOBAL_H_
#define _GLOBAL_H_

// INCLUDE ////////////////////////////////////////////////////////

#ifdef WIN32
// Windows & STL includes
#include <windows.h>
#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <assert.h>

#else
// Standard ANSI-C includes
#include <stdio.h>

#endif

// DirectX includes
#include "d3d8.h"
#include "d3dx8.h"
#include "dmusici.h"
#include "dsound.h"
#include "dplay8.h"
#include "dpaddr.h"
#include "dinput.h"

// �\��禡 includes
#include "GameTemplate.h"

// �귽�� includes
#include "../Win32/resource.h"

// Custom Engine includes
#include "..\GameCore\System_Core.h"
#include "..\GameCore\DXGraphics_Engine.h"
#include "..\GameCore\DXInput_Engine.h"
#include "..\GameCore\DXSound_Engine.h"
#include "..\GameCore\DXNetWork_Engine.h"
//#include "..\GameCore\AI_Engine.h"

#pragma warning( disable: 4127 )
#pragma inline_depth( 255 )
#pragma inline_recursion( on )

#pragma comment(lib,"DXNetwork_Engine.lib")
//#pragma comment(lib,"AI_Engine.lib")

#endif