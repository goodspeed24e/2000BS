//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GameResource.rc
//
#define IDD_DIALOG1                     104
#define IDD_LOGINDIA                    104
#define IDD_CREATEROLE                  106
#define IDD_SELECTROLE                  107
//#define IDB_BITMAP1                     114
#define IDC_USERID                      1000
#define IDC_USERPASSWORD                1001
#define IDC_ROLEPIC                     1003
#define IDC_PLAYERNAME                  1004
#define IDC_CLASS                       1005
#define IDC_SP                          1006
#define IDC_LUK                         1007
#define IDC_DEX                         1008
#define IDC_WIS                         1009
#define IDC_INT                         1010
#define IDC_CON                         1011
#define IDC_STR                         1012
#define IDC_HP                          1013
#define IDC_EXP                         1014
#define IDC_LEVEL                       1015
#define IDC_LOGIN                       1017
#define IDC_CANCEL                      1018
#define IDC_FLEE                        1019
#define IDC_ENTER                       1019
#define IDC_HIT                         1020
#define IDC_DEL                         1020
#define IDC_MATK                        1021
#define IDC_CREATE                      1021
#define IDC_MDEF                        1022
#define IDC_DEF                         1023
#define IDC_ATK                         1024
#define IDC_ASPD                        1025
#define IDC_CRI                         1026
#define IDC_OK                          1027
#define IDC_IP                          1028

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
