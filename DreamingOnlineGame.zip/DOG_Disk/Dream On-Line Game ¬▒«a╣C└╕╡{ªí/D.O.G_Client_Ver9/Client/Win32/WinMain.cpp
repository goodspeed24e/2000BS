
#include "WinMain.h"

cMainApp            *g_Application;		
cNetworkAdapter			*g_Adapters;   
BOOL								 g_Connected = FALSE;  

// �]�w�O�_���ù�
int FULLSCREENMODE;
bool kb = FALSE;
 
#define Textrow								5
int  BufferCounter=0;
char UserName[32],UserPsw[32],ServerIP[16];
char TextBuffer[Textrow][256]={"","","","",""};
char LocalText[32]="";
	int test=0;
cMainApp::cMainApp()
{
	// ��l��INSTANCE ���

	// ������
	INDEX	=	STATE_START;
	FULLSCREENMODE = 0;
	// �]�w�����Φ��A��m�A���e
	m_XPos	= 0;
	m_YPos	= 0;
	m_Width  = 640; 
	m_Height = 575;
	 m_Style  = WS_BORDER | WS_CAPTION | WS_MINIMIZEBOX | WS_SYSMENU;

	strcpy(m_Class,"cMainApp");
	strcpy(m_Caption,"Dream on-line Game");

	g_Application = this;
	g_Adapters    = &m_Adapters;

	// Create a critical section for updating data
	InitializeCriticalSection(&m_UpdateCS);
}

cMainApp::~cMainApp(){
}

BOOL cMainApp::Init()
{
  if(InitializeGame() == FALSE) {
    MB("�� �� �� �l �� �� �� �C ��");
    return FALSE;
  }

  if(JoinGame() == FALSE) {
    MB("�L �k �s �u �� �� �A ��");
    return FALSE;
  }

  return TRUE;
}

BOOL cMainApp::Shutdown()
{

 // ��������
  m_Adapters.Shutdown();
  m_Client.Disconnect();
  m_Client.Shutdown();

  // ���񪱮a���c
  delete [] m_Players;
  m_Players = NULL;
  
  
  // ���� meshes
  for(int i=0;i<MAX_ROLES;i++)
  {
	  m_CharMesh[i].m_CharacterMesh.Free();
	  m_CharMesh[i].m_CharacterAnim.Free();
  }
  delete [] m_CharMesh;
  delete [] m_WeaponMesh;

  // ���� �˸m
  m_Keyboard.Free();
  m_Mouse.Free();
  m_Input.Shutdown();

  // �����ϧγB�z
  m_Font.Free();
  m_Graphics.Shutdown();

  // �R�� critical section
  DeleteCriticalSection(&m_UpdateCS);

	// �������, ����, �K��
  //m_SceneMesh.Free();
  delete[] m_SceneMesh;
  m_SceneObject.Free();
  m_Meshes.Free();
  m_Objects.Free();
  m_Animations.Free();
  for(i=0;i<6;i++)
    m_BDTextures[i].Free();

  // �����˸m
  m_Keyboard.Free();
  m_Input.Shutdown();

  // �����ϧ�
  m_Graphics.Shutdown();
  for(int ui=0;ui<3;ui++)
  {
	UI[ui].Free();
	//STATUS[ui].Free();
  }

  return TRUE;
}
void cMainApp::ChangeCharMesh(sPlayer *Player)
{
	Player->Body.Create(&m_Graphics, &m_CharMesh[Player->Career].m_CharacterMesh);
}

void cMainApp::ChangeWeaponMesh(sPlayer *Player)
{
	Player->Weapon.Create(&m_Graphics, &m_WeaponMesh[Player->WP]);
	Player->Weapon.AttachToObject(&Player->Body, "Bip01_R_Finger11");
	Player->Weapon.Rotate(1.57f, 0.0f, 0.0f);
}
void cMainApp::InputCharMesh()
{
	m_CharMesh= new CharMesh[MAX_ROLES]();
	for(int i=0;i<MAX_ROLES;i++)
	{
		switch(i){
		case UNKNOW:m_CharMesh[i].m_CharacterMesh.Load(&m_Graphics, "..\\Data\\killer\\killer.x", "..\\Data\\killer\\");
				m_CharMesh[i].m_CharacterAnim.Load("..\\Data\\killer\\killer.x", &m_CharMesh[i].m_CharacterMesh); 
			    break;
		case ASS:m_CharMesh[i].m_CharacterMesh.Load(&m_Graphics, "..\\Data\\killer\\killer.x", "..\\Data\\killer\\");
				m_CharMesh[i].m_CharacterAnim.Load("..\\Data\\killer\\killer.x", &m_CharMesh[i].m_CharacterMesh);
				break;
		case WAR:m_CharMesh[i].m_CharacterMesh.Load(&m_Graphics, "..\\Data\\hunter\\hunter.x", "..\\Data\\hunter\\");
				m_CharMesh[i].m_CharacterAnim.Load("..\\Data\\hunter\\hunter.x", &m_CharMesh[i].m_CharacterMesh);
				break;
		case TIGER:m_CharMesh[i].m_CharacterMesh.Load(&m_Graphics, "..\\Data\\tigger\\tigger.x", "..\\Data\\tigger\\");
				m_CharMesh[i].m_CharacterAnim.Load("..\\Data\\hunter\\hunter.x", &m_CharMesh[i].m_CharacterMesh);
				break;
		case MONKEY:m_CharMesh[i].m_CharacterMesh.Load(&m_Graphics, "..\\Data\\baboon\\baboon.x", "..\\Data\\baboon\\");
				m_CharMesh[i].m_CharacterAnim.Load("..\\Data\\baboon\\baboon.x", &m_CharMesh[i].m_CharacterMesh);
				break;
		case KNI:m_CharMesh[i].m_CharacterMesh.Load(&m_Graphics, "..\\Data\\ernie\\ernie.x", "..\\Data\\ernie\\");
				m_CharMesh[i].m_CharacterAnim.Load("..\\Data\\hunter\\hunter.x", &m_CharMesh[i].m_CharacterMesh);
				break;
	    
		}
		m_CharMesh[i].m_CharacterAnim.SetLoop(TRUE, "Walk");
		m_CharMesh[i].m_CharacterAnim.SetLoop(TRUE, "Idle");
		m_CharMesh[i].m_CharacterAnim.SetLoop(FALSE, "Swing");
		m_CharMesh[i].m_CharacterAnim.SetLoop(FALSE, "Hurt");
	}
}

void cMainApp::InputMapMesh()
{
	m_SceneMesh =new cMesh[70]();
	char FileName[100];
	for(int i=0;i<70;i++)
	{
		sprintf(FileName,"..\\Data\\MapMesh\\%u.x",i);
		m_SceneMesh[i].Load(&m_Graphics, FileName);
	}
}


void cMainApp::InputWeaponMesh()
{
	m_WeaponMesh= new cMesh[MAX_WEAPONS]();
	for(int i=0;i<MAX_WEAPONS;i++)
	{
		switch(i){
		case UNKNOW:m_WeaponMesh[i].Load(&m_Graphics, "..\\Data\\weapon\\sword.x", "..\\Data\\weapon\\");
			break;
		case TOOTHCLUB:m_WeaponMesh[i].Load(&m_Graphics, "..\\Data\\weapon\\ding.x", "..\\Data\\weapon\\");
					break;
		case MAGICSTICK:m_WeaponMesh[i].Load(&m_Graphics, "..\\Data\\weapon\\staff.x", "..\\Data\\weapon\\");
					break;
		case ALUMINUMCLUB:m_WeaponMesh[i].Load(&m_Graphics, "..\\Data\\weapon\\bon.x", "..\\Data\\weapon\\");
					break;
		case SUNSTARHAMMER:m_WeaponMesh[i].Load(&m_Graphics, "..\\Data\\weapon\\CHO.x", "..\\Data\\weapon\\");
					break;
		case BEASTHAMMER:m_WeaponMesh[i].Load(&m_Graphics, "..\\Data\\weapon\\SI.x", "..\\Data\\weapon\\");
					break;
		case DREAMSWORD:m_WeaponMesh[i].Load(&m_Graphics, "..\\Data\\weapon\\knife.x", "..\\Data\\weapon\\");
					break;
		}
	}
}


void cMainApp::LoadMap(int MID)
{
	long start=0,end=0;
	char Filename[81];
	sprintf(Filename, "..\\Data\\%u\\",MID);
	int lenth=strlen(Filename);
	sprintf(Filename+lenth, "%u",MID);
	lenth=strlen(Filename);

	for(short i=0;i<6;i) {
		sprintf(Filename+lenth,"%u.jpg", i+1);
		m_BDTextures[i].Load(&m_Graphics, Filename);
		if (m_BDTextures[i].IsLoaded())
			i++;
	}
	
	start = GetTickCount();
	while (end-start<100){
		end = GetTickCount();
	}
	char XFilename[81];
		sprintf(XFilename, "..\\Data\\%u\\", MID);
		lenth=strlen(XFilename);
		sprintf(XFilename+lenth, "%u.x", MID);
		
		//m_SceneMesh.Free();
		//m_SceneMesh.Load(&m_Graphics,XFilename);
	//	while (!m_SceneMesh.IsLoaded())
	//	m_SceneMesh.Load(&m_Graphics,XFilename);
		//m_SceneObject.Create(&m_Graphics, &m_SceneMesh);
}



BOOL cMainApp::InitializeGame()
{
	//char Filename[81];

	Move(250,150);

	// �n�J��ܲ�
	int Result = DialogBox(GethInst(), MAKEINTRESOURCE(IDD_LOGINDIA),  \
                   GethWnd( ), ConnectDialogProc);

	// ��l����ܥd�Mdisplay mode
   m_Graphics.Init();

	// �M�w�O�_���ù�
	if (FULLSCREENMODE)
		m_Graphics.SetMode(GethWnd(), FALSE, TRUE, 640, 480);
	else
		m_Graphics.SetMode(GethWnd(), TRUE, TRUE);
 
  // ���e�{����
  m_Graphics.SetPerspective(0.6021124f, 1.333333f, 1.0f, 20000.0f);

  ShowMouse(TRUE);

	// �إߦr��
  m_Font.Create(&m_Graphics, "Arial", 14, TRUE);

	// ��l�ƿ�J�˸m
  m_Input.Init(GethWnd(), GethInst());
  m_Keyboard.Create(&m_Input, KEYBOARD);
  m_Mouse.Create(&m_Input, MOUSE, TRUE);

	// ��l���n���t��
  m_Sound.Init(GethWnd(), 44100, 1, 16);
  m_SoundChannel.Create(&m_Sound, 44100, 1, 16);
  m_MusicChannel.Create(&m_Sound);
  PlayMusic(0); 


	// Ū�J��������
	InitMenu();



	// ���J��������ëإߪ���ʧ@
	InputCharMesh();
	InputWeaponMesh();
	InputMapMesh();
  // ---------------------------
// ���J��������ëإߪ���ʧ@

  
	//	--------------------------------------------------
	//PlaySound(1);
	
	SetInfo( g_Adapters->GetGUID(0),ServerIP, UserName,UserPsw);



  // �إߪ��a���c
  m_Players = new sPlayer[MAX_PLAYERS]();

  // �]�w�������
  

  
  // ��l���a���a���
  m_NumPlayers = 1;
  strcpy(m_Players[0].Name,UserName);
  m_Players[0].Career    = UNKNOW;
  m_Players[0].Connected = TRUE;
  m_Players[0].Direction = 0.0f;
  m_Players[0].AtMap	= 50;
  m_Players[0].XPos		= 0.0f;
  m_Players[0].YPos		= 0.0f;
  m_Players[0].ZPos		= 0.0f;
  m_Players[0].Speed	= 128.0f;
  m_Players[0].State	= UNKNOW;
  m_Players[0].WP		= UNKNOW;
  EQmenu=false;

  return TRUE;
}

BOOL cMainApp::JoinGame()
{
  // ��l�ƺ����ós�ܥD��
  strcat(m_Name,"*");
  strcat(m_Name,m_Psw);
  m_Client.Init();
  if(m_Client.Connect(m_guidAdapter, m_HostIP, 9123,          \
                      m_Name, "Dream On-line Game", NULL) == FALSE)
    return FALSE;

  return TRUE; 
}



BOOL cMainApp::FrameProcess()
{
	static DWORD UpdateCounter  = timeGetTime();
	static long MoveAction = 0, LastMove = 0;
	static BOOL CamMoved = FALSE;
	BOOL AllowMovement;
	long Dir;
	float Angles[13] = { 0.0f, 0.0f, 1.57f, 0.785f, 3.14f,      \
		               0.0f, 2.355f, 0.0f, 4.71f, 5.495f,     \
			           0.0f, 0.0f, 3.925f };

	// �������a�˸m���ʧ@
	m_Keyboard.Acquire(TRUE);  
	m_Mouse.Acquire(TRUE);     
	m_Keyboard.Read();
	m_Mouse.Read();

	if(m_Keyboard.GetKeyState(KEY_ESC) == TRUE)
		return FALSE;

	// �����s�u�õ��ݵe�������
	if(g_Connected == FALSE || !m_Players[0].dpnidPlayer) {

    // Display message(s)
		m_Graphics.Clear();
		if(m_Graphics.BeginScene() == TRUE) {
			m_Font.Print("�s �u �� �� �A ��....",0,60);
			if(!m_Players[0].dpnidPlayer)
				m_Font.Print("�� �� �� �A �� �� �� ��....", 0, 80);
			m_Graphics.EndScene();
		}
		m_Graphics.Display();
	
    // Request player ID from server every 2 seconds
		// �C���
		if(timeGetTime() > UpdateCounter + 2000) {
			UpdateCounter = timeGetTime();  // ��s�p�ƾ�

			sAssignPlayerIDMessage apidm;
			apidm.Header.Type = MSG_ASSIGNID;
			apidm.Header.Size = sizeof(sAssignPlayerIDMessage);
			SendNetworkMessage(&apidm, DPNSEND_NOLOOPBACK |         \
					                 DPNSEND_GUARANTEED);
		}
		return TRUE;
	}
  // Store movements every frame
	if(m_Keyboard.GetKeyState(KEY_UP) == TRUE)
		MoveAction |= 1;
	if(m_Keyboard.GetKeyState(KEY_RIGHT) == TRUE)
		MoveAction |= 2;
	if(m_Keyboard.GetKeyState(KEY_DOWN) == TRUE)
		MoveAction |= 4;
	if(m_Keyboard.GetKeyState(KEY_LEFT) == TRUE)
		MoveAction |= 8;
  
  // Store attack action
/*	
	if (m_Mouse.GetButtonState(MOUSE_RBUTTON) == TRUE)
	{
		int mouse_x = m_Mouse.GetXPos();
		int mouse_y = m_Mouse.GetYPos();

	  	char test1[10],test2[10],test3[10];
		itoa(mouse_x,test1,10);
		itoa(mouse_y,test2,10);
		itoa(m_Players[0].State,test3,10);
		strcat(test1,"  ");
		strcat(test1,test2);
		strcat(test1,"  ");
		strcat(test1,test3);
		MB(test1);
	}
*/
	 long start=0,end=0;
	start = GetTickCount();
	
	if(strlen(LocalText)<32)
	{
			
		if (m_Keyboard.GetKeyState(KEY_SPACE)){
			strcat(LocalText," ");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_BACKSPACE)){
			if(strlen(LocalText)>0)
			{
				LocalText[strlen(LocalText)-1]='\0';
				while (end-start<200)
					end = GetTickCount();
			}
		}
		if (m_Keyboard.GetKeyState(KEY_1)){
			strcat(LocalText,"1");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_2)){
			strcat(LocalText,"2");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_2)){
			strcat(LocalText,"2");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_3)){
			strcat(LocalText,"3");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_4)){
			strcat(LocalText,"4");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_5)){
			strcat(LocalText,"5");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_6)){
			strcat(LocalText,"6");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_7)){
			strcat(LocalText,"7");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_8)){
			strcat(LocalText,"8");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_9)){
			strcat(LocalText,"9");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_0)){
			strcat(LocalText,"0");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_A)){
			strcat(LocalText,"A");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_B)){
			strcat(LocalText,"B");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_C)){
			strcat(LocalText,"C");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_D)){
			strcat(LocalText,"D");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_E)){
			strcat(LocalText,"E");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_F)){
			strcat(LocalText,"F");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_G)){
			strcat(LocalText,"G");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_H)){
			strcat(LocalText,"H");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_I)){
			strcat(LocalText,"I");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_J)){
			strcat(LocalText,"J");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_K)){
			strcat(LocalText,"K");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_L)){
			strcat(LocalText,"L");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_M)){
			strcat(LocalText,"M");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_N)){
			strcat(LocalText,"N");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_O)){
			strcat(LocalText,"O");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_P)){
			strcat(LocalText,"P");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_Q)){
			strcat(LocalText,"Q");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_S)){
			strcat(LocalText,"S");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_R)){
			strcat(LocalText,"S");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_T)){
			strcat(LocalText,"T");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_U)){
			strcat(LocalText,"U");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_V)){
			strcat(LocalText,"V");
			while (end-start<200)
				end = GetTickCount();
		}if (m_Keyboard.GetKeyState(KEY_W)){
			strcat(LocalText,"W");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_X)){
			strcat(LocalText,"X");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_Y)){
			strcat(LocalText,"Y");
			while (end-start<200)
				end = GetTickCount();
		}
		if (m_Keyboard.GetKeyState(KEY_Z)){
			strcat(LocalText,"Z");
			while (end-start<200)
				end = GetTickCount();
		}
	}
	if(m_Keyboard.GetKeyState(KEY_ENTER) == TRUE && strlen(LocalText)!=0)
	{
		sShowText Stm;
		Stm.Header.Type			=	MSG_CHATING;
		Stm.Header.Size			= sizeof(sShowText);
		Stm.Header.PlayerID = m_Players[0].dpnidPlayer;
	
		strcpy(Stm.text,LocalText);
		ZeroMemory(&LocalText,sizeof(LocalText));
		SendNetworkMessage(&Stm, DPNSEND_NOLOOPBACK);
	}
	 
  //----------��m����
	if(m_Keyboard.GetKeyState(KEY_F1) == TRUE)
	{
		if(EQmenu)
		{
			EQmenu=false;
		}else{
			EQmenu=true;
		}
		while (end-start<200)
				end = GetTickCount();
		
	}
	int WantWP=m_Players[0].WP;
    if(m_Keyboard.GetKeyState(KEY_F2) == TRUE && WantWP != m_Players[0].EQ1)
	{
		m_Players[0].State=STATE_SWAPWP;
		WantWP=m_Players[0].EQ1;
	}
	if(m_Keyboard.GetKeyState(KEY_F3) == TRUE && WantWP != m_Players[0].EQ2)
	{
		m_Players[0].State=STATE_SWAPWP;
		WantWP=m_Players[0].EQ2;
	}
	if(m_Keyboard.GetKeyState(KEY_F4) == TRUE && WantWP != m_Players[0].EQ3)
	{
		m_Players[0].State=STATE_SWAPWP;
		WantWP=m_Players[0].EQ3;
	}
  // Rotate camera
	if(m_Mouse.GetXDelta() > 0) 
	{
		m_CamAngle -= 0.1f;
		CamMoved = TRUE;
	}
	if(m_Mouse.GetXDelta() < 0) 
	{
		m_CamAngle += 0.1f;
		CamMoved = TRUE;
	}
	AllowMovement = TRUE;
	int NextMenuState=UNKNOW;
	if(m_Mouse.GetButtonState(MOUSE_LBUTTON) == TRUE)
	{
		int mouse_x = m_Mouse.GetXPos();
		int mouse_y = m_Mouse.GetYPos();
		if(m_Players[0].AtMap==6 && !(m_Players[0].State > 2 && m_Players[0].State < 15) 
			&& (mouse_x >160 && mouse_x <200 &&mouse_y >65 &&mouse_y <115))
		{
			m_Players[0].State=STATE_HEAL;
		}

	}
	if(m_Mouse.GetButtonState(MOUSE_LBUTTON) == TRUE && !(m_Players[0].State > 4 && m_Players[0].State < 15))
	{
		MoveAction |= 16;

		PlaySound(m_Players[0].WP);
	}


	if (m_Players[0].State > 4 && m_Players[0].State < 13)
	{
		AllowMovement=FALSE;
		if(m_Mouse.GetButtonState(MOUSE_LBUTTON) == TRUE)
		{
			int mouse_x = m_Mouse.GetXPos();
			int mouse_y = m_Mouse.GetYPos();
			switch(m_Players[0].State)
			{
				case STATE_CHOOSINGL:
					if(mouse_x >=370 && mouse_x <=490 && mouse_y >=480 && mouse_y <=520)
						NextMenuState= STATE_LEFT;
					if(mouse_x >=500 && mouse_x <=620 && mouse_y >=480 && mouse_y <=520)
						NextMenuState= STATE_CHOOSING;
					break;
				case STATE_CHOOSINGR:
					if(mouse_x >=370 && mouse_x <=490 && mouse_y >=480 && mouse_y <=520)
						NextMenuState= STATE_RIGHT;
					if(mouse_x >=500 && mouse_x <=620 && mouse_y >=480 && mouse_y <=520)
						NextMenuState= STATE_CHOOSING;
					break;
				case STATE_CHOOSING :
					if(m_Mouse.GetXPos() > 360 && m_Mouse.GetXPos() < 580)
						NextMenuState = STATE_CHOOSINGR;
					if(m_Mouse.GetXPos() > 60 && m_Mouse.GetXPos() < 280)
						NextMenuState = STATE_CHOOSINGL;	
					break;
				case STATE_START:
					if(mouse_x >=225 && mouse_x <=335 && mouse_y >=480 && mouse_y <=510)
					{
						if(m_Players[0].Career == UNKNOW)
						{
							EnterCriticalSection(&m_UpdateCS);
							NextMenuState = STATE_CHOOSING;
							LeaveCriticalSection(&m_UpdateCS);
						}else{
							EnterCriticalSection(&m_UpdateCS);
							NextMenuState = STATE_START;
							LeaveCriticalSection(&m_UpdateCS);
						}
					}
					if(mouse_x >=400 && mouse_x <=510 && mouse_y >=480 && mouse_y <=510)
					{		
						if(m_Players[0].Career != UNKNOW)
						{
							EnterCriticalSection(&m_UpdateCS);
							NextMenuState = STATE_DELETE;
							m_Players[0].State=STATE_DELETE;
							LeaveCriticalSection(&m_UpdateCS);
						}else{
							EnterCriticalSection(&m_UpdateCS);
							NextMenuState = STATE_START;
							LeaveCriticalSection(&m_UpdateCS);
						}
					}
					if(mouse_x >=540 && mouse_x <=660 && mouse_y >=480 && mouse_y <=510)
					{
							if(m_Players[0].Career != UNKNOW)
							{
								EnterCriticalSection(&m_UpdateCS);
								NextMenuState = STATE_PLAYGAME;
								LeaveCriticalSection(&m_UpdateCS);
							}else{
								EnterCriticalSection(&m_UpdateCS);
								NextMenuState = STATE_START;
								LeaveCriticalSection(&m_UpdateCS);
							}
					}
					break;
			}
			sStateChangeMessage Msg;
			Msg.Header.Type     = MSG_STATE_CHANGE;
			Msg.Header.Size     = sizeof(sStateChangeMessage);
			Msg.Header.PlayerID = m_Players[0].dpnidPlayer;
			if(NextMenuState != UNKNOW)
			{
				Msg.State           = NextMenuState ;
			}else{
				Msg.State           = m_Players[0].State ;
			}
			Msg.AtMap			= m_Players[0].AtMap;
			Msg.Career			= m_Players[0].Career;
			Msg.Direction       = m_Players[0].Direction ;
			// Send message to server
			SendNetworkMessage(&Msg, DPNSEND_NOLOOPBACK);
		}
	}
  // Only update players every 33ms (30 times a second)
	if(timeGetTime() < UpdateCounter + 33)
		return TRUE;

  // Set flag to allow player movement

  // Don't allow movement if still swinging weapon
	if(m_Players[0].State == STATE_SWING)
		AllowMovement = FALSE;

  // Don't allow movement if still being hurt
	if(m_Players[0].State == STATE_HURT)
		AllowMovement = FALSE;
	if(m_Players[0].State== STATE_SWAPWP)
	{
		sStateChangeMessage Msg;
		Msg.Header.Type     = MSG_STATE_CHANGE;
		Msg.Header.Size     = sizeof(sStateChangeMessage);
		Msg.Header.PlayerID = m_Players[0].dpnidPlayer;
		Msg.State           = STATE_SWAPWP;
		Msg.Direction       = m_Players[0].Direction;
		Msg.WP								= WantWP;
			//m_Players[0].WP				= WantWP;
		//m_Players[0].State=STATE_IDLE;
		SendNetworkMessage(&Msg, DPNSEND_NOLOOPBACK);
		AllowMovement = FALSE;
	}
	if(m_Players[0].State== STATE_HEAL)
	{
		sStateChangeMessage Msg;
		Msg.Header.Type     = MSG_STATE_CHANGE;
		Msg.Header.Size     = sizeof(sStateChangeMessage);
		Msg.Header.PlayerID = m_Players[0].dpnidPlayer;
		Msg.Direction       = m_Players[0].Direction;
		Msg.State           = STATE_HEAL;
		//m_Players[0].State= STATE_IDLE;
		SendNetworkMessage(&Msg, DPNSEND_NOLOOPBACK);
		AllowMovement = FALSE;
	}
  // Handle movements if allowed
	if(AllowMovement == TRUE) 
	{
		
    // Process attack
		if(MoveAction & 16) 
		{
			MoveAction = 0;  // Clear movement
			LastMove = 0;    // Clear last movement

      // Send attack message - let server signal swing
			sStateChangeMessage Msg;
			Msg.Header.Type     = MSG_STATE_CHANGE;
			Msg.Header.Size     = sizeof(sStateChangeMessage);
			Msg.Header.PlayerID = m_Players[0].dpnidPlayer;
			Msg.State           = STATE_SWING;
			Msg.Direction       = m_Players[0].Direction;
			Msg.AtMap							= m_Players[0].AtMap;
			Msg.Career						= m_Players[0].Career;
			Msg.WP								= m_Players[0].WP;


      // Send message to server
			SendNetworkMessage(&Msg, DPNSEND_NOLOOPBACK);
		}

    // Process local player movements
		if((Dir = MoveAction) > 0 && Dir < 13) 
		{
      // Set new player state (w/time and direction)
			EnterCriticalSection(&m_UpdateCS);
			m_Players[0].State     = STATE_MOVE;
			//--------------------------------------------------------------------- �����V
			m_Players[0].Direction = Angles[Dir];
			LeaveCriticalSection(&m_UpdateCS);

      // Reset last move if camera moved since last update
			if(CamMoved == TRUE) 
			{
				CamMoved = FALSE;
				LastMove = 0;
			}

      // Send actions to server if changed from last move
			if(MoveAction != LastMove) 
			{
				LastMove = MoveAction;  // Store last action
				m_Players[0].Time = timeGetTime();

        // Construct message
				sStateChangeMessage Msg;
				Msg.Header.Type     = MSG_STATE_CHANGE;
				Msg.Header.Size     = sizeof(sStateChangeMessage);
				Msg.Header.PlayerID = m_Players[0].dpnidPlayer;
				Msg.State           = STATE_MOVE;
				Msg.Direction       = m_Players[0].Direction;
				Msg.AtMap       = m_Players[0].AtMap;
				Msg.Career      = m_Players[0].Career;
				Msg.WP      = m_Players[0].WP;

        // Send message to server
				SendNetworkMessage(&Msg, DPNSEND_NOLOOPBACK);
			}
		}else{
      // Change to idle state
			if(m_Players[0].State== STATE_SWAPWP){
			}else{
				EnterCriticalSection(&m_UpdateCS);
				m_Players[0].State = STATE_IDLE;
				LeaveCriticalSection(&m_UpdateCS);
			}
      // Send update only if player moved last update
			if(LastMove) 
			{
				LastMove = 0;
				sStateChangeMessage Msg;
		        Msg.Header.Type     = MSG_STATE_CHANGE;
				Msg.Header.Size     = sizeof(sStateChangeMessage);
		        Msg.Header.PlayerID = m_Players[0].dpnidPlayer;
				Msg.State           = m_Players[0].State;
		        Msg.Direction       = m_Players[0].Direction;
				Msg.AtMap       = m_Players[0].AtMap;
				Msg.Career      = m_Players[0].Career;
				Msg.WP      = WantWP;
        // Send message to server
				SendNetworkMessage(&Msg, DPNSEND_NOLOOPBACK);
			}
		}
	}
  // Update all players
	UpdatePlayers();

  // Render the scene
	RenderScene();

	MoveAction = 0; // Clear action data for next frame

	UpdateCounter = timeGetTime(); // Reset update counter

	return TRUE;
}


BOOL cMainApp::PlaySound(long Num)
{
  if(Num >=0 && Num < NUM_SOUNDS) {
    m_SoundData.Free();

    if(m_SoundData.LoadWAV(g_SoundFilenames[Num]) == TRUE)
      m_SoundChannel.Play(&m_SoundData);

    return TRUE;
  }

  return FALSE;
}

BOOL cMainApp::PlayMusic(long Num)
{
  // Don't bother changing song if same already playing
  if(g_CurrentMusic == Num)
    return TRUE;

  // Stop and free current song
  m_MusicChannel.Stop();
  m_MusicChannel.Free();

  // Fade music out, giving DirectMusic enough time
  // to finish up last song (or else new song doesn't
  // play correctly.  The 700 is based on play volume
  // of music, so adjust ahead.
  DWORD Timer = timeGetTime() + 700;
  while(timeGetTime() < Timer) {
    DWORD Level = (Timer - timeGetTime()) / 10;
    m_MusicChannel.SetVolume(Level);
  }

  // Load and play new song
  m_MusicChannel.Load(g_MusicFilenames[Num]);
  m_MusicChannel.Play(70,0);

  // Remember new song #
  g_CurrentMusic = Num;

  return TRUE;
}

BOOL cMainApp::StopMusic()
{
  // Stop and free music, marking current song as none
  m_MusicChannel.Stop();
  m_MusicChannel.Free();
  g_CurrentMusic = -1;

  return TRUE;
}

float cMainApp::GetHeightBelow(float XPos, float YPos, float ZPos)
{
  BOOL  Hit;
  float u, v, Dist;
  DWORD FaceIndex;

  D3DXIntersect(m_SceneMesh[m_Players[0].AtMap].GetParentMesh()->m_Mesh, 
                &D3DXVECTOR3(XPos,YPos,ZPos),
                &D3DXVECTOR3(0.0f, -1.0f, 0.0f),
                &Hit, &FaceIndex, &u, &v, &Dist,NULL,NULL);
  if(Hit == TRUE)
    return YPos-Dist;
  return YPos;
}

BOOL cMainApp::CheckIntersect(float XStart, float YStart, float ZStart,
                          float XEnd,   float YEnd,   float ZEnd,
                          float *Length)
{
  BOOL  Hit;
  float u, v, Dist;
  float XDiff, YDiff, ZDiff, Size;
  DWORD FaceIndex;
  D3DXVECTOR3 vecDir;

  XDiff = XEnd - XStart;
  YDiff = YEnd - YStart;
  ZDiff = ZEnd - ZStart;

  D3DXVec3Normalize(&vecDir, &D3DXVECTOR3(XDiff, YDiff, ZDiff));
  D3DXIntersect(m_SceneMesh[m_Players[0].AtMap].GetParentMesh()->m_Mesh, 
                &D3DXVECTOR3(XStart,YStart,ZStart), &vecDir,
                &Hit, &FaceIndex, &u, &v, &Dist,NULL,NULL);

  if(Hit == TRUE) {
    Size = (float)sqrt(XDiff*XDiff+YDiff*YDiff+ZDiff*ZDiff);
    if(Dist > Size)
      Hit = FALSE;
    else {
      if(Length != NULL)
        *Length = Dist;
    }
  }

  return Hit;
}

bool Login()
{
		char t_fullscreen[4];
		FILE	*fp;
		fp = fopen("config.txt","r"); 
			if (!fp)	return 0;
			// �]�w�O�_���ù�
			fgets(t_fullscreen,32,fp);
			t_fullscreen[strlen(t_fullscreen)-1] = '\0';
			// Ū�J�H������
			//fgets(t_role,32,fp);
			//t_role[strlen(t_role)-1] = '\0';
			fclose(fp);
	
			FULLSCREENMODE = atoi(t_fullscreen);
		//MB(	t_fullscreen);
			
		return 1;
}

BOOL CALLBACK ConnectDialogProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  switch(uMsg) {
    case WM_INITDIALOG:
	SetWindowText(GetDlgItem(hWnd, IDC_IP),   "140.131.7.89");
    SetWindowText(GetDlgItem(hWnd, IDC_USERID), "goodspeed");
	SetWindowText(GetDlgItem(hWnd, IDC_USERPASSWORD),   "789789789");
		return TRUE;

    case WM_COMMAND:
		{
			switch(LOWORD(wParam)) {
				case IDC_LOGIN:
				// �P�_ip�O�_���T
				GetWindowText(GetDlgItem(hWnd,IDC_IP),ServerIP,16);
				if(!strlen(ServerIP))
				{
					MB("�z����J���A����}�I");
					break;
				}
				// �P�_�b���O�_���T
				GetWindowText(GetDlgItem(hWnd,IDC_USERID),UserName,32);
				if(!strlen(UserName))
				{
					MB("�z����J�b���I");
					break;
				}
				// �P�_�K�X�O�_���T
				GetWindowText(GetDlgItem(hWnd,IDC_USERPASSWORD),UserPsw,32);
				if(!strlen(UserPsw))
				{
					MB("�z����J�K�X�I");
					break;
				}
				if (!Login()){
					break;
				}

			EndDialog(hWnd, TRUE);
			return TRUE;
			break;
			case IDC_CANCEL:
					EndDialog(hWnd, TRUE);
			return TRUE;
			break;
			}
		}
  }
  return FALSE;
}

void cMainApp::SetAnim(int i,int anim)
{
	char* ANIM[5]={"UNKNOW","Idle","Walk","Swing","Hurt"};
	switch(m_Players[i].Career){
		case ASS:m_Players[i].Body.SetAnimation(                     \
			  &m_CharMesh[m_Players[i].Career].m_CharacterAnim, ANIM[anim], timeGetTime() / 32);
				break;
		case UNKNOW:m_Players[i].Body.SetAnimation(                     \
			  &m_CharMesh[m_Players[i].Career].m_CharacterAnim, ANIM[anim], timeGetTime() / 32);
				break;
		default:m_Players[i].Body.SetAnimation(                     \
		  &m_CharMesh[m_Players[i].Career].m_CharacterAnim, ANIM[anim], timeGetTime() / 32);
		  break;
	}
	
}
void cMainApp::InitMenu(void)
{
	int i=0;
	char Filename[81];

	// ���A�C
	for (i=0;i<3;i){
		sprintf(Filename,"..\\DATA\\UI\\alltitle1%u.jpg",i+1);
		UI[i].Load(&m_Graphics,Filename);
		if (UI[i].IsLoaded())
			i++;
	}
}

void cMainApp::SetInfo(GUID *Adapter, char *IP, char *Name,char *UserPsw)
{
  m_guidAdapter = Adapter;
  strcpy(m_HostIP, IP);
  strcpy(m_Name, Name);
  strcpy(m_Psw, UserPsw);
}

///////////////////////////////////////////////////////////
// Misc. application functions
///////////////////////////////////////////////////////////
long cMainApp::GetPlayerNum(DPNID dpnidPlayer)
{
  long i;

  // Error checking
  if(m_Players == NULL)
    return -1;

  // Scan list looking for match
  for(i=0;i<MAX_PLAYERS;i++) {
    if(m_Players[i].dpnidPlayer == dpnidPlayer &&             \
       m_Players[i].Connected == TRUE)
      return i;
  }

  return -1;  // Not found in list
}

///////////////////////////////////////////////////////////
// Network send and receive functions
///////////////////////////////////////////////////////////
BOOL cMainApp::SendNetworkMessage(void *Msg, long SendFlags)
{
  sMessageHeader *mh = (sMessageHeader*)Msg;
  unsigned long Size;

  // Get size of message to send
  if((Size = mh->Size) == 0)
    return FALSE;

  // Send the mesage
  return m_Client.Send(Msg, Size, SendFlags);
}

BOOL cMainApp::Receive(DPNMSG_RECEIVE *Msg)
{
  sMessage *MsgPtr;

  // Get pointer to received data
  MsgPtr = (sMessage*)Msg->pReceiveData;

  // Handle packets by type
  switch(MsgPtr->Header.Type) {
    case MSG_ASSIGNID: // Assign local player ID
	  AssignID(MsgPtr);
      break;

    case MSG_PLAYER_INFO:    // Add a player to list
    case MSG_CREATE_PLAYER:
      CreatePlayer(MsgPtr);
      break;

    case MSG_DESTROY_PLAYER: // Remove a player from list
      DestroyPlayer(MsgPtr);
      break;

    case MSG_STATE_CHANGE:   // Change state of player
      ChangeState(MsgPtr);
      break;
	case MSG_CHATING :
		
	test++;
		ShowText(MsgPtr);
	  break;
  }

  return TRUE;
}

///------------------------------------------------------------------------
// 
// �T�����R
///------------------------------------------------------------------------

void cMainApp::ShowText(sMessage *Msg)
{
	sShowText *stm = (sShowText*)Msg;
  for(int row=Textrow-1;row >0;row--)
  {
	  strcpy(TextBuffer[row],TextBuffer[row-1]);
  }
  strcpy(TextBuffer[row],stm->text);
}
void cMainApp::AssignID(sMessage *Msg)
{
  sAssignPlayerIDMessage *apidm;

  if(m_Players == NULL || m_Players[0].dpnidPlayer)
    return;

	// ���o�T������
  apidm = (sAssignPlayerIDMessage*)Msg;

  EnterCriticalSection(&m_UpdateCS);
  m_Players[0].dpnidPlayer = apidm->Header.PlayerID;
  LeaveCriticalSection(&m_UpdateCS);
}


int cMainApp::CreatePlayer(sMessage *Msg)
{
  sCreatePlayerMessage *cpm;
  long PlayerNum, i;

  if(m_Players == NULL || !m_Players[0].dpnidPlayer)
    return 0;

  // ���o�T������
  cpm = (sCreatePlayerMessage*)Msg;

  // Don't add local player to list
  if(cpm->Header.PlayerID == m_Players[0].dpnidPlayer)
    return	0;

  // �T�w�O�_���ۦP���a�W�٩���C�õ����Ū�slot
  PlayerNum = -1;
  for(i=1;i<MAX_PLAYERS;i++) {
    if(m_Players[i].Connected == TRUE) {
      if(m_Players[i].dpnidPlayer==cpm->Header.PlayerID)
        return 0;
    } else
      PlayerNum = i;
  }

 
	// �S���Ū�slot
  if(PlayerNum == -1)
    return 0;

  EnterCriticalSection(&m_UpdateCS);
  // �[�J���a���
  m_Players[PlayerNum].Connected   = TRUE;
  m_Players[PlayerNum].dpnidPlayer = cpm->Header.PlayerID;
  m_Players[PlayerNum].XPos        = cpm->XPos;
  m_Players[PlayerNum].YPos        = cpm->YPos;
  m_Players[PlayerNum].ZPos        = cpm->ZPos;
  m_Players[PlayerNum].AtMap       = cpm->AtMap;
  if(m_Players[PlayerNum].Career != cpm->Career)
  {
	m_Players[PlayerNum].Career = cpm->Career;
	ChangeCharMesh(&m_Players[PlayerNum]);
  }
  if(m_Players[PlayerNum].WP     != cpm->WP)
  {
	m_Players[PlayerNum].WP     =cpm->WP;
	ChangeWeaponMesh(&m_Players[PlayerNum]);
  }
  m_Players[PlayerNum].Direction   = cpm->Direction;
  m_Players[PlayerNum].Speed       = 0.0f;
  m_Players[PlayerNum].State       = STATE_IDLE;
  m_NumPlayers++;
  LeaveCriticalSection(&m_UpdateCS);

  return 1;
}

void cMainApp::DestroyPlayer(sMessage *Msg)
{
  sDestroyPlayerMessage *dpm;
  long PlayerNum;

  if(m_Players == NULL || !m_Players[0].dpnidPlayer)
    return;

  // ���o�T������
  dpm = (sDestroyPlayerMessage*)Msg;

  // Don't remove local player from list
  if(dpm->Header.PlayerID == m_Players[0].dpnidPlayer)
    return;

  // ���o���a��ID����C 
  if((PlayerNum = GetPlayerNum(dpm->Header.PlayerID)) == -1)
    return;

  EnterCriticalSection(&m_UpdateCS);

	// �]�w���a�S���i��s�u
  m_Players[PlayerNum].Connected = FALSE;
  m_NumPlayers--;
	

	LeaveCriticalSection(&m_UpdateCS);
}
int cc=0;
void cMainApp::ChangeState(sMessage *Msg)
{
  sStateChangeMessage *scm;
  sRequestPlayerInfoMessage rpim;
  long PlayerNum;

  if(m_Players == NULL || !m_Players[0].dpnidPlayer)
    return;

  scm = (sStateChangeMessage*)Msg;

  // ���o���a���X����C
  if((PlayerNum = GetPlayerNum(scm->Header.PlayerID)) == -1) {
    // �ШD�������a����T
    if(PlayerNum == -1) {
      // �غc�T��
      rpim.Header.Type = MSG_PLAYER_INFO;
      rpim.Header.Size = sizeof(sRequestPlayerInfoMessage);
      rpim.Header.PlayerID = m_Players[0].dpnidPlayer;
      rpim.PlayerID = scm->Header.PlayerID;

      // �ǰe�����
      SendNetworkMessage(&rpim, DPNSEND_NOLOOPBACK);

      return;
    }
  }


	EnterCriticalSection(&m_UpdateCS);
	if(m_Players[0].dpnidPlayer==scm->Header.PlayerID){
		switch(scm->State)
		{
		case STATE_START:if(m_Players[0].State != scm->State){
							if(scm->Career == UNKNOW){
								 LoadMap(50);
							 }else{
								 if(scm->Career == ASS){
									 LoadMap(68);
								 }else{
									 LoadMap(69);
								 }
							 }
						 }
						 break;
			case STATE_CHOOSING:if(m_Players[0].State != scm->State){
									LoadMap(51);
								}
								break;
			case STATE_CHOOSINGL:if(m_Players[0].State != scm->State){
									LoadMap(52);
								 }
								
							     break;
			case STATE_CHOOSINGR:if(m_Players[0].State != scm->State){
									LoadMap(60);
								 }
								 break;
			case STATE_PLAYGAME:if(m_Players[0].State !=STATE_PLAYGAME)
								{
									LoadMap(m_Players[0].AtMap);
									m_MusicChannel.Stop();
									PlayMusic(m_Players[0].AtMap /25 +1); 
									UI[0].Load(&m_Graphics,"..\\DATA\\UI\\�D����1.jpg");
									UI[1].Load(&m_Graphics,"..\\DATA\\UI\\�D����2.jpg");
									if(m_Players[0].AtMap /25 ==0)
										UI[2].Load(&m_Graphics,"..\\DATA\\UI\\�D����3.jpg");
									else
										UI[2].Load(&m_Graphics,"..\\DATA\\UI\\�D����4.jpg");
								//ChangeCharMesh(&m_Players[0]);
								//ChangeWeaponMesh(&m_Players[0]);
									m_SceneObject.Create(&m_Graphics, &m_SceneMesh[scm->AtMap]);
								}
									
								break;

		}
		if( !(scm->State>4 && scm->State<15) && m_Players[0].AtMap != scm->AtMap && m_Players[0].State != UNKNOW)
		{
			LoadMap(scm->AtMap);
			m_SceneObject.Create(&m_Graphics, &m_SceneMesh[scm->AtMap]);
		}
		if(m_Players[0].AtMap /25 != scm->AtMap/25 && !(scm->State>4 && scm->State<15)&& m_Players[0].State != UNKNOW)
		{
			if(scm->AtMap/25 ==0)
				UI[2].Load(&m_Graphics,"..\\DATA\\UI\\�D����3.jpg");
			else
				UI[2].Load(&m_Graphics,"..\\DATA\\UI\\�D����4.jpg");

			m_MusicChannel.Stop();
			PlayMusic((int)(scm->AtMap /25) +1);

		}
	}

	// �ثe���A
	if(PlayerNum==0 && m_Players[0].HP > scm->HP){ 
		PlaySound(1);
	}
	m_Players[PlayerNum].HP				= scm->HP;
	m_Players[PlayerNum].SP				= scm->SP;	
	m_Players[PlayerNum].Exp			= scm->Exp;
	m_Players[PlayerNum].MaxHP		=	scm->MaxHP;
	m_Players[PlayerNum].MaxSP		= scm->MaxSP;
	m_Players[PlayerNum].Exp			=	scm->Exp;
	m_Players[PlayerNum].NextExp	= scm->NextExp;
  // Store new sytate info
	m_Players[PlayerNum].Time      = timeGetTime();
	m_Players[PlayerNum].State     = scm->State;
	m_Players[PlayerNum].XPos      = scm->XPos;
	m_Players[PlayerNum].YPos      = scm->YPos;
	m_Players[PlayerNum].ZPos      = scm->ZPos;
	strcpy(m_Players[PlayerNum].Name,scm->Name);
	m_Players[PlayerNum].AtMap      = scm->AtMap;
	
	if(m_Players[PlayerNum].Career != scm->Career)
	{
		m_Players[PlayerNum].Career = scm->Career;
		//if(PlayerNum == 0 && m_Players[PlayerNum].State != UNKNOW && !(m_Players[PlayerNum].State>=5 && m_Players[PlayerNum].State <13))
		//{
			ChangeCharMesh(&m_Players[PlayerNum]);
			ChangeWeaponMesh(&m_Players[PlayerNum]);
		//}else
	}
	if(m_Players[PlayerNum].WP     != scm->WP)
	{
		//if(m_Players[PlayerNum].State != UNKNOW && !(m_Players[PlayerNum].State>=5 && m_Players[PlayerNum].State <13))
		//{
			m_Players[PlayerNum].WP     =scm->WP;
			ChangeWeaponMesh(&m_Players[PlayerNum]);
		//}
	 }
  m_Players[PlayerNum].EQ1     =scm->EQ1;
  m_Players[PlayerNum].EQ2     =scm->EQ2;
  m_Players[PlayerNum].EQ3     =scm->EQ3;
  m_Players[PlayerNum].Mon     =scm->Mon;
  m_Players[PlayerNum].Level     =scm->Level;
  m_Players[PlayerNum].Direction = scm->Direction;
  m_Players[PlayerNum].Speed     = scm->Speed;
  m_Players[PlayerNum].Latency   = scm->Latency;
	// �̤jlatency�@���ɶ�
  if(m_Players[PlayerNum].Latency > 1000)
    m_Players[PlayerNum].Latency = 1000;

	// �վ�ɶ�latency���D
  m_Players[PlayerNum].Time -= m_Players[PlayerNum].Latency;

	LeaveCriticalSection(&m_UpdateCS);
}

///------------------------------------------------------------------------
// 
// �C���B�z
///------------------------------------------------------------------------
void cMainApp::UpdatePlayers()
{
  long  i;
  float XMove=0.0f, ZMove=0.0f, Dist=0.0f, Speed=0.0f;
  long Elapsed;

  
	// �B�z��s�Ҧ����ʪ����a
  for(i=0;i<MAX_PLAYERS;i++) {
    //if(m_Players[i].Connected == TRUE && m_Players[i].AtMap==m_Players[0].AtMap) {
	if(m_Players[i].Connected == TRUE) {
			// ���o���u�ɶ�
      Elapsed = timeGetTime() - m_Players[i].Time;

			// �B�z���a�ʧ@���A
      if(m_Players[i].State == STATE_MOVE) {
				// �p�Ⲿ��
        Speed = (float)Elapsed / 1000.0f * m_Players[i].Speed;
				XMove = (float)sin(m_Players[i].Direction) * Speed;
        ZMove = (float)cos(m_Players[i].Direction) * Speed;

        if(m_Players[i].AtMap==m_Players[0].AtMap){
				// mesh�I������
        if(CheckIntersect(
                            m_Players[i].XPos,
                            m_Players[i].YPos + 8.0f,
                            m_Players[i].ZPos,
                            m_Players[i].XPos + XMove,
                            m_Players[i].YPos + 8.0f,
                            m_Players[i].ZPos + ZMove,
                            &Dist) == TRUE)
          XMove = ZMove = 0.0f;
		}

				// ��s�y��
        EnterCriticalSection(&m_UpdateCS);
        m_Players[i].XPos += XMove;
        m_Players[i].YPos = 0.0f;
        m_Players[i].ZPos += ZMove;
        m_Players[i].Time = timeGetTime(); // ���]�ɶ�
        LeaveCriticalSection(&m_UpdateCS);
      } 

//	if(XMove != 0.0f || ZMove != 0.0f) {
			// �]�w�����ʧ@
			if(m_Players[i].State == STATE_IDLE) {
				if(m_Players[i].LastAnim != ANIM_IDLE) {
					EnterCriticalSection(&m_UpdateCS);
					m_Players[i].LastAnim = ANIM_IDLE;
					SetAnim(i,ANIM_IDLE);
					LeaveCriticalSection(&m_UpdateCS);
				}
			} else
				if(m_Players[i].State == STATE_MOVE) {
					if(m_Players[i].LastAnim != ANIM_WALK) {
						EnterCriticalSection(&m_UpdateCS);
						m_Players[i].LastAnim = ANIM_WALK;
						SetAnim(i,ANIM_WALK);
						LeaveCriticalSection(&m_UpdateCS);
					}
	} else
      if(m_Players[i].State == STATE_SWING) {
        if(m_Players[i].LastAnim != ANIM_SWING) {
          EnterCriticalSection(&m_UpdateCS);
          m_Players[i].LastAnim = ANIM_SWING;
          SetAnim(i,ANIM_SWING);

          LeaveCriticalSection(&m_UpdateCS);
        }
      } else
      if(m_Players[i].State == STATE_HURT) {
        if(m_Players[i].LastAnim != ANIM_HURT) {
          EnterCriticalSection(&m_UpdateCS);
          m_Players[i].LastAnim = ANIM_HURT;
          SetAnim(i,ANIM_HURT);

          LeaveCriticalSection(&m_UpdateCS);
        }
      }

   }
		}
 // }
}


void cMainApp::RenderScene()
{
  float Radius;
  long i,j;
	float XPos, YPos, ZPos;
	char ShowText[10];

	// �վ���������m
  //m_Camera.Move(0.0f, 200.0f, -650.0f);
	m_Camera.Move(0.0f, 200.0f, -650.0f);
  m_Camera.Rotate(0.348888f, 0.0f, 0.0f);
  m_Graphics.SetCamera(&m_Camera);


	// ø�X����
  m_Graphics.Clear();
  if( m_Players[0].State != UNKNOW && m_Graphics.BeginScene() == TRUE) {
	m_Graphics.EnableZBuffer(TRUE);
    m_SceneObject.Render();
    m_Graphics.EnableZBuffer(FALSE);
		m_Graphics.BeginSprite();

	for(i=0;i<6;i) {
        m_BDTextures[i].IsLoaded();
		i++;
    }
		// �I��
    for(i=0;i<2;i++) {
      for(j=0;j<3;j++)
        m_BDTextures[i*3+j].Blit(j*256,i*256+65);
    }
		// ����
		for(j=0;j<3;j++)
			UI[j].Blit(j*255,0,0,0,0,0,1,0.5,0xFFFFFFFF);
	
	
	
	for(int row=0;row<Textrow;row++)
	{
		m_Font.Print(TextBuffer[row],20,200-(15*(row)));
//		MB("TextBuffer[row]");
	}
//	m_Font.Print("��ܤ��e�G",20,380);
	m_Font.Print(LocalText,20,380);

    m_Graphics.EndSprite();

		m_Graphics.EnableZBuffer(TRUE);
		XPos = m_Players[i].XPos;
		YPos = m_Players[i].YPos;
		ZPos = m_Players[i].ZPos;
	if(m_Players[0].State == STATE_START && m_Players[0].Career != UNKNOW)
	{
		m_Font.Print(m_Players[0].Name,480,200,100,0,0xFF000000,DT_LEFT);
		m_Font.Print(itoa(m_Players[0].Level,ShowText,10), 480,230,50,0,0xFF000000,DT_LEFT);
		m_Font.Print(itoa(m_Players[0].Mon,ShowText,10), 480,260,50,0,0xFF000000,DT_LEFT);

	}
	if(m_Players[0].State!=UNKNOW && !(m_Players[0].State >4 && m_Players[0].State<13))
		// ø�X�Ҧ�����
    for(i=0;i<MAX_PLAYERS;i++) {
      if(m_Players[i].Connected == TRUE && m_Players[i].AtMap==m_Players[0].AtMap) {
//if(m_Players[i].Connected == TRUE ) {
        // Bounds check if player in view
		  if(m_Players[i].Career != UNKNOW && !(m_Players[0].State >=5 && m_Players[0].State<12) && m_Players[0].State != UNKNOW){
				if(EQmenu){
					m_Font.Print("�i�󴫸˳�", 100,100,100,0,0xFF00FFFF,DT_LEFT);
					m_Font.Print("F2 :", 80,120,50,0,0xFFFF00A5,DT_LEFT);
					m_Font.Print("F3 :", 80,140,50,0,0xFFFF00A5,DT_LEFT);
					m_Font.Print("F4 :", 80,160,50,0,0xFFFF00A5,DT_LEFT);
					m_Font.Print(WPName[m_Players[0].EQ1], 110,120,100,0,0xFF000000,DT_LEFT);
					m_Font.Print(WPName[m_Players[0].EQ2], 110,140,100,0,0xFF000000,DT_LEFT);
					m_Font.Print(WPName[m_Players[0].EQ3], 110,160,100,0,0xFF000000,DT_LEFT);
				}
				m_Font.Print("�E", 547+(m_Players[0].AtMap%5*15),5+((m_Players[0].AtMap%25)/5*9),50,0,0xFFFF44FF,DT_LEFT);
				m_Font.Print(m_Players[0].Name, 90,5,100,0,0xFF000000,DT_LEFT);
				m_Font.Print(itoa(m_Players[0].Level,ShowText,10), 250,5,50,0,0xFF000000,DT_LEFT);
				m_Font.Print(itoa(m_Players[0].AtMap,ShowText,10), 380,5,50,0,0xFF000000,DT_LEFT);

				m_Font.Print(itoa(m_Players[0].Exp,ShowText,10), 105,22,50,0,0xFF000000,DT_LEFT);
				m_Font.Print(itoa(m_Players[0].NextExp,ShowText,10), 295,22,50,0,0xFF000000,DT_LEFT);
				m_Font.Print(WPName[m_Players[0].WP], 460,22,100,0,0xFF000000,DT_LEFT);

				m_Font.Print(itoa(m_Players[0].HP,ShowText,10), 180,40,50,0,0xFF000000,DT_LEFT);
				m_Font.Print(itoa(m_Players[0].MaxHP,ShowText,10), 220,40,50,0,0xFF000000,DT_LEFT);
				m_Font.Print(itoa(m_Players[0].SP,ShowText,10), 450,40,50,0,0xFF000000,DT_LEFT);
				m_Font.Print(itoa(m_Players[0].MaxSP,ShowText,10), 490,40,50,0,0xFF000000,DT_LEFT);
				m_Players[i].Body.GetBounds(NULL,NULL,NULL,NULL,      \
                                    NULL,NULL,&Radius);
				
				// �����m�M���� 
				GetHeightBelow(XPos,YPos+64.0f,ZPos);
				m_Players[i].Body.Move(m_Players[i].XPos,	m_Players[i].YPos,m_Players[i].ZPos);
				m_Players[i].Body.Rotate(0.0f, m_Players[i].Direction, 0.0f);
    
		  // ø�X����M�Z��
				m_Players[i].Body.UpdateAnimation(timeGetTime()/32, TRUE);
				m_Players[i].Body.Render();
			if(m_Players[i].WP != UNKNOW)
				m_Players[i].Weapon.Render();
		  }

      }
    }

    m_Graphics.EndScene();
  }

  m_Graphics.Display();  // ��ܥX�Ҧ�����
}

///------------------------------------------------------------------------
// 
// Client class
///------------------------------------------------------------------------
BOOL cClient::ConnectComplete(DPNMSG_CONNECT_COMPLETE *Msg) 
{ 
  // �x�s�s�u���A
  if(Msg->hResultCode == S_OK)
    g_Connected = TRUE;
  else
    g_Connected = FALSE;

  return TRUE; 
}

BOOL cClient::Receive(DPNMSG_RECEIVE *Msg)
{
	// �ǰe�T�������ε{��
  if(g_Application != NULL)
    g_Application->Receive(Msg);
  return TRUE;
}

FAR PASCAL cMainApp::MsgProc(HWND hWnd, UINT uMsg,                \
                         WPARAM wParam, LPARAM lParam)
{
  switch(uMsg) {
    case WM_DESTROY:
      PostQuitMessage(0);
      break;
    default: return DefWindowProc(hWnd, uMsg, wParam, lParam);
  }

  return 0;
} 
// �{���i�J�I
int PASCAL WinMain(HINSTANCE hInst,HINSTANCE hPrev,LPSTR szCmdLine,int nShowCmd)
{
	cMainApp app;

	return app.Run();
}
