using System;
using System.Data;
using System.IO;
using System.Text;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace User_Login
{
	[Guid("0E8EA43F-B050-4896-8D16-9C20BCD4A80A")]
	public interface DBCOM_User_Login_Interface
	{
		[DispId(1)]
		bool User_Login(string id , string password);
		[DispId(2)]
		string User_GetValue(int pos);
	}
	// Events interface Database_COMObjectEvents 
	[Guid("8101D337-5391-4f7d-9F9B-3EF70719120D"), 
	InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
	public interface DBCOM_Events 
	{
	}
	[Guid("D5AEA79C-3DFC-485b-9A64-08AC200B4516"),
	ClassInterface(ClassInterfaceType.None),
	ComSourceInterfaces(typeof(DBCOM_Events))]
	public class DBCOM_User_Login_Class : DBCOM_User_Login_Interface
	{
		string a,b,c,e,d,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;
		//�ŧiSP_Login()���,���e�ݵ{���n��	
		public bool User_Login(string id , string password)
		{
			try
			{
				//�ŧi�s���r��
				String strConnection="server=localhost;database=game;uid=game_user;pwd=4321;";
				//�ŧi�s������
				SqlConnection objConnection=new SqlConnection(strConnection);
				//�}�ҳs��
				objConnection.Open();
				//�ŧi�R�O����,����SP-->sp_get_user_value
				SqlCommand objCommand=new SqlCommand("sp_get_user_value",objConnection);
				//�]�w�R�O���󪺫��A��StoreProcedure
				objCommand.CommandType=CommandType.StoredProcedure;
				//�ŧi�Ѽƪ���Parameters
				//�H�w�x�{��sp_get_user_value���Xuser_value table�������a�ݩ�
				//�ŧi�Ѽƪ���-->@get_id(���a�b��)
				objCommand.Parameters.Add(new SqlParameter("@get_id",SqlDbType.Char,16));
				objCommand.Parameters["@get_id"].Value=id;
				//�ŧi�Ѽƪ���-->@get_password(���a�K�X)
				objCommand.Parameters.Add(new SqlParameter("@get_password",SqlDbType.Char,16));
				objCommand.Parameters["@get_password"].Value=password;
				//�ŧi�Ѽƪ���-->@get_pet_name(���a�ʺ�)
				objCommand.Parameters.Add(new SqlParameter("@get_pet_name",SqlDbType.Char,32));
				//�ŧi�Ѽƪ���-->@get_use_equipment(���a�ثe�ϥθ˳�)
				objCommand.Parameters.Add(new SqlParameter("@get_use_equipment",SqlDbType.Int));
				//�ŧi�Ѽƪ���-->@get_user_kind(���a����)
				objCommand.Parameters.Add(new SqlParameter("@get_user_kind",SqlDbType.Int));
				//�ŧi�Ѽƪ���-->@get_map_id(�a�Ͻs��)
				objCommand.Parameters.Add(new SqlParameter("@get_map_id",SqlDbType.Int));
				//�ŧi�Ѽƪ���-->@get_coordinage_x(���a�y��_x)
				objCommand.Parameters.Add(new SqlParameter("@get_coordinage_x",SqlDbType.Int));
				//�ŧi�Ѽƪ���-->@get_coordinage_y(���a�y��_y)
				objCommand.Parameters.Add(new SqlParameter("@get_coordinage_y",SqlDbType.Int));
				//�ŧi�Ѽƪ���-->@get_coordinage_z(���a�y��_z)
				objCommand.Parameters.Add(new SqlParameter("@get_coordinage_z",SqlDbType.Int));
				//�ŧi�Ѽƪ���-->@get_money(���a����)
				objCommand.Parameters.Add(new SqlParameter("@get_money",SqlDbType.Int));
				//�ŧi�Ѽƪ���-->@get_grade(���a����)
				objCommand.Parameters.Add(new SqlParameter("@get_grade",SqlDbType.Int));
				//�ŧi�Ѽƪ���-->@get_experience_value(���a�g���)
				objCommand.Parameters.Add(new SqlParameter("@get_experience_value",SqlDbType.Int));
				//�ŧi�Ѽƪ���-->@get_advance_exper(���a�ɯũһݸg���)
				objCommand.Parameters.Add(new SqlParameter("@get_advance_exper",SqlDbType.Int));
				//�ŧi�Ѽƪ���-->@get_strength(���a�O�q)
				objCommand.Parameters.Add(new SqlParameter("@get_strength",SqlDbType.Int));
				//�ŧi�Ѽƪ���-->@get_coonstitation(���a���)
				objCommand.Parameters.Add(new SqlParameter("@get_coonstitation",SqlDbType.Int));
				//�ŧi�Ѽƪ���-->@get_money(���a���z)
				objCommand.Parameters.Add(new SqlParameter("@get_intelligence",SqlDbType.Int));
				//�ŧi�Ѽƪ���-->@get_speed(���a�t��)
				objCommand.Parameters.Add(new SqlParameter("@get_speed",SqlDbType.Int));
				//�ŧi�Ѽƪ���-->@get_blood(���a��q)
				objCommand.Parameters.Add(new SqlParameter("@get_blood",SqlDbType.Int));
				//�ŧi�Ѽƪ���-->@get_max_blood(���a�̤j��q)
				objCommand.Parameters.Add(new SqlParameter("@get_max_blood",SqlDbType.Int));
				//�ŧi�Ѽƪ���-->@get_magic(���a�k�O)
				objCommand.Parameters.Add(new SqlParameter("@get_magic",SqlDbType.Int));
				//�ŧi�Ѽƪ���-->@get_max_magic(���a�̤j�k�O��)				   
				objCommand.Parameters.Add(new SqlParameter("@get_max_magic",SqlDbType.Int));
				//�ŧi�Ѽƪ���Parameters
				//�H�w�x�{��sp_get_user_value���Xequipment table�����˳��ݩ�
				//�ŧi�Ѽƪ���-->@get_equipment_id(�˳ƽs��)
				//   objCommand.Parameters.Add(new SqlParameter("@get_equipment_id",SqlDbType.Char,3));
				//�ŧi�Ѽƪ���-->@get_equipment_name(�˳ƦW��)
				objCommand.Parameters.Add(new SqlParameter("@get_equipment_name",SqlDbType.Char,16));
				//�ŧi�Ѽƪ���-->@get_equipment_power(�˳ƤO�q)
				objCommand.Parameters.Add(new SqlParameter("@get_equipment_power",SqlDbType.Int));
				//�ŧi�Ѽƪ���-->@get_equipment_class(�˳ƺ���)
				//�ŧi����SP�Ǧ^�Ȫ��Ѽ�@retval=>�Ǧ^�O�񵧼�
				objCommand.Parameters.Add(new SqlParameter("@retval",SqlDbType.Int));
			
				
				//�HParameters����Ҵ��Ѫ�Direction�ݩ�,����ParameterDircetion�M�椤���� 
				//���X��user_value table�����a�ݩʭ�
				objCommand.Parameters["@get_pet_name"].Direction=ParameterDirection.Output;
				objCommand.Parameters["@get_use_equipment"].Direction=ParameterDirection.Output;
				objCommand.Parameters["@get_user_kind"].Direction=ParameterDirection.Output;
				objCommand.Parameters["@get_map_id"].Direction=ParameterDirection.Output;
				objCommand.Parameters["@get_coordinage_x"].Direction=ParameterDirection.Output;
				objCommand.Parameters["@get_coordinage_y"].Direction=ParameterDirection.Output;
				objCommand.Parameters["@get_coordinage_z"].Direction=ParameterDirection.Output;
				objCommand.Parameters["@get_money"].Direction=ParameterDirection.Output;
				objCommand.Parameters["@get_grade"].Direction=ParameterDirection.Output;
				objCommand.Parameters["@get_experience_value"].Direction=ParameterDirection.Output;
				objCommand.Parameters["@get_advance_exper"].Direction=ParameterDirection.Output;
				objCommand.Parameters["@get_strength"].Direction=ParameterDirection.Output;
				objCommand.Parameters["@get_coonstitation"].Direction=ParameterDirection.Output;
				objCommand.Parameters["@get_intelligence"].Direction=ParameterDirection.Output;
				objCommand.Parameters["@get_speed"].Direction=ParameterDirection.Output;
				objCommand.Parameters["@get_blood"].Direction=ParameterDirection.Output;
				objCommand.Parameters["@get_max_blood"].Direction=ParameterDirection.Output;
				objCommand.Parameters["@get_magic"].Direction=ParameterDirection.Output;
				objCommand.Parameters["@get_max_magic"].Direction=ParameterDirection.Output;
				//���X��equipment table���˳��ݩʭ�
				//objCommand.Parameters["@get_equipment_id"].Direction=ParameterDirection.Output;
				objCommand.Parameters["@get_equipment_name"].Direction=ParameterDirection.Output;
				objCommand.Parameters["@get_equipment_power"].Direction=ParameterDirection.Output;
				//�����Ǧ^��Ƽ�
				objCommand.Parameters["@retval"].Direction=ParameterDirection.ReturnValue;
				//�N�^�����G��J�ܼƤ�,�Ǧ^�e�ݵ{���B��
				objCommand.ExecuteNonQuery();
			
				int count=Convert.ToInt32(objCommand.Parameters["@retval"].Value);
				if (count==0)
				{
					objConnection.Close();
					return false;
				}
				else
				{
					//user_value table
					a=objCommand.Parameters["@get_pet_name"].Value.ToString();
					b=objCommand.Parameters["@get_use_equipment"].Value.ToString();
					c=objCommand.Parameters["@get_user_kind"].Value.ToString();
					d=objCommand.Parameters["@get_map_id"].Value.ToString();
					e=objCommand.Parameters["@get_coordinage_x"].Value.ToString();
					f=objCommand.Parameters["@get_coordinage_y"].Value.ToString();
					g=objCommand.Parameters["@get_coordinage_z"].Value.ToString();
					h=objCommand.Parameters["@get_money"].Value.ToString();
					i=objCommand.Parameters["@get_grade"].Value.ToString();
					j=objCommand.Parameters["@get_experience_value"].Value.ToString();
					k=objCommand.Parameters["@get_advance_exper"].Value.ToString();
					l=objCommand.Parameters["@get_strength"].Value.ToString();
					m=objCommand.Parameters["@get_coonstitation"].Value.ToString();
					n=objCommand.Parameters["@get_intelligence"].Value.ToString();
					o=objCommand.Parameters["@get_speed"].Value.ToString();
					p=objCommand.Parameters["@get_blood"].Value.ToString();
					q=objCommand.Parameters["@get_max_blood"].Value.ToString();
					r=objCommand.Parameters["@get_magic"].Value.ToString();
					s=objCommand.Parameters["@get_max_magic"].Value.ToString();
					//equipment table
					t=objCommand.Parameters["@get_equipment_name"].Value.ToString();
					u=objCommand.Parameters["@get_equipment_power"].Value.ToString();
					objConnection.Close();
					return true;
				}
			}
			
			catch(System.Data.SqlClient.SqlException ex)
			{
				Console.WriteLine(ex);
				return false;
			}
		}

		//�ŧiSP_GetValue���,���e�ݵ{������
		public string User_GetValue(int pos)
		{
			try
			{
				
				switch(pos)
				{
					case 1:
						Object obj1=a;
						return obj1.ToString();
					
					case 2:
						Object obj2=b;
						return obj2.ToString();
						
					case 3:
						Object obj3=c;
						return obj3.ToString();
						
					case 4:
						Object obj4=d;
						return obj4.ToString();
						
					case 5:
						Object obj5=e;
						return obj5.ToString();
						
					case 6:
						Object obj6=f;
						return obj6.ToString();
						
					case 7:
						Object obj7=g;
						return obj7.ToString();
						
					case 8:
						Object obj8=h;
						return obj8.ToString();
						
					case 9:
						Object obj9=i;
						return obj9.ToString();
						
					case 10:
						Object obj10=j;
						return obj10.ToString();
						
					case 11:
						Object obj11=k;
						return obj11.ToString();

					case 12:
						Object obj12=l;
						return obj12.ToString();
					case 13:
						Object obj13=m;
						return obj13.ToString();
					case 14:
						Object obj14=n;
						return obj14.ToString();
					case 15:
						Object obj15=o;
						return obj15.ToString();
					case 16:
						Object obj16=p;
						return obj16.ToString();
					case 17:
						Object obj17=q;
						return obj17.ToString();
					case 18:
						Object obj18=r;
						return obj18.ToString();
					case 19:
						Object obj19=s;
						return obj19.ToString();
					case 20:
						Object obj20=t;
						return obj20.ToString();
					case 21:
				
						Object obj21=u;
						return obj21.ToString();
					default:
						Console.WriteLine("���ȶW�L�d��!!�{�����~!!");
						return "ERROR!ERROR!" ;
				}
			}
			catch(System.NullReferenceException ex)
			{
				Console.WriteLine(ex);
				return "aaaa";
			}

			}
		}						
			
	}

	


