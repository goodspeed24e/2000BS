using System;
using System.Data;
using System.IO;
using System.Text;
using System.Data.SqlClient;
using System.Runtime.InteropServices;


namespace Equipment_Get
{
	[Guid("A82E1FEF-F771-4d20-8481-779AE962F78C")]
	public interface DBCOM_Equipment_Get_Interface
	{
		[DispId(1)]
		string  Equipment_Get_Value(string owner_id);
	
	}

	// Events interface Database_COMObjectEvents 
	[Guid("CFAEB128-C4EE-4fa2-A3DE-3E18F1C93A91"), 
	InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
	public interface DBCOM_Events 
	{
	}


	[Guid("3460C010-48AE-4af6-9C31-B0E9CBC57067"),
	ClassInterface(ClassInterfaceType.None),
	ComSourceInterfaces(typeof(DBCOM_Events))]
	public class DBCOM_Equipment_Get_Class : DBCOM_Equipment_Get_Interface
	{
		object Ret_Equipment;
		public DBCOM_Equipment_Get_Class()
		{
		}
		public string  Equipment_Get_Value(string owner_id)
		{

			//�ŧi�s���r��
			String strConnection="server=localhost;database=game;uid=game_user;pwd=4321;";
			//�ŧi�s������
			SqlConnection objConnection=new SqlConnection(strConnection);
			//�}�ҳs��
			objConnection.Open();
			//�ŧiSqlDataAdapter����
			SqlDataAdapter equipment_reader=new SqlDataAdapter("sp_get_equipment",objConnection);
			//�ŧiSqlDataAdapter�R�O�ݩʬ��w�x�{��
			equipment_reader.SelectCommand.CommandType=CommandType.StoredProcedure;
			//�ŧi�Ѽƪ���-->@get_equipment_owner(�˳ƾ֦���)=>�ǤJsp�Ѽ�
			equipment_reader.SelectCommand.Parameters.Add(new SqlParameter("@get_equipment_owner",SqlDbType.Char,16));
			equipment_reader.SelectCommand.Parameters["@get_equipment_owner"].Value=owner_id;
			//�ŧi����SP�Ǧ^�Ȫ��Ѽ�@retval=>�Ǧ^�O�񵧼�
			equipment_reader.SelectCommand.Parameters.Add(new SqlParameter("@retval",SqlDbType.Int));
			equipment_reader.SelectCommand.Parameters["@retval"].Direction=ParameterDirection.ReturnValue;
			//�ŧiDataSet����equipment_dataset
			DataSet equipment_dataset=new DataSet();
			//�N���浲�G�HFill��J��ƪ������W"my_equipment"
			equipment_reader.Fill(equipment_dataset,"my_equipment");
			//�ŧiDataTable����equipment_table
			DataTable equipment_table=equipment_dataset.Tables["my_equipment"];
			objConnection.Close();
			//���X�O�񵧼�
			int abc=Convert.ToInt32(equipment_reader.SelectCommand.Parameters["@retval"].Value);
			for(int i=0;i<=(abc-1);i++)
			{
				string ret1=(equipment_table.Rows[i]["equipment_id"].ToString());
				Ret_Equipment=Ret_Equipment+ret1.ToString()+"@";
			}
			if (abc==0)
			{
				return("0");
			}
			else
			{
				return Ret_Equipment.ToString();
			}
			
			
		}
	
	}
}
