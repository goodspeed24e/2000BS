using System;
using System.IO;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace User_Write
{
	[Guid("5E13F612-933F-4ec0-B81D-3CB719DF16B0")]
	public interface DBCOM_User_Write_Interface
	{
		[DispId(1)]
		void User_Write_Value(string id,string password,int use_equipment,
			int user_kind,int map_id,int coordinage_x,int coordinage_y,
			int coordinage_z,int game_money,int grade,int experience_value,
			int advance_exper,int strength,int coonstitation,int intelligence,
			int speed,int blood,int max_blood,int magic,int max_magic);
	}

	// Events interface Database_COMObjectEvents 
	[Guid("6ECF363F-DD4E-405a-8673-48F204C7AE51"), 
	InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
	public interface DBCOM_Events 
	{
	}
	[Guid("7F810EF8-882D-497b-B3C3-CDE280A81D04"),
	ClassInterface(ClassInterfaceType.None),
	ComSourceInterfaces(typeof(DBCOM_Events))]
	public class DBCOM_User_Write_Class:DBCOM_User_Write_Interface
	{
		public DBCOM_User_Write_Class()
		{
		}
		public void User_Write_Value(string id,string password,int use_equipment,
			int user_kind,int map_id,int coordinage_x,int coordinage_y,
			int coordinage_z,int game_money,int grade,int experience_value,
			int advance_exper,int strength,int coonstitation,int intelligence,
			int speed,int blood,int max_blood,int magic,int max_magic)
		{
			//�ŧi�s���r��
			String strConnection="server=localhost;database=game;uid=game_user;pwd=4321;";
			//�ŧi�s������
			SqlConnection objConnection=new SqlConnection(strConnection);
			//�}�ҳs��
			objConnection.Open();
			//�ŧi�R�O����,����SP-->sp_write_user_value
			SqlCommand objCommand=new SqlCommand("sp_write_user_value",objConnection);
			//�]�w�R�O���󪺫��A��StoreProcedure
			objCommand.CommandType= CommandType.StoredProcedure;
			//�ŧi�Ѽƪ���Parameters
			//�ŧi�Ѽƪ���-->@u_id
			objCommand.Parameters.Add(new SqlParameter("@u_id",SqlDbType.Char,16));
			objCommand.Parameters["@u_id"].Value=id;
			//�ŧi�Ѽƪ���-->@u_password
			objCommand.Parameters.Add(new SqlParameter("@u_password",SqlDbType.Char,16));
			objCommand.Parameters["@u_password"].Value=password;
			//�ŧi�Ѽƪ���-->@u_use_equipment
			objCommand.Parameters.Add(new SqlParameter("@u_use_equipment",SqlDbType.Int));
			objCommand.Parameters["@u_use_equipment"].Value=use_equipment;
			//�ŧi�Ѽƪ���-->@u_user_kind
			objCommand.Parameters.Add(new SqlParameter("@u_user_kind",SqlDbType.Int));
			objCommand.Parameters["@u_user_kind"].Value=user_kind;
			//�ŧi�Ѽƪ���-->@u_map_id
			objCommand.Parameters.Add(new SqlParameter("@u_map_id",SqlDbType.Int));
			objCommand.Parameters["@u_map_id"].Value=map_id;
			//�ŧi�Ѽƪ���-->@u_coordinage_x
			objCommand.Parameters.Add(new SqlParameter("@u_coordinage_x",SqlDbType.Int));
			objCommand.Parameters["@u_coordinage_x"].Value=coordinage_x;
			//�ŧi�Ѽƪ���-->@u_coordinage_y
			objCommand.Parameters.Add(new SqlParameter("@u_coordinage_y",SqlDbType.Int));
			objCommand.Parameters["@u_coordinage_y"].Value=coordinage_y;
			//�ŧi�Ѽƪ���-->@u_coordinage_z
			objCommand.Parameters.Add(new SqlParameter("@u_coordinage_z",SqlDbType.Int));
			objCommand.Parameters["@u_coordinage_z"].Value=coordinage_z;
			//�ŧi�Ѽƪ���-->@u_game_money
			objCommand.Parameters.Add(new SqlParameter("@u_game_money",SqlDbType.Int));
			objCommand.Parameters["@u_game_money"].Value=game_money;
			//�ŧi�Ѽƪ���-->@u_grade
			objCommand.Parameters.Add(new SqlParameter("@u_grade",SqlDbType.Int));
			objCommand.Parameters["@u_grade"].Value=grade;
			//�ŧi�Ѽƪ���-->@u_experience_value
			objCommand.Parameters.Add(new SqlParameter("@u_experience_value",SqlDbType.Int));
			objCommand.Parameters["@u_experience_value"].Value=experience_value;
			//�ŧi�Ѽƪ���-->@u_advance_exper
			objCommand.Parameters.Add(new SqlParameter("@u_advance_exper",SqlDbType.Int));
			objCommand.Parameters["@u_advance_exper"].Value=advance_exper;
			//�ŧi�Ѽƪ���-->@u_strength
			objCommand.Parameters.Add(new SqlParameter("@u_strength",SqlDbType.Int));
			objCommand.Parameters["@u_strength"].Value=strength;
			//�ŧi�Ѽƪ���-->@u_coonstitation
			objCommand.Parameters.Add(new SqlParameter("@u_coonstitation",SqlDbType.Int));
			objCommand.Parameters["@u_coonstitation"].Value=coonstitation;
			//�ŧi�Ѽƪ���-->@u_intelligence
			objCommand.Parameters.Add(new SqlParameter("@u_intelligence",SqlDbType.Int));
			objCommand.Parameters["@u_intelligence"].Value=intelligence;
			//�ŧi�Ѽƪ���-->@u_speed
			objCommand.Parameters.Add(new SqlParameter("@u_speed",SqlDbType.Int));
			objCommand.Parameters["@u_speed"].Value=speed;
			//�ŧi�Ѽƪ���-->@u_blood
			objCommand.Parameters.Add(new SqlParameter("@u_blood",SqlDbType.Int));
			objCommand.Parameters["@u_blood"].Value=blood;
			//�ŧi�Ѽƪ���-->@u_max_blood
			objCommand.Parameters.Add(new SqlParameter("@u_max_blood",SqlDbType.Int));
			objCommand.Parameters["@u_max_blood"].Value=max_blood;
			//�ŧi�Ѽƪ���-->@u_magic
			objCommand.Parameters.Add(new SqlParameter("@u_magic",SqlDbType.Int));
			objCommand.Parameters["@u_magic"].Value=magic;
			//�ŧi�Ѽƪ���-->@u_max_magic				   
			objCommand.Parameters.Add(new SqlParameter("@u_max_magic",SqlDbType.Int));
			objCommand.Parameters["@u_max_magic"].Value=max_magic;
		/*	//�}�ҳs��
			objConnection.Open();*/
			try
			{
				objCommand.ExecuteNonQuery();
				objConnection.Close();
			}
			catch(System.Data.SqlClient.SqlException e)
			{
				Console.WriteLine(e.Message);
				objConnection.Close();
			}
			
		}
	}
}

