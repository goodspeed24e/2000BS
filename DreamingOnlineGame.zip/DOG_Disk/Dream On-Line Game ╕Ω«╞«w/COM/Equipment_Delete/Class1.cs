using System;
using System.Data;
using System.IO;
using System.Text;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace Equipment_Delete
{
	[Guid("575CDF30-E2C9-4f45-BB2F-D8CBF2AB15F3")]
	public interface DBCOM_Equipment_Delete_Interface
	{
		[DispId(1)]
		void Equipment_Delete(string user_id);
	}

	// Events interface Database_COMObjectEvents 
	[Guid("25724A47-F105-40bd-88AB-0D281C8CB003"), 
	InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
	public interface DBCOM_Events 
	{
	}


	[Guid("4E7BB5F9-1214-4c31-8CFB-CF5F91629D9A"),
	ClassInterface(ClassInterfaceType.None),
	ComSourceInterfaces(typeof(DBCOM_Events))]
	public class DBCOM_Equipment_Delete_Class:DBCOM_Equipment_Delete_Interface
	{
		public DBCOM_Equipment_Delete_Class()
		{
		}

		public void Equipment_Delete(string user_id)
		{
			//�ŧi�s���r��
			String strConnection="server=localhost;database=game;uid=game_user;pwd=4321;";
			//�ŧi�s������
			SqlConnection objConnection=new SqlConnection(strConnection);
			//�}�ҳs��
			objConnection.Open();
			try
			{
				//�ŧi�R�O����,����SP-->sp_equipment_delete
				SqlCommand objCommand=new SqlCommand("sp_equipment_delete",objConnection);
				//�]�w�R�O���󪺫��A��StoreProcedure
				objCommand.CommandType= CommandType.StoredProcedure;
				//�ŧi�Ѽƪ���Parameters
				//�ŧi�Ѽƪ���-->@d_user_id==>�˳ƾ֦���
				objCommand.Parameters.Add(new SqlParameter("@d_user_id",SqlDbType.Char,16));
				objCommand.Parameters["@d_user_id"].Value=user_id;
				objCommand.ExecuteNonQuery();
			}
			catch(System.ExecutionEngineException ex)
			{
				Console.WriteLine(ex);
			//	return false;
			}
			objConnection.Close();
		}
			
	}
}