using System;
using System.IO;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

//���a�˳Ʀ^�s��Ʈw
namespace Equipment_Write
{
	[Guid("94681D7C-F9E5-4238-89AA-E3428AC77FE9")]
	public interface DBCOM_Equipment_Write_Interface
	{
		[DispId(1)]
		void Equipment_Write_Value(string owner_id,int equipment_id1,int equipment_id2,int equipment_id3);
	}

	// Events interface Database_COMObjectEvents 
	[Guid("5EFFDD37-78D2-4a15-B212-D2D3F583857B"), 
	InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
	public interface DBCOM_Events 
	{
	}


	[Guid("26E25CED-B7DC-4716-9C35-251F5446CB2E"),
	ClassInterface(ClassInterfaceType.None),
	ComSourceInterfaces(typeof(DBCOM_Events))]
	public class DBCOM_Equipment_Write_Class:DBCOM_Equipment_Write_Interface
	{
		public DBCOM_Equipment_Write_Class()
		{
		}

		public void Equipment_Write_Value(string owner_id,int equipment_id1,int equipment_id2,int equipment_id3)
		{
			//�ŧi�s���r��
			String strConnection="server=localhost;database=game;uid=game_user;pwd=4321;";
			//�ŧi�s������
			SqlConnection objConnection=new SqlConnection(strConnection);
			//�}�ҳs��
			objConnection.Open();
			int [] equipment_id=new int[3];
		    equipment_id[0]=equipment_id1;
			equipment_id[1]=equipment_id2;
			equipment_id[2]=equipment_id3;
			for(int i=0;i<3;i++)
			{			
				//�ŧi�R�O����,����SP-->sp_write_user_value
				SqlCommand objCommand=new SqlCommand("sp_write_equipment",objConnection);
				//�]�w�R�O���󪺫��A��StoreProcedure
				objCommand.CommandType= CommandType.StoredProcedure;
				//�ŧi�Ѽƪ���Parameters
				//�ŧi�Ѽƪ���-->@insert_equipment_owner==>�˳ƾ֦���
				objCommand.Parameters.Add(new SqlParameter("@insert_equipment_owner",SqlDbType.Char,16));
				objCommand.Parameters["@insert_equipment_owner"].Value=owner_id;
				//�ŧi�Ѽƪ���-->@insert_equipment_own_id==>�˳ƽs��
				objCommand.Parameters.Add(new SqlParameter("@insert_equipment_own_id",SqlDbType.Int));
				objCommand.Parameters["@insert_equipment_own_id"].Value=equipment_id[i];
				//�ϥΨҥ~�B�z�����O���O�_�s�b
				try
				{
					objCommand.ExecuteNonQuery();
					objConnection.Close();
					
				}
				catch(System.Data.SqlClient.SqlException ex)
				{
				}

			}
			objConnection.Close();
		}
			
	}
}

