using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace DOLG
{
	/// <summary>
	/// dicuss_main ���K�n�y�z�C
	/// </summary>
	public class dicuss_main : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Image imgTitle;
		protected System.Web.UI.WebControls.TextBox txtName;
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator1;
		protected System.Web.UI.WebControls.RadioButtonList radImg;
		protected System.Web.UI.WebControls.TextBox txtSubject;
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator2;
		protected System.Web.UI.WebControls.TextBox txtMemo;
		protected System.Web.UI.WebControls.Label lblError;
		protected System.Web.UI.WebControls.Button btnSend;
		protected System.Web.UI.WebControls.DataGrid DG1;
		protected System.Web.UI.WebControls.Button Ib1;
		protected System.Web.UI.HtmlControls.HtmlForm Form1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(!IsPostBack)
			{
				//�ŧi�n���檺
				string selectcmd="select * from discuss_title order by speak_time desc";
				
				string conn_str = "server=localhost;database=discuss;uid=web_user;pwd=1234;";
				SqlConnection conn = new SqlConnection(conn_str) ;
				conn.Open() ;
				DataSet myDataSet = new DataSet() ;
				SqlDataAdapter myAdapter = new SqlDataAdapter(selectcmd, conn) ;
				myAdapter.Fill(myDataSet,"discuss_title") ;
			    DG1.DataSource=myDataSet.Tables["discuss_title"] ;
				DG1.DataBind();
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: ���I�s�� ASP.NET Web Form �]�p�u�㪺���n���C
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����]�p�u��䴩�ҥ��ݪ���k - �ФŨϥε{���X�s�边�ק�
		/// �o�Ӥ�k�����e�C
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
