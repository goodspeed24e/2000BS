vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Aug 2003 14:08:02 -0000
vti_extenderversion:SR|4.0.2.5526
