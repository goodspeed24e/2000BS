using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace DOLG
{
	/// <summary>
	/// discuss_detail ���K�n�y�z�C
	/// </summary>
	public class discuss_detail : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label lblId;
		protected System.Web.UI.WebControls.Repeater Repeater1;
		protected System.Web.UI.WebControls.Repeater Repeater2;
		protected System.Web.UI.WebControls.TextBox txtName;
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator1;
		protected System.Web.UI.WebControls.RadioButtonList radImg;
		protected System.Web.UI.WebControls.TextBox txtSubject;
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator2;
		protected System.Web.UI.WebControls.TextBox txtMemo;
		protected System.Web.UI.WebControls.Label lblError;
		protected System.Web.UI.WebControls.Button btnSend;
		protected System.Web.UI.HtmlControls.HtmlForm Form1;
		string selectcmd,conn_str,updatecmd;
		int num;
		
	
		private void Page_Load(object sender, System.EventArgs e)
        {
			
			if (!IsPostBack)
			{
				//�ϥ�Request������oGBOOKTITLE��ƪ�(�d���O�D�D)���s��
				lblId.Text = Request["txtTitle_id"] ;    
				selectcmd = "Select * From discuss_title Where title_id = " + lblId.Text ;
				conn_str = "server=localhost;database=discuss;uid=web_user;pwd=1234;";                          
				SqlConnection conn = new SqlConnection(conn_str) ;
				conn.Open() ;
				SqlCommand cmd = new SqlCommand (selectcmd, conn);
				SqlDataReader rd= cmd.ExecuteReader();
				//	���XGBOOKTITLE��ƪ�(�d���O�D�D)���s���ƨå[1
				if (rd.Read()) 
				{
					//�N���o���s���ơureader["look_num"]�v�૬��int���A�M��A�[1�A�ë��wnum�ܼ�
					num = (int)rd["brower_num"] + 1 ;
				}
				conn.Close();
        		updatecmd = "Update discuss_title Set brower_num = " + num +
					" Where title_id = " + lblId.Text ;
				conn_str = "server=localhost;database=discuss;uid=web_user;pwd=1234;";                          
				SqlConnection conn2 = new SqlConnection(conn_str) ;
				conn2.Open() ;
				SqlCommand cmd2 = new SqlCommand(updatecmd, conn2) ;
				cmd2.ExecuteNonQuery() ;
				conn2.Close() ;
				selectcmd = "Select * From discuss_title Where title_id = " + lblId.Text + 
					" Order By speak_time Desc" ;
				conn_str = "server=localhost;database=discuss;uid=web_user;pwd=1234;";                          
				SqlConnection conn3 = new SqlConnection(conn_str) ;
				conn3.Open() ;
				DataSet myDataSet3 = new DataSet() ;
				SqlDataAdapter myAdapter3 = new SqlDataAdapter(selectcmd, conn3) ;
				myAdapter3.Fill(myDataSet3,"discuss_detail") ;
				Repeater1.DataSource=myDataSet3.Tables["discuss_detail"] ;
				Repeater1.DataBind();
				selectcmd = "Select * From discuss_detail Where ans_id = " + lblId.Text + 
					" Order By speak_time Desc" ;
				conn_str = "server=localhost;database=discuss;uid=web_user;pwd=1234;";                          
				SqlConnection conn4 = new SqlConnection(conn_str) ;
				conn4.Open() ;
				DataSet myDataSet4 = new DataSet() ;
				SqlDataAdapter myAdapter4 = new SqlDataAdapter(selectcmd, conn4) ;
				myAdapter4.Fill(myDataSet4,"discuss_detail") ;
				Repeater2.DataSource=myDataSet4.Tables["discuss_detail"] ;
				Repeater2.DataBind();
			}
		



			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: ���I�s�� ASP.NET Web Form �]�p�u�㪺���n���C
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����]�p�u��䴩�ҥ��ݪ���k - �ФŨϥε{���X�s�边�ק�
		/// �o�Ӥ�k�����e�C
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
