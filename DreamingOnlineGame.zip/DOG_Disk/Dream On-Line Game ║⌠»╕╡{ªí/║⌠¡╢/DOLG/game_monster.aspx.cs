using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace DOLG
{
	/// <summary>
	/// game_monster ���K�n�y�z�C
	/// </summary>
	public class game_monster : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.ImageButton ib1;
		protected System.Web.UI.WebControls.ImageButton Ib2;
		protected System.Web.UI.WebControls.ImageButton Ib3;
		protected System.Web.UI.WebControls.ImageButton Ib4;
		protected System.Web.UI.WebControls.ImageButton Ib5;
		protected System.Web.UI.WebControls.LinkButton Linkbutton1;
		protected System.Web.UI.WebControls.LinkButton Linkbutton2;
		protected System.Web.UI.WebControls.LinkButton Linkbutton3;
		protected System.Web.UI.WebControls.LinkButton Linkbutton4;
		protected System.Web.UI.WebControls.LinkButton Linkbutton6;
		protected System.Web.UI.WebControls.LinkButton Linkbutton5;
		protected System.Web.UI.HtmlControls.HtmlImage Img2;
		protected System.Web.UI.WebControls.LinkButton Linkbutton7;
		protected System.Web.UI.HtmlControls.HtmlImage Img1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// �N�ϥΪ̵{���X�m�󦹥H��l�ƺ���
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: ���I�s�� ASP.NET Web Form �]�p�u�㪺���n���C
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����]�p�u��䴩�ҥ��ݪ���k - �ФŨϥε{���X�s�边�ק�
		/// �o�Ӥ�k�����e�C
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
