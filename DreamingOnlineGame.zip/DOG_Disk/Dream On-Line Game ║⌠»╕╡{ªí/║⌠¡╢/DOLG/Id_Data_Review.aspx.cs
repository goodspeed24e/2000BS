using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace DOLG
{
	/// <summary>
	/// Id_Data_Review ���K�n�y�z�C
	/// </summary>
	public class Id_Data_Review : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label labelid;
		protected System.Web.UI.WebControls.Label labelpass;
		protected System.Web.UI.WebControls.Label labelpetname;
		protected System.Web.UI.WebControls.Label labelname;
		protected System.Web.UI.WebControls.Label labelsex;
		protected System.Web.UI.WebControls.Label labelsid;
		protected System.Web.UI.WebControls.Label labelyear;
		protected System.Web.UI.WebControls.Label labelmon;
		protected System.Web.UI.WebControls.Label labelday;
		protected System.Web.UI.WebControls.Label labelcity;
		protected System.Web.UI.WebControls.Label labeladdress;
		protected System.Web.UI.WebControls.Label labellocalcode;
		protected System.Web.UI.WebControls.Label labelphonecode;
		protected System.Web.UI.WebControls.Label labelcellphone;
		protected System.Web.UI.WebControls.Label labelemail;
		protected System.Web.UI.WebControls.Button sure_btn;
		protected System.Web.UI.WebControls.Button canser_btn;
		protected System.Web.UI.WebControls.ImageButton ib1;
		protected System.Web.UI.WebControls.ImageButton Ib2;
		protected System.Web.UI.WebControls.ImageButton Ib3;
		protected System.Web.UI.WebControls.ImageButton Ib4;
		protected System.Web.UI.WebControls.ImageButton Ib5;
		protected System.Web.UI.WebControls.LinkButton Linkbutton1;
		protected System.Web.UI.WebControls.LinkButton Linkbutton2;
		protected System.Web.UI.WebControls.LinkButton Linkbutton3;
		protected System.Web.UI.WebControls.LinkButton Linkbutton4;
		
		protected System.Web.UI.WebControls.Label msg;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			labelid.Text=Request["txtid"];
			labelpass.Text=Request["txtpass"];
			labelpetname.Text=Request["txtpetname"];
			labelname.Text=Request["txtname"];
			labelsex.Text=Request["txtsex"];
			labelsid.Text=Request["txtsid"];
			labelyear.Text=Request["txtyear"];
			labelmon.Text=Request["txtmon"];
			labelday.Text=Request["txtday"];
			labelcity.Text=Request["txtcity"];
			labeladdress.Text=Request["txtaddress"];
			labellocalcode.Text=Request["txtlocalcode"];
			labelphonecode.Text=Request["txtphonecode"];
			labelcellphone.Text=Request["txtcellphone"];
			labelemail.Text=Request["txtemail"];
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: ���I�s�� ASP.NET Web Form �]�p�u�㪺���n���C
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����]�p�u��䴩�ҥ��ݪ���k - �ФŨϥε{���X�s�边�ק�
		/// �o�Ӥ�k�����e�C
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
