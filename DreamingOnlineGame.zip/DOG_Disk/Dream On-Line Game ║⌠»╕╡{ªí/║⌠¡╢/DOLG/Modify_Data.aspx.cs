using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


namespace DOLG
{
	/// <summary>
	/// Modify_Data ���K�n�y�z�C
	/// </summary>
	public class Modify_Data : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label msg3;
		protected System.Web.UI.WebControls.TextBox txtid;
		protected System.Web.UI.WebControls.TextBox txtpass;
		protected System.Web.UI.WebControls.RequiredFieldValidator rfepass;
		protected System.Web.UI.WebControls.RegularExpressionValidator revpass;
		protected System.Web.UI.WebControls.TextBox txtcpass;
		protected System.Web.UI.WebControls.TextBox txtname;
		protected System.Web.UI.WebControls.ListBox txtcity;
		protected System.Web.UI.WebControls.TextBox txtaddress;
		protected System.Web.UI.WebControls.ListBox txtlocalcode;
		protected System.Web.UI.WebControls.TextBox txtphonecode;
		protected System.Web.UI.WebControls.TextBox txtcellphone;
		protected System.Web.UI.WebControls.TextBox txtemail;
		protected System.Web.UI.WebControls.RequiredFieldValidator rfemail;
		protected System.Web.UI.WebControls.RegularExpressionValidator revmail;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.ImageButton ib1;
		protected System.Web.UI.WebControls.ImageButton Ib2;
		protected System.Web.UI.WebControls.ImageButton Ib3;
		protected System.Web.UI.WebControls.ImageButton Ib4;
		protected System.Web.UI.WebControls.ImageButton Ib5;
		protected System.Web.UI.WebControls.ImageButton Ib6;
		protected System.Web.UI.WebControls.LinkButton Linkbutton1;
		protected System.Web.UI.WebControls.LinkButton Linkbutton2;
		protected System.Web.UI.WebControls.LinkButton Linkbutton3;
		protected System.Web.UI.WebControls.LinkButton Linkbutton4;
		protected System.Web.UI.WebControls.TextBox txtpetname;
		protected System.Web.UI.WebControls.Label msg;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			string mem_id,conn_str,select_cmd;
			if(!IsPostBack)
			{
				mem_id=Request["txtid"];
				select_cmd="select * from affiliate where a_id='"+mem_id+"'";
				conn_str="server=localhost;database=user_account;uid=web_user;pwd=1234;";
				SqlConnection conn=new SqlConnection(conn_str);
				conn.Open();
				SqlCommand cmd=new SqlCommand(select_cmd,conn);
				SqlDataReader rd;
				rd=cmd.ExecuteReader() ;
				if(rd.Read())
				{
					txtid.Text=mem_id;
					txtpetname.Text=rd["a_pet_name"].ToString();
					txtname.Text=rd["a_name"].ToString();
					txtaddress.Text=rd["a_address"].ToString();
					txtphonecode.Text=rd["a_phonecode"].ToString();
					txtcellphone.Text=rd["a_cellphone"].ToString();
					txtemail.Text=rd["a_email"].ToString();
				}
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: ���I�s�� ASP.NET Web Form �]�p�u�㪺���n���C
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����]�p�u��䴩�ҥ��ݪ���k - �ФŨϥε{���X�s�边�ק�
		/// �o�Ӥ�k�����e�C
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
