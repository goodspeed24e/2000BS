
#include "..\Common\Global.h"
#include "..\Common\GameDef.h"
#include "WinMain.h"

cMainApp        *g_Application; // Global application pointer
cNetworkAdapter *g_Adapters;    // Global adapter list pointer
long						MenuTime	= GetTickCount();
int				NewMap=0;
cMainApp::cMainApp()
{ 
  m_Width  = 800;
  m_Height = 600;
  m_Style  = WS_BORDER | WS_CAPTION | WS_MINIMIZEBOX | WS_SYSMENU;
  strcpy(m_Class, "ServerClass");
  strcpy(m_Caption, "Dream on-line Game ���A��");

  // �M����Ƥ��e
  m_Messages    = NULL;
  m_Players     = NULL;
  m_guidAdapter = NULL;
  g_Application = this;
  g_Adapters    = &m_Adapters;
  srand((unsigned)time(NULL));
	// ��l�� critical section for messaging
  InitializeCriticalSection(&m_MessageCS);
}

BOOL cMainApp::Init()
{

	// ��ܺ��������d
  if(SelectAdapter() == FALSE)
    return FALSE;

  // Setup the main interface window
	// �]�w�D����
  SetupApplicationWindow();
  
  // ��l�ƹC�������Ҧ��]�w
  if(InitializeGame() == FALSE) {
    MB("��l�� InitializeGame() ���~");
    return FALSE;
  }

	// �إ߹C���D��
  if(HostGame() == FALSE) {
    MB("��l�� HostGame() ���~");
    return FALSE;
  }

  return TRUE;
}

BOOL cMainApp::Shutdown()
{
  // ����
  m_Adapters.Shutdown();
  m_Server.Disconnect();
  m_Server.Shutdown();

	// �ϧ�
  //m_LevelMesh.Free();
  delete [] m_LevelMesh;
  m_Graphics.Shutdown();

  //����a�ϵ��c
  for(int i=0;i<MapCount;i++)
  {
	if(AllMap[i].ExitCount !=0)
		delete [] AllMap[i].Exit;
	AllMap[i].Exit=NULL;
  }
  //delete [] AllMap;
  AllMap=NULL;

	// �T���}�C
  delete [] m_Messages;
  m_Messages = NULL;

	// ���a���
  delete [] m_Players;
  m_Players = NULL;
   // �Ǫ����

  // Free the critical section
  DeleteCriticalSection(&m_MessageCS);

  return TRUE;
}

BOOL cMainApp::FrameProcess()
{
  static DWORD PlayerCounter = timeGetTime();
  static DWORD NetworkCounter = timeGetTime();
  static DWORD LatencyCounter = timeGetTime();
  
	// �B�z�@�Ǧ�C�W�������T��
  ProcessQueuedMessages();

  // ��s���a 33ms (30 times a second)
  if(timeGetTime() > PlayerCounter + 33) {
    UpdatePlayers();				// ���a��s
//	MonsterMove(m_Monsters);		//�Ǫ�����
    PlayerCounter = timeGetTime(); // Reset counter
  }

  // ��s����Send out network updates every 100ms (10 times a second)
  if(timeGetTime() > NetworkCounter + 100) {
    UpdateNetwork();
    NetworkCounter = timeGetTime(); // Reset counter
  }

  // ��s���alatency   every 10 seconds
  if(timeGetTime() > LatencyCounter + 10000) {
    UpdateLatency();
    LatencyCounter = timeGetTime(); // Reset counter
  }

  return TRUE;
}

FAR PASCAL cMainApp::MsgProc(HWND hWnd, UINT uMsg,                \
                         WPARAM wParam, LPARAM lParam)
{
  switch(uMsg) {
    case WM_DESTROY:
      PostQuitMessage(0);
      break;
    default: return DefWindowProc(hWnd, uMsg, wParam, lParam);
  }

  return 0;
}    

int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hPrev,          \
                   LPSTR szCmdLine, int nCmdShow)
{
  cMainApp App;
  return App.Run();  // Run the application instance
}

//
// Select adapter dialog and other functions
//
//
BOOL CALLBACK ConfigDialogProc(HWND hWnd, UINT uMsg,          \
                               WPARAM wParam, LPARAM lParam)
{
  long i;
  char Text[256];
  int Selection;
  static HWND hAdapters;

  switch(uMsg) {
    case WM_INITDIALOG:
			// ���o�����d
      hAdapters = GetDlgItem(hWnd, IDC_ADAPTERS);

			// �K�W�����d���W��
      for(i=0;i<g_Adapters->GetNumAdapters();i++) {
        g_Adapters->GetName(i, Text);
        SendMessage(hAdapters, CB_INSERTSTRING,i,(LPARAM)Text);
      }

			// �w��Ĥ@�i�d
      SendMessage(hAdapters, CB_SETCURSEL, 0, 0);

      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam)) {

        case IDC_OK:
  
          if((Selection = SendMessage(hAdapters,              \
                                      CB_GETCURSEL,           \
                                      0, 0)) == LB_ERR)
            break;

          // ���w�����d
          if(g_Application != NULL)
            g_Application->SetAdapter(                        \
                           g_Adapters->GetGUID(Selection));

     
          EndDialog(hWnd, TRUE);
          return TRUE;

        case IDC_CANCEL:
          EndDialog(hWnd, FALSE);
          return TRUE;
      }

  }
  return FALSE;
}

void cMainApp::SetAdapter(GUID *Adapter)
{
  m_guidAdapter = Adapter;
}

//
// Misc. application functions
//
//
void cMainApp::ListPlayers()
{
  long i;
  char Text[256];
  char ListUser[512];
  char weapon[7][16]={"�Ť�","�T����","�]�k��","�T��","��P��","���~����","�ڤۤ��C"};
  if(m_Players == NULL)
    return;

	// �M�Ū��C
  SendMessage(m_Controls[2], LB_RESETCONTENT, 0, 0);
	// �p��u�W���a���W��

  for(i=0;i<MAX_PLAYERS;i++) {
	  if(m_Players[i].Connected == TRUE){
		 strcpy(ListUser,m_Players[i].UserID); strcat(ListUser,"       ");
		 strcat(ListUser,m_Players[i].Name);   strcat(ListUser,"                 ");
		 strcat(ListUser,m_Players[i].Psw);    strcat(ListUser,"           ");
		 strcat(ListUser,itoa(m_Players[i].AtMap,Text,10));  strcat(ListUser,"       ");
		 strcat(ListUser,weapon[m_Players[i].WP]);
		 SendMessage(m_Controls[2], LB_ADDSTRING, 0,(LPARAM)ListUser);
	  }
  }

  SetWindowText(m_Controls[1],"���a�b��            �ʺ�      			      �K�X		  ���a��     �ϥΤ��Z��");


  /*
	// ��ܤ�
  if(!m_NumPlayers)
    SetWindowText(m_Controls[1], "�s �u �� �a �C ��");
  else {
    sprintf(Text, "%lu �� �� �a �s �u ��", m_NumPlayers);
    SetWindowText(m_Controls[1], Text);
  }*/
}

//
// Network send and receive functions
//
//
BOOL cMainApp::SendNetworkMessage(void *Msg, long SendFlags, int To)
{
  sMessageHeader *mh = (sMessageHeader*)Msg;
  sStateChangeMessage *scm = (sStateChangeMessage*)Msg;
  unsigned long Size;
  
	// ���o�T���j�p
  if((Size = mh->Size) == 0)
    return FALSE;

		// �s���ʥ]
  if(To == -1)
    To = DPNID_ALL_PLAYERS_GROUP;

  // Send the message
  if(mh->PlayerID >=0 && mh->PlayerID < MAX_MONSTERS)
  {
		PlayerStateChange((sMessage*)mh);
  }
  /*if(To==DPNID_ALL_PLAYERS_GROUP && mh->Type == MSG_STATE_CHANGE)
  {
		for(int i=MAX_MONSTERS;i<MAX_PLAYERS;i++)
		{
			if(m_Players[i].Connected==TRUE &&  scm->AtMap==m_Players[i].AtMap )
				m_Server.Send(m_Players[i].dpnidPlayer,Msg,Size,SendFlags);
		}
		return true;
  }*/
  return m_Server.Send(To, Msg, Size, SendFlags);
}


BOOL cMainApp::CreatePlayer(DPNMSG_CREATE_PLAYER *Msg)
{
  sCreatePlayerMessage cpm;

	// �]�w�T�����
  cpm.Header.Type     = MSG_CREATE_PLAYER;
  cpm.Header.Size     = sizeof(sCreatePlayerMessage);
  cpm.Header.PlayerID = Msg->dpnidPlayer;
  
  QueueMessage(&cpm); // �[��Queue��
  
  return TRUE;
}


//-------------------------
/*BOOL cMainApp::CreateMonster()
{



}*/
//-------------------------
BOOL cMainApp::DestroyPlayer(DPNMSG_DESTROY_PLAYER *Msg)
{
  sDestroyPlayerMessage dpm;

  // �]�w�T�����
  dpm.Header.Type     = MSG_DESTROY_PLAYER;
  dpm.Header.Size     = sizeof(sDestroyPlayerMessage);
  dpm.Header.PlayerID = Msg->dpnidPlayer;
  
  QueueMessage(&dpm); // �[��Queue��

  return TRUE;
}

BOOL cMainApp::Receive(DPNMSG_RECEIVE *Msg)
{
  sMessageHeader *mh = (sMessageHeader*)Msg->pReceiveData;

	// �P�O�T�����A
  switch(mh->Type) {
    case MSG_ASSIGNID: 
			// �x�s���aid
      mh->PlayerID = Msg->dpnidSender;
	case MSG_CHATING :
    case MSG_PLAYER_INFO:
    case MSG_STATE_CHANGE:
			// �[��message queue��
      QueueMessage((void*)Msg->pReceiveData);
      break;
  }

  return TRUE;
}

//
// Message queue functions
//
//
BOOL cMainApp::QueueMessage(void *Msg)
{
  sMessageHeader *mh = (sMessageHeader*)Msg;

  if(m_Messages == NULL)
    return FALSE;

  // Return if no room left in queue
  if(((m_MsgHead+1) % NUM_MESSAGES) == m_MsgTail)
    return FALSE;
	

	// �������T�����B�z
  if(mh->Size <= sizeof(sMessage)) {
		// �i�J critical section
    EnterCriticalSection(&m_MessageCS);

    memcpy(&m_Messages[m_MsgHead], Msg, mh->Size);

		// �i��U�@�ӪŰT��
    m_MsgHead++;
    if(m_MsgHead >= NUM_MESSAGES)
      m_MsgHead = 0;

    // ���} critical section
    LeaveCriticalSection(&m_MessageCS);
  }

  return TRUE;
}

// �t�m���aID
BOOL cMainApp::PlayerID(sMessage *Msg, DPNID To)
{
  sAssignPlayerIDMessage apidm;

  apidm.Header.Type     = MSG_ASSIGNID;
  apidm.Header.Size     = sizeof(sAssignPlayerIDMessage);
  apidm.Header.PlayerID = To;
  SendNetworkMessage(&apidm, DPNSEND_NOLOOPBACK, To);

  return TRUE;
}

// ���a���
BOOL cMainApp::PlayerInfo(sMessage *Msg, DPNID To)
{
  sRequestPlayerInfoMessage *rpim;
  sCreatePlayerMessage cpm;
  long i;

  if(m_Players == NULL)
    return FALSE;

  // Get pointer to request info
	// ���o��T
  rpim = (sRequestPlayerInfoMessage*)Msg;

  for(i=0;i<MAX_PLAYERS;i++) {
		// �ǰe���C���W�����a
    if(m_Players[i].dpnidPlayer == rpim->PlayerID &&          \
       m_Players[i].Connected == TRUE) {
 
			// �ǰe���a��T���ШD�����a
      cpm.Header.Type     = MSG_PLAYER_INFO;
      cpm.Header.Size     = sizeof(sCreatePlayerMessage);
      cpm.Header.PlayerID = rpim->PlayerID;
      cpm.XPos            = m_Players[i].XPos;
      cpm.YPos            = m_Players[i].YPos;
      cpm.ZPos            = m_Players[i].ZPos;
      cpm.Direction       = m_Players[i].Direction;
      cpm.AtMap           = m_Players[i].AtMap;
	  cpm.Career          = m_Players[i].Career;
	  cpm.WP          = m_Players[i].WP;
      SendNetworkMessage(&cpm, DPNSEND_NOLOOPBACK, To);

      break;
    }
  }

  return TRUE;
}

// �[�J���a
BOOL cMainApp::AddPlayer(sMessage *Msg)
{
  long i;
  DWORD Size = 0;
  DPN_PLAYER_INFO *dpi = NULL;
  HRESULT hr;
  DPNID PlayerID;

  if(m_Players == NULL)
    return FALSE;

	// ���o���aID
  PlayerID = Msg->Header.PlayerID;

	// ���o���a����T
  hr = m_Server.GetServerCOM()->GetClientInfo(PlayerID, dpi,  \
                                              &Size, 0);

  // Return on error or if adding server
  if(FAILED(hr) && hr != DPNERR_BUFFERTOOSMALL)
    return FALSE;

	// �t�m���a��ƪ�buffer
  if((dpi = (DPN_PLAYER_INFO*)new BYTE[Size]) == NULL)
    return FALSE;
  ZeroMemory(dpi, Size);
  dpi->dwSize = sizeof(DPN_PLAYER_INFO);
  if(FAILED(m_Server.GetServerCOM()->GetClientInfo(           \
                                PlayerID, dpi, &Size, 0))) {
    delete [] dpi;
    return FALSE;
  }

	// �T�w�O�_�����C
  for(i=0;i<MAX_PLAYERS;i++) {
    if(m_Players[i].dpnidPlayer == PlayerID &&                \
       m_Players[i].Connected == TRUE) {
      delete [] dpi;
      m_Server.DisconnectPlayer(PlayerID);
      return FALSE;
    }
  }
	

	// Search �Ū�slot�����a
  for(i=0;i<MAX_PLAYERS;i++) {
    if(m_Players[i].Connected == FALSE) {

		 // �x�sDPNID #�M���a�W��
		m_Players[i].dpnidPlayer = PlayerID;
		wcstombs(m_Players[i].Name, dpi->pwszName, 256);
	  // �N�K�X��r���}
	  int key=0,w=0,j=0;
	  std::string a;
	  a=m_Players[i].Name;
	  key=a.find('*');
	  while (j < strlen(m_Players[i].Name))
	  {
		  if (j<=key)
			  m_Players[i].UserID[j]=a.at(j);
		  else{
			  m_Players[i].Psw[w]=a.at(j);
				w++;
		  }
		j++;
	  }
 	 m_Players[i].UserID[key]='\0';
	 m_Players[i].Psw[w]='\0';

	 // �qDBŪ���X���a���
	 if (!ReadDB(m_Players[i])){
		 //MB("�n�J�����\");
	//	 delete [] dpi;
		 m_Server.DisconnectPlayer(PlayerID);
		 return FALSE;
	 }
	
	
	// �]�w���a���
	
	  m_Players[i].Connected = TRUE;
      //m_Players[i].XPos      = 0.0f;
      //m_Players[i].YPos      = 0.0f;
      //m_Players[i].ZPos      = 0.0f;
      m_Players[i].Direction = 0.0f;
      //m_Players[i].Speed     = 256.0f;
	  //m_Players[i].AtMap		= 33;
      m_Players[i].State		= STATE_START;
      m_Players[i].Latency		= 0;
      //m_Players[i].Career		= MI;
	  //m_Players[i].Level		= 100;
	  //m_Players[i].WP			= UNKNOW;
	  //m_Players[i].EQ1			= UNKNOW;
	  //m_Players[i].EQ2			= UNKNOW;
	  //m_Players[i].EQ3			= UNKNOW;
	  //m_Players[i].MaxHP		= 1000;
	   //m_Players[i].HP			= 10;
	   //m_Players[i].MaxSP		= 10;
	   //m_Players[i].SP			= 10;
	   //m_Players[i].NextExp		= 100;
	   //m_Players[i].Exp			= 99;
	   //m_Players[i].Str			= 1;
       //m_Players[i].Con			= 10;
	   //m_Players[i].Int			= 5;
	   //m_Players[i].Mon			= 200;
			// �ǰe���a��T�����������a
      sCreatePlayerMessage cpm;
      cpm.Header.Type     = MSG_CREATE_PLAYER;
      cpm.Header.Size     = sizeof(sCreatePlayerMessage);
      cpm.Header.PlayerID = PlayerID;
	  cpm.Career          = m_Players[i].Career;
	  cpm.WP              = m_Players[i].WP;
      cpm.XPos            = m_Players[i].XPos;
      cpm.YPos            = m_Players[i].YPos;
      cpm.ZPos            = m_Players[i].ZPos;
      cpm.Direction       = m_Players[i].Direction;
	  cpm.AtMap			  = m_Players[i].AtMap;
      SendNetworkMessage(&cpm, DPNSEND_NOLOOPBACK, -1);

      ListPlayers();			// �C����W

      delete [] dpi;        // Free player data

      return TRUE;    
    }
  }

  delete[] dpi;  // Free player data

	// �s�u�L��
  m_Server.DisconnectPlayer(PlayerID);

  return FALSE; 
}

BOOL cMainApp::RemovePlayer(sMessage *Msg)
{
  long i;

  if(m_Players == NULL)
    return FALSE;

  // Search �����C�����a
  for(i=0;i<MAX_PLAYERS;i++) {
    if(m_Players[i].dpnidPlayer == Msg->Header.PlayerID &&    \
       m_Players[i].Connected == TRUE) {

	EnterCriticalSection(&m_MessageCS);
    WriteDB(m_Players[i]);		// �g�J��Ʈw

    // ���} critical section
    LeaveCriticalSection(&m_MessageCS);

	
      m_Players[i].Connected = FALSE;  // ���u

	  // �i�D��L�����a���u���T�� 
      sDestroyPlayerMessage dpm;
      dpm.Header.Type     = MSG_DESTROY_PLAYER;
      dpm.Header.Size     = sizeof(sDestroyPlayerMessage);
      dpm.Header.PlayerID = Msg->Header.PlayerID;
      SendNetworkMessage(&dpm, DPNSEND_NOLOOPBACK, -1);

      // ���s�C��
      ListPlayers();

      return TRUE;
    }
  }

  return FALSE;  
}

BOOL cMainApp::ShowText(sMessage *Msg)
{
	sShowText *stm, rstm;
	int i,PlayerNum;
  stm = (sShowText*)Msg;
	// ���o���a��dpnid���X
  PlayerNum = -1;
  for(i=0;i<MAX_PLAYERS;i++) {
    if(m_Players[i].dpnidPlayer == Msg->Header.PlayerID &&    \
       m_Players[i].Connected == TRUE) {
		 PlayerNum = i;
      break;
    }
  }
  if(PlayerNum == -1)
    return FALSE;
 //for(i=MAX_MONSTERS;i<MAX_PLAYERS;i++) {
	 if(m_Players[PlayerNum].Connected == TRUE){
		if(strcmp(stm->text,"DOG")==0)
		{
			Levelup(&m_Players[PlayerNum]);
		}else{
			rstm.Header.Type = MSG_CHATING;
			rstm.Header.Size = sizeof(sShowText);
			rstm.Header.PlayerID = m_Players[PlayerNum].dpnidPlayer;
			strcpy(rstm.text,m_Players[PlayerNum].Name);
			strcat(rstm.text,": ");
			strcat(rstm.text,stm->text);
		//MB(rstm.text);
			SendNetworkMessage(&rstm, DPNSEND_NOLOOPBACK);
		}
	 }
 //}

	return TRUE;
}

BOOL cMainApp::PlayerStateChange(sMessage *Msg)
{
  sStateChangeMessage *scm, uscm;
  long i, PlayerNum;
  BOOL AllowChange;
  float XDiff, ZDiff, Dist, Angle;
  if(m_Players == NULL)
    return FALSE;

	// ���o���A���ܪ�message
  scm = (sStateChangeMessage*)Msg;
	// ���o���a��dpnid���X
  PlayerNum = -1;
  for(i=0;i<MAX_PLAYERS;i++) {
    if(m_Players[i].dpnidPlayer == Msg->Header.PlayerID &&    \
       m_Players[i].Connected == TRUE) {
		 PlayerNum = i;
      break;
    }
  }
  if(PlayerNum == -1)
    return FALSE;

  AllowChange = TRUE;  // ���\���ܪ��A
  
  
	// ��������ɪ���s���A
  if(m_Players[PlayerNum].State == STATE_SWING){
    AllowChange = FALSE;
  }
	// ����Q��ծɧ�s���a
  if(m_Players[PlayerNum].State == STATE_HURT)
    AllowChange = FALSE;
	
	// ��Lok
  if(AllowChange == TRUE) {
		// ��s���a
    m_Players[PlayerNum].Time      =	timeGetTime();
	
    if( !(scm->Header.PlayerID >=0 && scm->Header.PlayerID < MAX_MONSTERS) ){
		m_Players[PlayerNum].Direction = scm->Direction;
		if(scm->State == STATE_SWAPWP){
			m_Players[PlayerNum].State=STATE_IDLE;
			m_Players[PlayerNum].WP=scm->WP;
		}else{
			m_Players[PlayerNum].State     = scm->State;
		}
		if(scm->State == STATE_HEAL){
			if(m_Players[PlayerNum].Mon >=100 && m_Players[PlayerNum].HP < m_Players[PlayerNum].MaxHP)
			{
				m_Players[PlayerNum].HP=m_Players[PlayerNum].MaxHP;
				m_Players[PlayerNum].Mon-=100;
			}
			m_Players[PlayerNum].State=STATE_IDLE;
		}
		// �L�ժ��a�ʧ@������
		m_Players[PlayerNum].Time -= m_Players[PlayerNum].Latency;
		// �ǰe���a��Ƶ�������clients
		uscm.Header.Type     = MSG_STATE_CHANGE;
		uscm.Header.Size     = sizeof(sStateChangeMessage);
		uscm.Header.PlayerID = m_Players[PlayerNum].dpnidPlayer;

		if(CheckChangeMap(&m_Players[PlayerNum]))	{}
		uscm.AtMap       = m_Players[PlayerNum].AtMap;
		uscm.State           = m_Players[PlayerNum].State;
		uscm.XPos            = m_Players[PlayerNum].XPos;
		uscm.YPos            = m_Players[PlayerNum].YPos;
		uscm.ZPos            = m_Players[PlayerNum].ZPos;
		uscm.Direction       = m_Players[PlayerNum].Direction;
		uscm.Career          = m_Players[PlayerNum].Career;
		uscm.WP          = m_Players[PlayerNum].WP;
		uscm.Level          = m_Players[PlayerNum].Level;
		uscm.EQ1          = m_Players[PlayerNum].EQ1;
		uscm.EQ2          = m_Players[PlayerNum].EQ2;
		uscm.EQ3          = m_Players[PlayerNum].EQ3;
		uscm.Speed           = m_Players[PlayerNum].Speed;		
		uscm.HP			= m_Players[PlayerNum].HP;
		uscm.SP			=	m_Players[PlayerNum].SP;
		uscm.MaxHP	=	m_Players[PlayerNum].MaxHP;
		uscm.MaxSP	=	m_Players[PlayerNum].MaxSP;
		uscm.Exp		= m_Players[PlayerNum].Exp;
		uscm.NextExp= m_Players[PlayerNum].NextExp;
		uscm.Mon			=	m_Players[PlayerNum].Mon;
		strcpy(uscm.Name,m_Players[PlayerNum].Name);
		SendNetworkMessage(&uscm, DPNSEND_NOLOOPBACK);
	}
  }
		// �����ɡA���˪̪��B�z
    if((m_Players[PlayerNum].State == STATE_SWING && (PlayerNum >=0 && PlayerNum < MAX_MONSTERS) && m_Players[PlayerNum].Count%14==0)|| 
		(m_Players[PlayerNum].State == STATE_SWING && PlayerNum >= MAX_MONSTERS)) {

			// �ˬd���������a
      for(i=0;i<MAX_PLAYERS;i++) {
        
        // Only check against other players that are connected
        if(i != PlayerNum && m_Players[i].Connected == TRUE) {

          // Get distance to player
					// ���o���a�Z��
          XDiff = (float)fabs(m_Players[PlayerNum].XPos -     \
                              m_Players[i].XPos);
          ZDiff = (float)fabs(m_Players[PlayerNum].ZPos -     \
                              m_Players[i].ZPos);
          Dist = XDiff*XDiff + ZDiff*ZDiff;

					// �O�_�A�����ϰ�(�Z��)
          if(Dist < 10000.0f) {
            
						// ���o���a���������װ��D
            Angle = -(float)atan2(                            \
                           (m_Players[i].ZPos -               \
                            m_Players[PlayerNum].ZPos),       \
                           (m_Players[i].XPos -               \
                            m_Players[PlayerNum].XPos)) +     \
                            
							1.570796f;

						// ��է����̪���V
            Angle -= m_Players[PlayerNum].Direction;

            Angle += 0.785f; // �վ����

						// �d�򪺨��׭�
            if(Angle < 0.0f)
              Angle += 6.28f;
            if(Angle >= 6.28f)
              Angle -= 6.28f;
                       
						// ���a����(���e��90��)
            if(Angle >= 0.0f && Angle <= 1.570796f) {

							// �]�w�Q�����̪����A
              if(m_Players[i].State != STATE_HURT && !(m_Players[i].State >=5 && m_Players[i].State<13)) {
					if(Attack(&m_Players[PlayerNum] , &m_Players[i]))
					{		
						m_Players[i].State = STATE_HURT;
					}
					m_Players[i].Time = timeGetTime();
					if( m_Players[i].Auto==3 && m_Players[i].dpnidPlayer>=0 && m_Players[i].dpnidPlayer< MAX_MONSTERS)
						m_Players[i].Auto=2;   //�p�G�Q�����̬O�Q�ʤ��������Ǫ��A���ܩǪ����A���Q�ʧ���
                // �ǰe�T��
					uscm.Header.Type = MSG_STATE_CHANGE;
					uscm.Header.Size = sizeof(sStateChangeMessage);
					uscm.Header.PlayerID = m_Players[i].dpnidPlayer;
					uscm.State = m_Players[i].State;
					uscm.XPos = m_Players[i].XPos;
					uscm.YPos = m_Players[i].YPos;
				    uscm.ZPos = m_Players[i].ZPos;
					uscm.Direction = m_Players[i].Direction;
					uscm.AtMap = m_Players[i].AtMap;
					uscm.Career= m_Players[i].Career;
					uscm.WP = m_Players[i].WP;
					uscm.EQ1 = m_Players[i].EQ1;
					uscm.EQ2 = m_Players[i].EQ2;
					uscm.EQ3 = m_Players[i].EQ3;
			        uscm.Speed = m_Players[i].Speed;
								//////////////////////////////////
					uscm.HP			= m_Players[i].HP;
					uscm.SP			=	m_Players[i].SP;
					uscm.MaxHP  =   m_Players[i].MaxHP;
					uscm.MaxSP  =	m_Players[i].MaxSP;
					uscm.MaxHP  =   m_Players[i].Exp;
					uscm.MaxSP  =	m_Players[i].NextExp;
					uscm.Mon			=	m_Players[i].Mon;
					uscm.Level			=	m_Players[i].Level;
					strcpy(uscm.Name,m_Players[i].Name);
                SendNetworkMessage(&uscm, DPNSEND_NOLOOPBACK);
              }
            }
          }
        }
      }
    }
  return TRUE;
}

//
// ��l�����ε{������functions
//
//
BOOL cMainApp::SelectAdapter()
{
  int Result;

  ShowWindow(GethWnd(), SW_HIDE);

	// �إߤ����d���C
  m_Adapters.Init();

	// dialog
  Result = DialogBox(GethInst(), MAKEINTRESOURCE(IDD_CONFIG), \
                     GethWnd(), ConfigDialogProc);

	// �Y���a������h��continue�ʧ@
  if(Result == FALSE)
    return FALSE;

  ShowWindow(GethWnd(), SW_SHOW);

  return TRUE;
}

void cMainApp::SetupApplicationWindow()
{
	// ���ip
  m_Controls[0] = CreateWindow("STATIC", "",                  
          WS_CHILD | WS_VISIBLE,                              
          4, 4, 800, 18,                                      
          GethWnd(), NULL, GethInst(), NULL);

	// �s�u�H��
  m_Controls[1] = CreateWindow("STATIC",                      
          "�� �e �S �� �� �a �s �u",                             
          WS_CHILD | WS_VISIBLE,                              
          4, 26, 800, 18,                                     
          GethWnd(), NULL, GethInst(), NULL);

	// �C�����a�W��
  m_Controls[2] = CreateWindow("LISTBOX", "",                 
          WS_CHILD | WS_BORDER | WS_VSCROLL | WS_VISIBLE,     
          4, 48, 800, 600,                                    
          GethWnd(), NULL, GethInst(), NULL);   

}

BOOL cMainApp::InitializeGame()
{
	// ��l�ƹϧθ˸m�M��ܼҥ�
  m_Graphics.Init();
  m_Graphics.SetMode(GethWnd());

	// ���J��������
  //m_LevelMesh.Load(&m_Graphics, "..\\Data\\green1-1\\green1-1.x");
  InputMapMesh();
	// �t�m�T����C�P���]�T������
  m_Messages = new sMessage[NUM_MESSAGES]();
  m_MsgHead = m_MsgTail = 0;

  // �إߪ��a���c
  m_Players = new sPlayer[MAX_PLAYERS]();
  

  
  //�إߩǪ����c
  for(int MNumber=0;MNumber<MAX_MONSTERS;MNumber++){
	strcpy(m_Players[MNumber].UserID,"***************");
	strcpy(m_Players[MNumber].Psw,"***************");
	  m_Players[MNumber].dpnidPlayer=MNumber;
		m_Players[MNumber].Connected = TRUE;
		m_Players[MNumber].Career=rand()%3+3;
		m_Players[MNumber].Level=rand()%10;
		m_Players[MNumber].WP=rand()%MAX_WEAPONS;
		m_Players[MNumber].AtMap=rand()%25+25;
//		m_Players[MNumber].AtMap=46;
		ReadMonsterDB(m_Players[MNumber]);
  }
  ReadWP();
  // �s�u�H��
  m_NumPlayers = 0;

  return TRUE;
}

BOOL cMainApp::HostGame()
{
  char Text[33], IP[16];

	// �Ұ�Server��
  m_Server.Init();
  if(m_Server.Host(m_guidAdapter, 9123,                       \
                  "Dreaming Online game", NULL, MAX_PLAYERS) == FALSE)
    return FALSE;

	// ���oip��m
  m_Server.GetIP(IP);
  sprintf(Text, "�D�� IP ��}: %s", IP);
  SetWindowText(m_Controls[0], Text);

  return TRUE; 
}

//
// Game message queue processing and update functions
//
//
void cMainApp::ProcessQueuedMessages()
{
  sMessage *Msg;
  long Count = 0;

  // �����T���ӳB�z��loop
  while(Count != MESSAGES_PER_FRAME && m_MsgHead != m_MsgTail) {

		// ���otail message
    EnterCriticalSection(&m_MessageCS);
    Msg = &m_Messages[m_MsgTail];
    LeaveCriticalSection(&m_MessageCS);

		// �B�z�T��������
    switch(Msg->Header.Type) {
      case MSG_ASSIGNID: // �ǰe�����aID
        PlayerID(Msg, Msg->Header.PlayerID);
        break;

      case MSG_PLAYER_INFO:    // �ШD���a��T
        PlayerInfo(Msg, Msg->Header.PlayerID);
        break;

      case MSG_CREATE_PLAYER:  // �[�J���a
        AddPlayer(Msg);
        break;

      case MSG_DESTROY_PLAYER: // ���h���a
        RemovePlayer(Msg);
        break;

      case MSG_STATE_CHANGE:   // �ק缾�a���A
        PlayerStateChange(Msg);
        break;
	  case MSG_CHATING :
		ShowText(Msg);
		break;
    }

    Count++; // �T���p��

		// ���o�U�@�ӰT��
    EnterCriticalSection(&m_MessageCS);
    m_MsgTail = (m_MsgTail + 1) % NUM_MESSAGES;
    LeaveCriticalSection(&m_MessageCS);
  }
}

void cMainApp::UpdatePlayers()
{
  long i;
  int MD=0;//�Ǫ�����V
  float XMove, ZMove, Speed;
  
  sStateChangeMessage scm;
  long Elapsed;

  MonsterAI();
  
  for(i=0;i<MAX_PLAYERS;i++) {

		// �B�s���s�u�����a
    if(m_Players[i].Connected == TRUE) {

      // ���o�{�b�ɶ���W�@���ʧ@���ۮt�Ȭ����u�ɶ�
      Elapsed = timeGetTime() - m_Players[i].Time;

			// �B�z���a�ʧ@���A
      if(m_Players[i].State == STATE_MOVE) {
				// �p��ʧ@���t��
        Speed = (float)Elapsed / 1000.0f * m_Players[i].Speed;
        XMove = (float)sin(m_Players[i].Direction) * Speed;
        ZMove = (float)cos(m_Players[i].Direction) * Speed;
        
				// �I������
        if(CheckIntersect(&m_LevelMesh[m_Players[i].AtMap],                       \
                          m_Players[i].XPos,                  \
                          m_Players[i].YPos + 8.0f,          \
                          m_Players[i].ZPos,                  \
                          m_Players[i].XPos + XMove,          \
                          m_Players[i].YPos + 8.0f,          \
                          m_Players[i].ZPos + ZMove) == TRUE){
			XMove = ZMove = 0.0f;
			m_Players[i].State = STATE_IDLE;
		}
				// ��s���a�y��
        m_Players[i].XPos += XMove;
        m_Players[i].YPos = 0.0f;    // ���d�b��a
        m_Players[i].ZPos += ZMove;
        
        m_Players[i].Time = timeGetTime();  // ���]�ɶ�
	  }

	  
		/*	 if(m_Players[i].State == STATE_CHOOSING) {
			
			//	if(Elapsed > 1000) {
						m_Players[i].State = STATE_CHOOSING;
						m_Players[i].Count =0;
		
					// �ǰe�����T�������a
					scm.Header.Type     = MSG_STATE_CHANGE;
					scm.Header.Size     = sizeof(sStateChangeMessage);
					scm.Header.PlayerID = m_Players[i].dpnidPlayer;
					scm.Career          = m_Players[i].Career;
					scm.WP				= m_Players[i].WP;
					scm.XPos            = m_Players[i].XPos;
					scm.YPos            = m_Players[i].YPos;
					scm.ZPos            = m_Players[i].ZPos;
				//	m_Players[i].AtMap +=1;
					scm.AtMap           = m_Players[i].AtMap;
					scm.Direction       = m_Players[i].Direction;
					scm.Speed           = m_Players[i].Speed;
					scm.State           = m_Players[i].State;
					scm.HP				= m_Players[i].HP;
					scm.SP				= m_Players[i].SP;
					scm.MaxHP			= m_Players[i].MaxHP;
					scm.MaxSP			= m_Players[i].MaxSP;
					scm.Exp				= m_Players[i].Exp;
					scm.NextExp			= m_Players[i].NextExp;
					// �T��
					SendNetworkMessage(&scm, DPNSEND_NOLOOPBACK, -1);
      // }
      }*/

      // �@����M���媬�A
      if(m_Players[i].State == STATE_SWING ||m_Players[i].State == STATE_PLAYGAME) {
        if(Elapsed > 1000) {
				m_Players[i].State = STATE_IDLE;
				m_Players[i].Count =0;
		
					// �ǰe�����T�������a
          scm.Header.Type     = MSG_STATE_CHANGE;
          scm.Header.Size     = sizeof(sStateChangeMessage);
          scm.Header.PlayerID = m_Players[i].dpnidPlayer;
		  scm.Career          = m_Players[i].Career;
		  scm.WP          = m_Players[i].WP;
		  scm.EQ1          = m_Players[i].EQ1;
		  scm.EQ2          = m_Players[i].EQ2;
		  scm.EQ3          = m_Players[i].EQ3;
          scm.XPos            = m_Players[i].XPos;
          scm.YPos            = m_Players[i].YPos;
          scm.ZPos            = m_Players[i].ZPos;
		  scm.AtMap           = m_Players[i].AtMap;
          scm.Direction       = m_Players[i].Direction;
          scm.Speed           = m_Players[i].Speed;
          scm.State           = m_Players[i].State;
		  scm.HP			= m_Players[i].HP;
		  scm.SP			=	m_Players[i].SP;
		  scm.MaxHP   = m_Players[i].MaxHP;
		  scm.MaxSP		=	m_Players[i].MaxSP;
		  scm.Exp			= m_Players[i].Exp;
		  scm.NextExp	=	m_Players[i].NextExp;
		  scm.Mon			=	m_Players[i].Mon;
		  scm.Level			=	m_Players[i].Level;
		  strcpy(scm.Name,m_Players[i].Name);
					// �T��
          SendNetworkMessage(&scm, DPNSEND_NOLOOPBACK, -1);
        }
      }

		  // �@����M�����˪��A
      if(m_Players[i].State == STATE_HURT ) {
        if(Elapsed > 1000) {
		  Die(&m_Players[i]);
          m_Players[i].State = STATE_IDLE;
		  m_Players[i].Count =0;
					// �ǰe�����T�������a
          scm.Header.Type     = MSG_STATE_CHANGE;
          scm.Header.Size     = sizeof(sStateChangeMessage);
          scm.Header.PlayerID = m_Players[i].dpnidPlayer;
		  scm.Career          = m_Players[i].Career;
		  scm.WP          = m_Players[i].WP;
		  scm.EQ1          = m_Players[i].EQ1;
		  scm.EQ2          = m_Players[i].EQ2;
		  scm.EQ3          = m_Players[i].EQ3;
          scm.XPos            = m_Players[i].XPos;
          scm.YPos            = m_Players[i].YPos;
          scm.ZPos            = m_Players[i].ZPos;
		  scm.AtMap           = m_Players[i].AtMap;
          scm.Direction       = m_Players[i].Direction;
          scm.Speed           = m_Players[i].Speed;
          scm.State           = m_Players[i].State;
		  scm.HP			= m_Players[i].HP;
		  scm.SP			=	m_Players[i].SP;
		  scm.MaxHP   = m_Players[i].MaxHP;
		  scm.MaxSP		=	m_Players[i].MaxSP;
		  scm.Exp			= m_Players[i].Exp;
		  scm.NextExp	=	m_Players[i].NextExp;
          // �T��
		  scm.Mon			=	m_Players[i].Mon;	
		  scm.Level			=	m_Players[i].Level;
		  strcpy(scm.Name,m_Players[i].Name);
          SendNetworkMessage(&scm, DPNSEND_NOLOOPBACK, -1);
        }
      }
    }
  }
  	
}

void cMainApp::UpdateNetwork()
{
  long i;
  sStateChangeMessage scm;

	// �ǰe���������a
  for(i=0;i<MAX_PLAYERS;i++) {

    // �ȳB�z���s�u�����a
    if(m_Players[i].Connected == TRUE) {
      scm.Header.Type     = MSG_STATE_CHANGE;
      scm.Header.Size     = sizeof(sStateChangeMessage);
      scm.Header.PlayerID = m_Players[i].dpnidPlayer;
	  scm.Career          = m_Players[i].Career;
	  scm.WP				= m_Players[i].WP;
	  scm.EQ1          = m_Players[i].EQ1;
	  scm.EQ2          = m_Players[i].EQ2;
	  scm.EQ3          = m_Players[i].EQ3;
      scm.XPos            = m_Players[i].XPos;
      scm.YPos            = m_Players[i].YPos;
      scm.ZPos            = m_Players[i].ZPos;
	  scm.AtMap           = m_Players[i].AtMap;
      scm.Direction       = m_Players[i].Direction;
      scm.Speed           = m_Players[i].Speed;
      scm.State           = m_Players[i].State;
      scm.Latency         = m_Players[i].Latency;


			//
			scm.HP			= m_Players[i].HP;
			scm.SP			=	m_Players[i].SP;
			scm.MaxHP   = m_Players[i].MaxHP;
			scm.MaxSP		=	m_Players[i].MaxSP;
			scm.Exp			= m_Players[i].Exp;
			scm.NextExp	=	m_Players[i].NextExp;
			scm.Mon			=	m_Players[i].Mon;
			scm.Level			=	m_Players[i].Level;
			strcpy(scm.Name,m_Players[i].Name);
			// �ǰe�T��
      SendNetworkMessage(&scm, DPNSEND_NOLOOPBACK);
    }
  }
}

void cMainApp::UpdateLatency()
{
  long i;
  DPN_CONNECTION_INFO dpci;
  HRESULT hr;

	// ���������a
  for(i=0;i<MAX_PLAYERS;i++) {
    
		// �ȳB�z���s�u�����a
    if(m_Players[i].Connected == TRUE) {

			// �n�D���a�s�u�]�w
      hr = m_Server.GetServerCOM()->GetConnectionInfo(        \
                   m_Players[i].dpnidPlayer, &dpci, 0);

      if(SUCCEEDED(hr)) {
        m_Players[i].Latency = dpci.dwRoundTripLatencyMS / 2;

        // Bounds latency to 1 second
        if(m_Players[i].Latency > 1000)
          m_Players[i].Latency = 1000;

      } else {
        m_Players[i].Latency = 0;
      }
    }
  }
  ListPlayers();			// �C����W
}

//
// Game logic functions
//
//
BOOL cMainApp::CheckIntersect(cMesh *Mesh,                        \
                 float XStart, float YStart, float ZStart,    \
                 float XEnd,   float YEnd,   float ZEnd)
{
  sMesh *MeshPtr;
  BOOL  Hit;
  float u, v, Dist;
  float XDiff, YDiff, ZDiff, Size;
  DWORD FaceIndex;
  D3DXVECTOR3 vecDir;

  if(Mesh == NULL)
    return FALSE;

  // Start with parent mesh
  if((MeshPtr = Mesh->GetParentMesh()) == NULL)
    return FALSE;

  // Calculate ray
  XDiff = XEnd - XStart;
  YDiff = YEnd - YStart;
  ZDiff = ZEnd - ZStart;
  D3DXVec3Normalize(&vecDir, &D3DXVECTOR3(XDiff, YDiff, ZDiff));

  // Go through each mesh looking for intersection
  while(MeshPtr != NULL) {
    D3DXIntersect(MeshPtr->m_Mesh,                            \
                &D3DXVECTOR3(XStart,YStart,ZStart), &vecDir,  \
                &Hit, &FaceIndex, &u, &v, &Dist,NULL,NULL);

    if(Hit == TRUE) {
      Size = (float)sqrt(XDiff*XDiff+YDiff*YDiff+ZDiff*ZDiff);
      if(Dist <= Size)
        return TRUE;
    }

    MeshPtr = MeshPtr->m_Next;
  }

  return FALSE;
}

//
// Server class code
//
//
BOOL cServer::CreatePlayer(DPNMSG_CREATE_PLAYER *Msg)
{
  if(g_Application != NULL)
    g_Application->CreatePlayer(Msg);
 
  return TRUE;
}

BOOL cServer::DestroyPlayer(DPNMSG_DESTROY_PLAYER *Msg)
{
  if(g_Application != NULL)
    g_Application->DestroyPlayer(Msg);
  return TRUE;
}

BOOL cServer::Receive(DPNMSG_RECEIVE *Msg)
{
  if(g_Application != NULL)
    g_Application->Receive(Msg);
  return TRUE;
}

//
// ��O�ȭp�� 
//


bool cMainApp::Attack(sPlayer *a,sPlayer *b)
{
	int atk= (a->Level/5+1)* a->Str + WPData[a->WP];
	int def= (b->Level/5+1)*b->Con +rand()%5;
	int dag=atk-def;
	if(dag>0)
		b->HP = b->HP - dag ;
	//b->HP = b->HP-((a->Level/5+1)* a->Str - ((b->Level/5+1)*b->Con));
	if(b->HP <= 0) //�Q�����̦�C��0
	{
		a->Mon+= rand()%100;	
		if(a->dpnidPlayer <0 || a->dpnidPlayer>=MAX_MONSTERS) //�p�G�����̬O���a
		{                                                     //���o�g���
			if(b->dpnidPlayer>=0 && b->dpnidPlayer < MAX_MONSTERS)
				a->Exp+=b->Exp;
			else
				a->Exp++;
			if(a->Exp >= a->NextExp)                //�P�_�O�_�ɯ�
				Levelup(a);
			int GetWP=rand()%10+1;
			if(GetWP<MAX_WEAPONS)
			{
				//if(a->EQ3 != UNKNOW)
				//	return true;
				if(a->EQ1 == GetWP)
					return true;
				if(a->EQ2 == GetWP)
					return true;
				if(a->EQ3 == GetWP)
					return true;
				if(a->EQ1 == UNKNOW){
					a->EQ1=GetWP;
					return true;
				}
				if(a->EQ2 == UNKNOW){
					a->EQ2=GetWP;
					return true;
				}
				if(a->EQ2 == UNKNOW){
					a->EQ3=GetWP;
					return true;
				}
			}
		}
		return true;                //�Ǧ^�Q�����̦��`�T��
	}
	return false;                     //�Ǧ^�Q�����̥����`�T��
}



void cMainApp::Levelup(sPlayer *a)
{
	a->Level=a->Level +1;
	a->MaxHP=a->MaxHP + a->Con;
	a->MaxSP=a->MaxSP + a->Int;
	a->NextExp=a->Level *100;
	a->HP=a->MaxHP;
	a->SP=a->MaxSP;
	a->Exp=0;
}

void cMainApp::InputMapMesh()
{
FILE     *fp;
	char Map[120];
	char FileName[100];
	fp=fopen("GameMap.txt","r");
	int counter;
	int j;
	int number=0;
	if(fgets(Map,120,fp)) 
	{
		MapCount=atoi(Map);
		m_LevelMesh=new cMesh[MapCount]();
		AllMap=new GameMap[MapCount]();
	}
	while(fp){
	  	 if(! fgets(Map,120,fp)) 
			 break;
		 counter=0;
		 j=0;
		 while (j<strlen(Map)){
			 if(Map[j]=='%')
				 counter++;
			 j++;
		 }
		 AllMap[number].ExitCount=counter;
		 AllMap[number].Exit=new ExitMap[counter]();
		 counter=-1;
		 int Pos=0,index=0;
		 char sub[5];
		 for (int i=0;i<strlen(Map);i++)
			switch (Map[i])
			{
				case '#':
					sub[Pos]='\0';
					AllMap[number].MapID = atoi(sub);
					sprintf(FileName,"..\\Data\\%u.x",atoi(sub));
					m_LevelMesh[number].Load(&m_Graphics, FileName);
					Pos=0;
					break;
				case '%':
					counter++;
					sub[Pos]='\0';
					Pos=0;
					AllMap[number].Exit[counter].MapID = atoi(sub);
					break;
				case '.':
					sub[Pos]='\0';
					Pos=0;
					switch(index){
					case 0:
						AllMap[number].Exit[counter].LXPos = atoi(sub);
						
						break;
					case 1:
						AllMap[number].Exit[counter].LZPos = atoi(sub);
						break;
					case 2:
						AllMap[number].Exit[counter].RXPos = atoi(sub);
						break;
					case 3:
						AllMap[number].Exit[counter].RZPos = atoi(sub);
						break;
					case 4:
						AllMap[number].Exit[counter].NewXPos = atoi(sub);
						break;
					}
					index++;
					if(index >4)
						index=0;
					break;
				case ';':
					sub[Pos]='\0';
					Pos=0;
					AllMap[number].Exit[counter].NewZPos = atoi(sub);
					break;
				default:
					sub[Pos]=Map[i];
					Pos++;
			}
		 number++;

		
	}
	fclose(fp);
}

//
// for DB using write & read
// 

BOOL cMainApp::CheckChangeMap(sPlayer *Players)
{
	long	Elapsed = timeGetTime() - MenuTime;
	switch (Players->State)
	{
		case STATE_DELETE:
			Players->Career=UNKNOW;
			Players->AtMap=0;
			Players->Level=1;
			Players->Mon=0;
			Players->WP=UNKNOW;
			DeleteWP(*Players);
			Players->State = STATE_START;
			return true;
		case STATE_PLAYGAME:
			// �qDBŪ�����
			Players->State = STATE_PLAYGAME;
			return true;
		case STATE_START :	
			return true;

		case STATE_CHOOSING : 	
			return true;

		case STATE_CHOOSINGL : 
			return true;

		case STATE_CHOOSINGR : 
			return true;

		case STATE_LEFT:{
				Players->AtMap=0;
				Players->Career=ASS;
				Players->Level=1;
				Players->WP=UNKNOW;
				ReadMonsterDB(*Players);
				Players->NextExp=100;
				Players->State = STATE_START;
				return true;
			}
		case STATE_RIGHT:{
				Players->AtMap=0;
				Players->Career=WAR;
				Players->Level=1;
				Players->WP=UNKNOW;
				ReadMonsterDB(*Players);
				Players->NextExp=100;
				Players->State = STATE_START;
				return true;
			}

		case STATE_IDLE : case STATE_MOVE : case STATE_SWING : case STATE_HURT :case STATE_SWAPWP: case STATE_HEAL:
			 break;

			default: MB("���e�����~"); break;
	}

	float PlayerXPos=Players->XPos;
	float PlayerZPos=Players->ZPos;
	float LX,LZ,RX,RZ,NewX,NewZ;
	for(int i=0;i< AllMap[Players->AtMap].ExitCount;i++){
		LX=AllMap[Players->AtMap].Exit[i].LXPos;
		LZ=AllMap[Players->AtMap].Exit[i].LZPos;
		RX=AllMap[Players->AtMap].Exit[i].RXPos;
		RZ=AllMap[Players->AtMap].Exit[i].RZPos;
		NewX=AllMap[Players->AtMap].Exit[i].NewXPos;
		NewZ=AllMap[Players->AtMap].Exit[i].NewZPos;
		
		if(PlayerXPos >= LX && PlayerXPos <= RX && PlayerZPos<=LZ && PlayerZPos>=RZ){
			Players->AtMap=AllMap[Players->AtMap].Exit[i].MapID;
			Players->XPos=NewX;
			Players->ZPos=NewZ;
			return true;
		}
	}
	
	return false;
}

void cMainApp::MonsterAI()
{
	long MobIndex=0,UserIndex,UserNumber,seelenth,temp=0;
	float X,Z;
	int MD=0;//�Ǫ�����V
	float Angles[13] = { 0.0f, 0.0f, 1.57f, 0.785f, 3.14f,      \
                       0.0f, 2.355f, 0.0f, 4.71f, 5.495f,     \
                       0.0f, 0.0f, 3.925f };
 
	for(MobIndex=0;MobIndex<MAX_MONSTERS;MobIndex++) { //����Ҧ��Ǫ���AI
		if((m_Players[MobIndex].Auto==0 || m_Players[MobIndex].Auto==2)&& (m_Players[MobIndex].State == STATE_IDLE  || m_Players[MobIndex].State == STATE_MOVE) ){
			//���Ǫ��|�D�ʥB���A�άO�b�Q�ʧ������A�ɬO�bIDLE�άO�bMOVE���p�U
			UserNumber=-1;
			seelenth=m_Players[MobIndex].See;
			for(UserIndex=MAX_MONSTERS;UserIndex<MAX_PLAYERS;UserIndex++){ //�M��Ǫ����u���O�_�����a
				if(m_Players[UserIndex].Connected==TRUE && m_Players[UserIndex].AtMap == m_Players[MobIndex].AtMap && m_Players[UserIndex].State != UNKNOW && !(m_Players[UserIndex].State > 4 && m_Players[UserIndex].State<13 ) ){
					X=m_Players[UserIndex].XPos-m_Players[MobIndex].XPos;
					Z=m_Players[UserIndex].ZPos-m_Players[MobIndex].ZPos;
					temp=sqrt(pow((int)X,2)+pow((int)Z,2));
					if(temp <= seelenth){
						seelenth=temp;
						UserNumber=UserIndex;
					}
				}
			}
			if(UserNumber != -1)   //�������a�b�Ǫ����u��
			{
				if(m_Players[UserNumber].XPos - m_Players[MobIndex].XPos > 5)
					MD+=2;
				if(m_Players[UserNumber].XPos - m_Players[MobIndex].XPos < -5)
					MD+=8;
				if(m_Players[UserNumber].ZPos - m_Players[MobIndex].ZPos > 5)
					MD+=1;
				if(m_Players[UserNumber].ZPos - m_Players[MobIndex].ZPos < -5)
					MD+=4;
				
				m_Players[MobIndex].Direction=Angles[MD];
				if(seelenth <25)
				{
					m_Players[MobIndex].State=STATE_SWING;
				    m_Players[MobIndex].Count= 0;
				}else{
					m_Players[MobIndex].State = STATE_MOVE;
					m_Players[MobIndex].Count= 0;
				}
			}else{  //�S�����a�b�Ǫ����u���A�Ǫ��|�۰ʦ樫
				if(m_Players[MobIndex].Auto==2 )
					m_Players[MobIndex].Auto=3;
				if(m_Players[MobIndex].Count >20){
					MD=rand()%13;
					if(MD != 0)
					{
						m_Players[MobIndex].Direction=Angles[MD];
						m_Players[MobIndex].State = STATE_MOVE;
						m_Players[MobIndex].Count= 0;
					}else{
						m_Players[MobIndex].State = STATE_IDLE;
						m_Players[MobIndex].Count= 0;
					}
				}else{
					m_Players[MobIndex].Count++;
				}
			}
		}else{ //���Ǫ����O�D�ʧ��������A�Ǫ��۰ʦ樫
			if(m_Players[MobIndex].Count >20 && (m_Players[MobIndex].State == STATE_IDLE  || m_Players[MobIndex].State == STATE_MOVE)){
				MD=rand()%13;
				if(MD != 0)
				{
					m_Players[MobIndex].Direction=Angles[MD];
					m_Players[MobIndex].State = STATE_MOVE;
					m_Players[MobIndex].Count= 0;
				}else{
					m_Players[MobIndex].State = STATE_IDLE;
					m_Players[MobIndex].Count= 0;
				}
			}else{
				m_Players[MobIndex].Count++;
			}
		}
	}
}

void cMainApp::Die(sPlayer *a)
{
	if(a->dpnidPlayer>=0 && a->dpnidPlayer < MAX_MONSTERS)
	{
		a->AtMap=rand()%25+25;
		a->XPos= 0.0f;
        a->YPos= 0.0f;
        a->ZPos= -100.0f;
		a->HP=a->MaxHP;
		
	}else{
		a->AtMap=0;
		a->XPos= 0.0f;
        a->YPos= 0.0f;
        a->ZPos= 0.0f;
		a->HP=1;
	}
}


///-----------------------------------------------------------------------
void cMainApp::ReadMonsterDB(sPlayer &Player)
{
	
	const char* p;
	HRESULT lg;
	CoInitialize(NULL);
	Role_Get::DBCOM_Role_Get_InterfacePtr rd(__uuidof(Role_Get::DBCOM_Role_Get_Class));
	Role_Get::DBCOM_Role_Get_Interface *role_style;
	role_style = rd;
	
	role_style->Sys_Get_Value(Player.Career);
	// �]�w���a���
	Player.Connected = TRUE;
	for (int i=1;i<9;i++)
	{
		_bstr_t mData = role_style->Role_Get_Value(i);
		p = mData;
		switch (i){
			case 1:if(Player.dpnidPlayer >=0 && Player.dpnidPlayer<MAX_MONSTERS) 
				strcpy(Player.Name,p); break;
			case 2: Player.Exp			= atoi(p);break;
			case 3: Player.Str		= atoi(p);break;
			case 4: Player.Con		= atoi(p);break;
			case 5: Player.Int		= atoi(p);break;
			case 6: Player.Speed		= atoi(p);break;
			case 7: Player.MaxHP		= atoi(p);Player.HP=Player.MaxHP;break;
			case 8: Player.MaxSP		= atoi(p);Player.SP=Player.MaxSP;break;
			default : MB("���XDB���~!!");break;
		}
	}
	Player.XPos      = 0.0f;
	Player.YPos      = 0.0f;
     Player.ZPos      = -100.0f;
     Player.Direction = 0.0f;
     Player.State     = STATE_IDLE;
     Player.Latency   = 0;
	  Player.EQ1    = UNKNOW;
	  Player.EQ2    = UNKNOW;
	  Player.EQ3    = UNKNOW;
	  Player.Count  = 0;
	  if(Player.Career==TIGER)
		Player.Auto  = 1;
	  if(Player.Career==MONKEY)
		Player.Auto  = 2;
	  if(Player.Career==KNI)
		Player.Auto  = 0;
	  Player.See  = Player.Int*15;
	Player.Time  = 0;
	//MB("OK");
	
}
///-----------------------------------------------------------------------

void cMainApp::DeleteWP(sPlayer &Player)
{
	CoInitialize(NULL);
			Equipment_Delete::DBCOM_Equipment_Delete_InterfacePtr deq(__uuidof(Equipment_Delete::DBCOM_Equipment_Delete_Class));
			Equipment_Delete::DBCOM_Equipment_Delete_Interface *delete_equ;
			delete_equ = deq;
			delete_equ->Equipment_Delete(Player.UserID);

}
void cMainApp::WriteDB(sPlayer &Player)
{
	/*
	string id,string password,int use_equipment,
	int user_kind,int map_id,int coordinage_x,int coordinage_y,
	int coordinage_z,int game_money,int grade,int experience_value,
	int advance_exper,int strength,int coonstitation,int intelligence,
	int speed,int blood,int max_blood,int magic,int max_magic)*/
	//--------------------
	const char* p;
	CoInitialize(NULL);
	User_Write::DBCOM_User_Write_InterfacePtr wr(__uuidof(User_Write::DBCOM_User_Write_Class));
	User_Write::DBCOM_User_Write_Interface *wr_com_ptr;
	wr_com_ptr = wr;
	//_bstr_t mData = wr_com_ptr->Write_User_Value(Player.UserID,Player.Psw,"good","e04",10,10,10,10,10,10,10,10,10,10,10,1,10,10,10,10,10);
	_bstr_t mData = wr_com_ptr->User_Write_Value(Player.UserID,Player.Psw,Player.WP,Player.Career, \
		Player.AtMap,Player.XPos,Player.YPos,Player.ZPos, \
		Player.Mon,Player.Level,Player.Exp,Player.NextExp,Player.Str, \
		Player.Con,Player.Int,Player.Speed,Player.HP,Player.MaxHP,Player.SP,Player.MaxSP);

	p = mData;

	Equipment_Write::DBCOM_Equipment_Write_InterfacePtr Ewr(__uuidof(Equipment_Write::DBCOM_Equipment_Write_Class));
	Equipment_Write::DBCOM_Equipment_Write_Interface *Ewr_com_ptr;
	Ewr_com_ptr = Ewr;
	Ewr_com_ptr->Equipment_Write_Value(Player.UserID,Player.EQ1,Player.EQ2,Player.EQ3);
	
//	MB(p);
	
}

bool cMainApp::ReadDB(sPlayer &Players)
{
	const char* p;
	HRESULT lg;
	CoInitialize(NULL);
	User_Login::DBCOM_User_Login_InterfacePtr rd(__uuidof(User_Login::DBCOM_User_Login_Class));
	User_Login::DBCOM_User_Login_Interface *user_login;
	user_login = rd;
	lg=user_login->User_Login(Players.UserID,Players.Psw);

	char test[8];
	if (lg==-1){
		// �]�w���a���
		Players.Connected = TRUE;
		for (int i=1;i<21;i++)
		{
			_bstr_t mData = user_login->User_GetValue(i);
			p = mData;
			switch (i){
				case 1: strcpy(Players.Name,p);
					    //Players.Name[strlen(Players.Name)]='\0';
							break;
				case 2: Players.WP			= atoi(p);break;
				case 3: Players.Career		= atoi(p);break;
				case 4: Players.AtMap		= atoi(p);break;
				case 5: Players.XPos		= atoi(p);break;
				case 6: Players.YPos		= atoi(p);break;
				case 7: Players.ZPos		= atoi(p);break;
				case 8: Players.Mon			= atoi(p);break;
				case 9: Players.Level		= atoi(p);break;
				case 10: Players.Exp		= atoi(p);break;
				case 11: Players.NextExp	= atoi(p);break;
				case 12: Players.Str		= atoi(p); break;
				case 13: Players.Con		= atoi(p);break;
				case 14: Players.Int		= atoi(p);break;
				case 15: Players.Speed		= atoi(p);break;
				case 16: Players.HP			= atoi(p);break;
				case 17: Players.MaxHP		= atoi(p);break;
				case 18: Players.SP			= atoi(p);break;
				case 19: Players.MaxSP		= atoi(p);break;
				case 20: break;
			//case 21: Players.EQPower	= atoi(p);break;
				default : MB("���XDB���~!!");break;
			}
		}
		Players.EQ1=UNKNOW;
		Players.EQ2=UNKNOW;
		Players.EQ3=UNKNOW;
		
		bool num=false;
		CoInitialize(NULL);
		Equipment_Get::DBCOM_Equipment_Get_InterfacePtr requ(__uuidof(Equipment_Get::DBCOM_Equipment_Get_Class));
		Equipment_Get::DBCOM_Equipment_Get_Interface *get_equ;
		get_equ = requ;
		_bstr_t mData = get_equ->Equipment_Get_Value(Players.UserID);
		p = mData;
		char sub[8];
		int loc=0,Pos=0;
		for (i=0;i<strlen(p);i++)
		{
			switch (p[i])
			{
				
				case '@':
					sub[Pos]='\0';
					if(loc==0)
						Players.EQ1 = atoi(sub);
					if(loc==1)
						Players.EQ2 = atoi(sub);
					if(loc==2)
						Players.EQ3 = atoi(sub);
					Pos=0;
					loc++;
					break;
				
				default:
					sub[Pos]=p[i];
					Pos++;
			}
		}
		Players.Direction = 0.0f;
		Players.State     = STATE_START;
		Players.Latency   = 0;
		return true;
		

	}
	return false;
}

void cMainApp::ReadWP()
{
	const char* p;
	HRESULT lg;
	CoInitialize(NULL);

	Equipment_Sys_Get::DBCOM_Sys_Get_Equipment_InterfacePtr requ(__uuidof(Equipment_Sys_Get::DBCOM_Sys_Get_Equipment_Class));
	Equipment_Sys_Get::DBCOM_Sys_Get_Equipment_Interface *get_equ;
	get_equ = requ;
	
	_bstr_t mData = get_equ->Sys_Get_Equipment();
	p = mData;
	//MB(p);
		char sub[8];
		int loc=0,Pos=0;
		for (int i=0;i<strlen(p);i++)
		{
			switch (p[i])
			{
				
				case '@':
					sub[Pos]='\0';
				
					WPData[loc]=atoi(sub);
					Pos=0;
					loc++;
					break;
				
				default:
					sub[Pos]=p[i];
					Pos++;
					break;
			}
		}
		
}

