#ifndef _WINMAIN_H_
#define _WINMAIN_H_


int PlayerVsPlayer(sPlayer *a,sPlayer *b);
///////////////////////////////////////////////////////////
// Server class definition
//
//
class cServer : public cNetworkServer
{
  private:
    BOOL CreatePlayer(DPNMSG_CREATE_PLAYER *Msg);
    BOOL DestroyPlayer(DPNMSG_DESTROY_PLAYER *Msg);
    BOOL Receive(DPNMSG_RECEIVE *Msg);
};

///////////////////////////////////////////////////////////
// cMainApp
//
//
class cMainApp : public CGameSysCoreMgt
{
  private:
    HWND             m_Controls[3];  // ����id

    CRITICAL_SECTION m_UpdateCS;     // �{���϶�
    CRITICAL_SECTION m_MessageCS;

    GUID            *m_guidAdapter; 
    cNetworkAdapter  m_Adapters;  
    cServer          m_Server;       // Derived server class

    CGraphics3DCore  m_Graphics;  
	
    cMesh            *m_LevelMesh;    // ����
    void             InputMapMesh();   //Ū�J����mesh
		int              MapCount;         //������
		GameMap          *AllMap; 
    //void LoadMap(int MID);
		BOOL CheckChangeMap(sPlayer *Players);


    long             m_NumPlayers;   // �s�u�H��
    sPlayer         *m_Players;      // ���a���
    sMessage        *m_Messages;     // �T��queue
    long             m_MsgHead;      // Head
    long             m_MsgTail;      // Tail
    
    BOOL SelectAdapter();            // ��ܤ����d
    void SetupApplicationWindow();   // �]�wAP
    BOOL InitializeGame();         
    BOOL HostGame();                 // �Ұ�host

    void ListPlayers();              // ���C�s�u�H��

    void ProcessQueuedMessages();    // �B�z���ݤ����T�� 
    void UpdatePlayers();            // ��s�����O�����a
    void UpdateNetwork();            // �ǵ����a
    void UpdateLatency();            // ��slantency

		// �ǰe�����T����client
    BOOL SendNetworkMessage(void *Msg, long SendFlags = 0,    \
                            int To = -1);

		//  �B�zqueue���T��
    BOOL QueueMessage(void *Msg);  
    BOOL PlayerID(sMessage *Msg, DPNID To);
    BOOL PlayerInfo(sMessage *Msg, DPNID To);
    BOOL AddPlayer(sMessage *Msg);
    BOOL RemovePlayer(sMessage *Msg);
    BOOL PlayerStateChange(sMessage *Msg);
	BOOL ShowText(sMessage *Msg);
		// �I���ˬd
    BOOL CheckIntersect(cMesh *Mesh,                          \
                 float XStart, float YStart, float ZStart,    \
                 float XEnd,   float YEnd,   float ZEnd);

	//	��O�ȭp��
	
	bool Attack(sPlayer *a,sPlayer *b);   //����
	void Levelup(sPlayer *a);             //�ɯ�
	int WPData[MAX_WEAPONS];
    void MonsterAI();
	void Die(sPlayer *a);            //���`��
	// DB��
	void WriteDB(sPlayer &Player);
	bool ReadDB(sPlayer &Player);
	void ReadMonsterDB(sPlayer &Player);
	void ReadWP();
	void DeleteWP(sPlayer &Player);

  public:
    
    cMainApp();

    BOOL Init();
    BOOL Shutdown();
    BOOL FrameProcess();
    FAR PASCAL MsgProc(HWND hWnd, UINT uMsg,                  \
                       WPARAM wParam, LPARAM lParam);

    void SetAdapter(GUID *Adapter); 

		// ���Xnetwork���T��
    BOOL CreatePlayer(DPNMSG_CREATE_PLAYER *Msg);
    BOOL DestroyPlayer(DPNMSG_DESTROY_PLAYER *Msg);
    BOOL Receive(DPNMSG_RECEIVE *Msg);


};

int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hPrev,          \
                   LPSTR szCmdLine, int nCmdShow);
BOOL CALLBACK ConfigDialogProc(HWND hWnd, UINT uMsg,          \
                               WPARAM wParam, LPARAM lParam);

#endif
