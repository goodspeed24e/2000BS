#include <iostream>
#include <fstream.h>
#include <time.h>
#define Maparraylength 69
#define Maparraywidth 50



class AIOListNode   //List��node
{
public:
	int f,g,h;           //�v��
	int x,y;             //�y��
	AIOListNode *parent;  //��node
	AIOListNode *next;    //�U�@��node
	AIOListNode *before;   //�e�@��node
	AIOListNode(int vx,int vy){
		x=vx;
		y=vy;
		parent=NULL;
		next=NULL;
		before=NULL;
		
	};
	void AISetghf(int sx,int sy,int tempx,int tempy)  //�p���v��
	{
		g=abs(x- sx)+abs(y - sy);
		h=abs(x - tempx)+abs(y - tempy);
		f=g + h;
	};

};


class AINode    //path��node
{
public:
	int x,y;
	AINode(int vx,int vy){
		x=vx;
		y=vy;
		parent=NULL;
		next=NULL;
	};
	AINode *next;
	AINode *parent;
};

class AIUser //���� 
{
public:
	AIUser(int a,int b){
		sx=a;
		sy=b;
		/*do{
			do{
				sx=rand()% Maparraylength;
			}while(!(sx>=0 && sx<Maparraylength));	
			do{
				sy=rand()% Maparraywidth;
			}while(!(sy>=0 && sy<Maparraywidth));
		}while(MapArray[sx][sy] =='1');
		*/
		PathIndex=NULL;
		PathWalk=NULL;
		OLIndex = NULL;
		CLIndex = NULL;
		

	};
	~AIUser(){
		AIdelmemory();
		PathIndex=NULL;
		PathWalk=NULL;
		OLIndex = NULL;
		CLIndex = NULL;
	};
	int sx,sy;
	int dx,dy;
	int max;
	bool AIdecDestination();
	bool AISetDestination(int x,int y);
	bool AISelectpath(int x,int y);
	bool AICheckCL(int checkx,int checky);
	bool AICheckOL(AIOListNode *OL);
	void AIdelmemory();
	AIOListNode	*AIGetBestOLNode();
	AIOListNode *OLIndex;
	AIOListNode *CLIndex;
	AINode *PathIndex;
	AINode *PathWalk;
	AINode	*AISetpath(AIOListNode* OL);
	char MapArray[Maparraylength][Maparraywidth];
	void LoadMap(char *file);
};