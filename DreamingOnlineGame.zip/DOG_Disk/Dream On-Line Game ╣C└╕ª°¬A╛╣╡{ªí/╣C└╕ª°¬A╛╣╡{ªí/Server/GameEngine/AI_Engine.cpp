#include "AI_Engine.h"


void AIUser::AIdelmemory() //�M������path node���O����
{
	if(PathIndex != NULL)
	{
		while(PathIndex->next!=NULL){
			PathIndex=PathIndex->next;
			delete PathIndex->parent;
		};
		delete PathIndex;
	}
	PathWalk=NULL;

}


AINode* AIUser::AISetpath(AIOListNode* OL)   //��List��node�নpath�W��node
{                                            //�M��List node���O����
	AINode* temp;
	temp=new AINode(OL->x,OL->y);
	while(OL ->parent!=NULL)
	{	
		OL=OL->parent;
		temp->parent=new AINode(OL->x,OL->y);
		temp->parent->next=temp;
		temp=temp->parent;
			
	};

	while(OLIndex->next!=NULL){
		OLIndex=OLIndex->next;
		delete OLIndex->before;
	};
	delete OLIndex;

	while(CLIndex->next!=NULL){
		CLIndex=CLIndex->next;
		delete CLIndex->before;
	};
	delete CLIndex;
	
	
	return temp;
	
};
bool AIUser::AICheckCL(int checkx,int checky)   //�ˬdList node�O�_�X�{�bClose list
{
	AIOListNode *CLtemp=CLIndex;
	while(CLtemp!=NULL){
		if(CLtemp->x==checkx && CLtemp->y==checky )
			return true;
		CLtemp=CLtemp->next;
	};
	return false;
};

bool AIUser::AICheckOL(AIOListNode *OL)         //�ˬdList node�O�_�X�{�bOpen list
{
	AIOListNode *OLtemp=OLIndex;
	while(OLtemp!=NULL){
		if(OLtemp->x==OL->x && OLtemp->y==OL->x)
		{
			if(OLtemp->f > OL->f)
			{
				OLtemp->f=OL->f;
				OLtemp->g=OL->g;
				OLtemp->h=OL->h;
				OLtemp->parent=OL->parent;
			}
			return true;
		}
		OLtemp=OLtemp->next;
	};
	return false;
};

AIOListNode* AIUser::AIGetBestOLNode()       //���oOpen list���v���̰�(f�ȳ̧C)
{
	AIOListNode *best=OLIndex;
	AIOListNode *temp=OLIndex;
	while(temp !=NULL){
		if(best->f > temp->f)
			best=temp;
		temp=temp->next;
	};
	temp=OLIndex;
	if(best->before!=NULL)
	{
		best->before->next=best->next;
		if(best->next!=NULL)
		{
			best->next->before=best->before;
		}
	}else{
			OLIndex=best->next;
			if(OLIndex !=NULL)
				OLIndex->before=NULL;
		   //�qOpenList�R��bestAINode
	}
	best->before=NULL;
	best->next=NULL;
	AIOListNode *CLtemp=CLIndex;            //�NbestAINode�[�JCloseList
	if(CLIndex==NULL)                 
	{
		CLIndex=best;
	}
	else{
		while(CLtemp ->next !=NULL)
		{
			CLtemp=CLtemp->next;
		}
		CLtemp->next=best;
		best->before=CLtemp;
	}
	return best;
};

bool AIUser::AIdecDestination()       //�M�w����ت��a�y��
{
	do{
		do{
			dx=sx+rand()%20-10;
		}while(!(dx>=0 && dx<Maparraylength));	
		do{
			dy=sy+rand()%30-10;
		}while(!(dy>=0 && dy<Maparraywidth));
	}while(MapArray[dx][dy] =='1');
	if(!AISetDestination(dx,dy))
		return false;
	return true;
}

bool AIUser::AISetDestination(int x,int y)    //�N����_�l�I�[��Open list�}�l�B���ت��a�����|
{
	OLIndex=0;
	CLIndex=0;
	OLIndex=new AIOListNode(sx,sy);
	OLIndex->AISetghf(sx,sy,x,y);
	max=1;
	if(!AISelectpath(x,y))
		return false;
	return true;
};
bool AIUser::AISelectpath(int x,int y)         //�p����|
{
	AIOListNode *OLtemp=AIGetBestOLNode();
	AIOListNode *OLInserttemp;
	AIOListNode *OLNewNode;
	while(OLtemp != NULL)
	{
		for(int vx=-1;vx<=1;vx++)
		{
			for(int vy=-1;vy<=1;vy++)
			{
				if(OLtemp->x+vx >=0 && OLtemp->x+vx < Maparraylength && OLtemp->y+vy >=0 && OLtemp->y+vy < Maparraywidth 
					&& MapArray[OLtemp->x+vx][OLtemp->y+vy]!='1' 
					&& !AICheckCL(OLtemp->x+vx,OLtemp->y+vy))
				{
					OLNewNode=new AIOListNode(OLtemp->x+vx,OLtemp->y+vy);
					OLNewNode->AISetghf(sx,sy,x,y);
					OLNewNode->parent=OLtemp;
					
					if(!AICheckOL(OLNewNode))
					{
						
						if(OLIndex==NULL)
							OLIndex=OLNewNode;
						else{
							OLInserttemp=OLIndex;
							while(OLInserttemp->next !=NULL ){
								OLInserttemp=OLInserttemp->next;
							};
							OLInserttemp->next=OLNewNode;
							OLNewNode->before=OLInserttemp;
							if(OLNewNode->x==x && OLNewNode->y==y)
							{	
								AIdelmemory();
								PathIndex=NULL;
								PathWalk=NULL;
								
								PathIndex=AISetpath(OLNewNode);
								
								PathWalk=PathIndex->next;
								return true;
							}
							max++;
							if(max >100)
								return false;
						};
					}else{
						delete OLNewNode;
					}
				};
			};
		};
		OLtemp=AIGetBestOLNode();
	}
	return false;
};

void AIUser::LoadMap(char* file)
{
	ifstream fin(file);
	fin.read(*MapArray,Maparraywidth*Maparraylength);
};