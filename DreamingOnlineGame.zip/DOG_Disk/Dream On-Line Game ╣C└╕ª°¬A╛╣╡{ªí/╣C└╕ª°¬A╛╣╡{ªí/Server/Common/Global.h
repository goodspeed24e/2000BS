//////////////////////////////////////////////////////////////////
//
//
//*****************************************											
//	�w�q���Y��, Global.h - v0.1	
//  author : Y.Y.L Date : 02/27/03
//*****************************************
//----------------------------------------------------------------


#ifndef _GLOBAL_H_
#define _GLOBAL_H_

// INCLUDE ////////////////////////////////////////////////////////

#ifdef WIN32
// Windows & STL includes
#include <windows.h>
#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <assert.h>
#include <time.h>
#else
// Standard ANSI-C includes
#include <stdio.h>

#endif

// DirectX includes
#include "d3d8.h"
#include "d3dx8.h"
#include "dmusici.h"
#include "dsound.h"
#include "dplay8.h"
#include "dpaddr.h"
#include "dinput.h"

// �\��禡 includes
#include "GameTemplate.h"

// �귽�� includes
#include "..\WIN32\resource.h"

// Custom Engine includes
#include "..\GameEngine\System_Core.h"
#include "..\GameEngine\DXGraphics_Engine.h"
#include "..\GameEngine\DXNetWork_Engine.h"
#include "..\GameEngine\AI_Engine.h"
#pragma warning( disable: 4127 )
#pragma inline_depth( 255 )
#pragma inline_recursion( on )

#pragma comment(lib,"DXNetwork_Engine.lib")

#import "..\..\DB_COM\User_Login.tlb"
#import "..\..\DB_COM\Equipment_Get.tlb"
#import "..\..\DB_COM\Equipment_Sys_Get.tlb"
#import "..\..\DB_COM\Role_Get.tlb"
#import "..\..\DB_COM\User_Write.tlb"
#import "..\..\DB_COM\Equipment_Write.tlb"
#import "..\..\DB_COM\Equipment_Delete.tlb"


#endif